export interface MinifigStyle {
  hairType: 'classic' | 'spiky' | 'long' | 'cap' | 'helmet' | 'wizard';
  hairColor: string; // hex or color name
  expression: 'smile' | 'wink' | 'cool' | 'glasses' | 'determined';
  torsoColor: string;
  torsoPrint: 'classic-space' | 'brick' | 'ninja' | 'heart' | 'tie' | 'none';
  legsColor: string;
}

export interface Student {
  id: string;
  name: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  birthdate: string;
  emergencyName: string;
  emergencyPhone: string;
  school: string;
  dietaryRestrictions: string;
  membershipType: 'Master Builder' | 'Adventurer' | 'Not a Member';
  photoPermission: boolean;
  guestPassUsed: boolean;
  setRentalUsed: boolean;
  avatar: MinifigStyle;
  badges: { [badgeId: string]: number }; // percentage 0-100 progress
  checkedInToday?: boolean;
  lastCheckIn?: string; // Timestamp ISO
  parentPassword?: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  category: 'Creativity' | 'Engineering' | 'Teamwork' | 'Focus';
  reqSteps: number;
  iconName: string;
}

export interface Workshop {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  minAge: number;
  spotsLeft: number;
  price: string;
  tag: string;
}

export interface CheckInLog {
  timestamp: string;
  studentName: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  membershipType: string;
  status: string; // "Checked In" | "Checked Out" "Staff In" | "Staff Out"
}

export interface Staff {
  id: string;
  name: string;
  role: string;
  avatar: MinifigStyle;
  checkedInToday?: boolean;
  lastCheckIn?: string;
  hoursWorked?: number; // Total accumulated hours in decimal (e.g. 15.5)
  clockedIn?: boolean; // Is currently on active shift
  shiftStartTimestamp?: string; // ISO string when they ticked clock in
  password?: string; // secure custom password for this staff member
}

export interface AdminNotification {
  id: string;
  timestamp: string;
  text: string;
  taskText?: string;
  completedBy?: string;
  read: boolean;
}

export interface DailyTask {
  id: string;
  text: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday' | 'All Days';
  completed: boolean;
  completedBy?: string; // staff ID or name
  completedAt?: string; // timestamp
  assignedTo?: string; // staff ID or name
}

export interface Booking {
  id: string;
  studentId: string;
  studentName: string;
  parentEmail: string;
  day: string;
  hour: string;
  notes?: string;
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  description: string;
  date: string; // ISO format "YYYY-MM-DD"
  type: 'Camp' | 'Workshop' | 'Holiday' | 'Special Event';
}

export interface LegoSet {
  id: string;
  name: string;
  theme: string;
  pieces: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Master';
  rented: boolean;
  rentedByStudentId?: string;
  rentedByStudentName?: string;
  rentedDate?: string;
  parentEmail?: string;
}


