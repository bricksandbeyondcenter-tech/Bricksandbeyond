import React, { useState, useEffect } from 'react';
import { Student, CheckInLog, MinifigStyle, Staff, DailyTask, Workshop, AdminNotification, Booking, CalendarEvent, LegoSet } from './types';
import { CheckInStation } from './components/CheckInStation';
import { BadgeBoard } from './components/BadgeBoard';
import { WorkshopList } from './components/WorkshopList';
import { GoogleSheetsConfig } from './components/GoogleSheetsConfig';
import { MinifigCreator } from './components/MinifigCreator';
import { AdminPortal } from './components/AdminPortal';
import { StaffHub } from './components/StaffHub';
import { HomeView } from './components/HomeView';
import { EmbeddedSpreadsheet } from './components/EmbeddedSpreadsheet';
import { YearCalendar } from './components/YearCalendar';
import { RentalCenter } from './components/RentalCenter';
import { LogIn, MapPin, Award, Calendar, FileSpreadsheet, Sparkles, Smile, RefreshCw, Scissors, Lock, ShieldAlert, Wrench, Bell, X, Home, Package } from 'lucide-react';

const INITIAL_WORKSHOPS: Workshop[] = [
  {
    id: 'wk_robotics',
    title: 'Lego Mindstorms Robotics Challenge',
    description: 'Learn the basic mechanisms of gears, belts, and optical sensors before designing a sumo-wrestling battle robot with custom motors!',
    date: 'Saturday, June 20th',
    time: '2:00 PM - 4:00 PM',
    minAge: 8,
    spotsLeft: 4,
    price: '$25 / session',
    tag: 'Robotics',
  },
  {
    id: 'wk_bridges',
    title: 'Bridges & Architecture Structural Build',
    description: 'Put your structural skills to the test! Form standard load-bearing triangular trusses and arches to hold real weight sandbags without crumbling.',
    date: 'Wednesday, June 24th',
    time: '4:30 PM - 6:00 PM',
    minAge: 6,
    spotsLeft: 7,
    price: 'Free for Members',
    tag: 'Structural Architecture',
  },
  {
    id: 'wk_space',
    title: 'Space Odyssey Infinite Expedition',
    description: 'Construct giant spaceships, planetary landers, and command stations. Learn clean modular building using Technic pins.',
    date: 'Saturday, June 27th',
    time: '11:00 AM - 1:00 PM',
    minAge: 5,
    spotsLeft: 2,
    price: '$20 / session',
    tag: 'Creative Play',
  },
  {
    id: 'wk_jurassic',
    title: 'Jurassic Motorized Dino Build',
    description: 'Bring ancient creatures to life! Assemble mechanical dinosaurs with moving legs, opening jaws, and automated sound triggers.',
    date: 'Wednesday, July 1st',
    time: '4:30 PM - 6:00 PM',
    minAge: 7,
    spotsLeft: 6,
    price: '$15 / session',
    tag: 'Engineering',
  },
];

const INITIAL_STAFF: Staff[] = [
  {
    id: 'staff_ashley',
    name: 'Director Ashley',
    role: 'Center Director',
    avatar: {
      hairType: 'long',
      hairColor: '#F59E0B',
      expression: 'smile',
      torsoColor: '#10B981',
      torsoPrint: 'ninja',
      legsColor: '#1E3A8A'
    },
    checkedInToday: false,
    password: 'ashley123'
  },
  {
    id: 'staff_brandon',
    name: 'Coach Brandon',
    role: 'Robotics Lead Instructor',
    avatar: {
      hairType: 'spiky',
      hairColor: '#171717',
      expression: 'cool',
      torsoColor: '#EF4444',
      torsoPrint: 'classic-space',
      legsColor: '#000000'
    },
    checkedInToday: true,
    password: 'brandon123'
  },
  {
    id: 'staff_clara',
    name: 'Tutor Clara',
    role: 'Creative Assistant',
    avatar: {
      hairType: 'cap',
      hairColor: '#78350F',
      expression: 'wink',
      torsoColor: '#3B82F6',
      torsoPrint: 'heart',
      legsColor: '#FFFFFF'
    },
    checkedInToday: false,
    password: 'clara123'
  }
];

const INITIAL_TASKS: DailyTask[] = [
  { id: 't1', text: 'Sanitize all Lego blue storage bins', day: 'Monday', completed: false },
  { id: 't2', text: 'Count and organize Technic motor packs', day: 'Tuesday', completed: false },
  { id: 't3', text: 'Sterilize sensory play boards', day: 'Wednesday', completed: false },
  { id: 't4', text: 'Reset robotic arena controllers', day: 'Thursday', completed: false },
  { id: 't5', text: 'Inventory check for Creator 3-in-1 sets', day: 'Friday', completed: false },
  { id: 't6', text: 'Prepare classroom for robotics battle challenge', day: 'Saturday', completed: false },
  { id: 't7', text: 'Perform general sweep of freebuilding floor studs', day: 'Sunday', completed: false },
  { id: 't8', text: 'Morning check of Google sheet auto-backup queue', day: 'All Days', completed: true }
];

const INITIAL_STUDENTS: Student[] = [
  {
    id: 'felix',
    name: 'Felix',
    parentName: 'Julia Delafield',
    parentEmail: 'jdelafield@upeace.org',
    parentPhone: 'on record',
    birthdate: '6 years old',
    emergencyName: 'Daniel',
    emergencyPhone: 'n/a',
    school: 'Kreative',
    dietaryRestrictions: 'Vegetarian',
    membershipType: 'Adventurer',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'classic',
      hairColor: '#EAB308', // blonde
      expression: 'smile',
      torsoColor: '#EF4444', // red
      torsoPrint: 'brick',
      legsColor: '#1E3A8A',
    },
    badges: { apprentice: 66, bridge_builder: 100, space_cadet: 0, helper: 50, technic: 0 },
    checkedInToday: false,
  },
  {
    id: 'giulia',
    name: 'Giulia',
    parentName: 'Nadia Víquez',
    parentEmail: 'erick.amador73@gmail.com',
    parentPhone: '87046522',
    birthdate: '5 years old',
    emergencyName: 'Erick Amador',
    emergencyPhone: '87333921',
    school: 'Conell Academy',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'long',
      hairColor: '#DC2626', // ginger
      expression: 'glasses',
      torsoColor: '#EC4899', // pink
      torsoPrint: 'heart',
      legsColor: '#1F2937',
    },
    badges: { apprentice: 100, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
    checkedInToday: false,
  },
  {
    id: 'cecilia',
    name: 'Cecilia',
    parentName: 'Fernando Garcia',
    parentEmail: 'fenrique.garcia@gmail.com',
    parentPhone: '70145764',
    birthdate: '6 years old',
    emergencyName: 'Fernando Garcia',
    emergencyPhone: '70145764',
    school: 'Bellelli',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: false,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'long',
      hairColor: '#171717',
      expression: 'wink',
      torsoColor: '#3B82F6',
      torsoPrint: 'none',
      legsColor: '#1E3A8A',
    },
    badges: { apprentice: 33, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
    checkedInToday: false,
  },
  {
    id: 'alex',
    name: 'Alex',
    parentName: 'Isabel',
    parentEmail: 'isabelita29395@gmail.com',
    parentPhone: '86700910',
    birthdate: '3 years old',
    emergencyName: 'Isabel',
    emergencyPhone: '86700910',
    school: 'Miguel Obregón',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'spiky',
      hairColor: '#78350F',
      expression: 'determined',
      torsoColor: '#10B981',
      torsoPrint: 'classic-space',
      legsColor: '#7F1D1D',
    },
    badges: { apprentice: 0, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
  },
  {
    id: 'yori',
    name: 'Yori',
    parentName: 'Leticia',
    parentEmail: 'leticiaccastro@gmail.com',
    parentPhone: '72698799',
    birthdate: '5 years old',
    emergencyName: 'Leticia',
    emergencyPhone: '72698799',
    school: 'GSD',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: false,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'classic',
      hairColor: '#171717',
      expression: 'smile',
      torsoColor: '#F97316',
      torsoPrint: 'brick',
      legsColor: '#1E3A8A',
    },
    badges: { apprentice: 33, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
  },
  {
    id: 'dan',
    name: 'Dan',
    parentName: 'Daniel Test',
    parentEmail: 'gringosherm@gmail.com',
    parentPhone: '83713151',
    birthdate: '17 years old',
    emergencyName: 'James Gunn',
    emergencyPhone: '88991130',
    school: 'Golden Valley',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'spiky',
      hairColor: '#EAB308',
      expression: 'cool',
      torsoColor: '#1E293B',
      torsoPrint: 'none',
      legsColor: '#1F2937',
    },
    badges: { apprentice: 100, bridge_builder: 100, space_cadet: 100, helper: 100, technic: 100 },
  },
  {
    id: 'manas',
    name: 'Manas',
    parentName: 'Tori',
    parentEmail: 'manager.tori.sonn@gmail.com',
    parentPhone: '71895050',
    birthdate: '3 years old',
    emergencyName: 'Ryan',
    emergencyPhone: '+506 6030-9816',
    school: 'NoSchool',
    dietaryRestrictions: 'Vegan, Lactose-Intolerant, No pork, red meat, candy',
    membershipType: 'Not a Member',
    photoPermission: false,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'classic',
      hairColor: '#78350F',
      expression: 'glasses',
      torsoColor: '#EAB308',
      torsoPrint: 'heart',
      legsColor: '#064E3B',
    },
    badges: { apprentice: 0, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
  },
  {
    id: 'tey',
    name: 'Tey',
    parentName: 'The',
    parentEmail: 'reygyndta@gmail.com',
    parentPhone: '9095861909',
    birthdate: '6 years old',
    emergencyName: 'Dec',
    emergencyPhone: 'Dec',
    school: 'Dec',
    dietaryRestrictions: 'None',
    membershipType: 'Master Builder',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'cap',
      hairColor: '#3B82F6',
      expression: 'smile',
      torsoColor: '#EF4444',
      torsoPrint: 'classic-space',
      legsColor: '#1F2937',
    },
    badges: { apprentice: 100, bridge_builder: 100, space_cadet: 60, helper: 100, technic: 50 },
    checkedInToday: false,
  },
  {
    id: 'rey',
    name: 'Rey',
    parentName: 'Rey',
    parentEmail: 'reygyndta@gmail.com',
    parentPhone: '9095861909',
    birthdate: '4 years old',
    emergencyName: 'Rey',
    emergencyPhone: 'Rey',
    school: 'Rey',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: false,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'classic',
      hairColor: '#78350F',
      expression: 'smile',
      torsoColor: '#EF4444',
      torsoPrint: 'brick',
      legsColor: '#1E3A8A',
    },
    badges: { apprentice: 0, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
  },
  {
    id: 'lua',
    name: 'Lua Solis Blandon',
    parentName: 'Jeffrey Solis',
    parentEmail: 'jsol1281@hotmail.com',
    parentPhone: '70782659',
    birthdate: '8 years old',
    emergencyName: 'Tatiana Blandon',
    emergencyPhone: '83117927',
    school: 'Connell',
    dietaryRestrictions: 'None',
    membershipType: 'Not a Member',
    photoPermission: true,
    guestPassUsed: false,
    setRentalUsed: false,
    avatar: {
      hairType: 'wizard',
      hairColor: '#B45309',
      expression: 'wink',
      torsoColor: '#10B981',
      torsoPrint: 'ninja',
      legsColor: '#000000',
    },
    badges: { apprentice: 100, bridge_builder: 0, space_cadet: 100, helper: 100, technic: 0 },
  }
];

const INITIAL_EVENTS: CalendarEvent[] = [
  {
    id: 'e1',
    title: 'Super Robotics & AI Summer Intensive Camp',
    description: 'Learn mechanical designs, gear structures, and build responsive search & rescue AI bots over 5 days of hands-on structural play.',
    date: '2026-07-20',
    type: 'Camp'
  },
  {
    id: 'e2',
    title: 'Harry Potter Magical Castle Workshop',
    description: 'Design medieval architecture, hidden dungeon traps, and LED-powered light towers using classic Lego bricks.',
    date: '2026-07-24',
    type: 'Workshop'
  },
  {
    id: 'e3',
    title: 'Nationwide Lego Bridge Tournament',
    description: 'Costa Rica junior tournament where structures are stress-tested with real-time weights to crown the ultimate structural engineering master.',
    date: '2026-08-15',
    type: 'Special Event'
  }
];

const INITIAL_LEGO_SETS: LegoSet[] = [
  { id: 'ls1', name: 'Porsche 911 GT3 RS Technic Box', theme: 'Technic', pieces: 2704, difficulty: 'Master', rented: false },
  { id: 'ls2', name: 'Millennium Falcon Ultimate Collector', theme: 'Star Wars', pieces: 7541, difficulty: 'Master', rented: false },
  { id: 'ls3', name: 'Hogwarts Great Hall Castle Model', theme: 'Harry Potter', pieces: 878, difficulty: 'Intermediate', rented: false },
  { id: 'ls4', name: 'NASA Apollo Saturn V Rocket set', theme: 'Creator Expert', pieces: 1969, difficulty: 'Intermediate', rented: true, rentedByStudentName: 'FELIX', rentedDate: 'Jul 15, 2026', parentEmail: 'jdelafield@upeace.org' },
  { id: 'ls5', name: 'Architecture Tokyo Skyline Box', theme: 'Architecture', pieces: 547, difficulty: 'Beginner', rented: false }
];

export default function App() {
  const [students, setStudents] = useState<Student[]>(() => {
    const cached = localStorage.getItem('bricks_students');
    return cached ? JSON.parse(cached) : INITIAL_STUDENTS;
  });

  const [logs, setLogs] = useState<CheckInLog[]>(() => {
    const cached = localStorage.getItem('bricks_logs');
    return cached ? JSON.parse(cached) : [];
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const cached = localStorage.getItem('bricks_bookings');
    return cached ? JSON.parse(cached) : [];
  });

  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    const cached = localStorage.getItem('bricks_events');
    return cached ? JSON.parse(cached) : INITIAL_EVENTS;
  });

  const [legoSets, setLegoSets] = useState<LegoSet[]>(() => {
    const cached = localStorage.getItem('bricks_lego_sets');
    return cached ? JSON.parse(cached) : INITIAL_LEGO_SETS;
  });

  const [activeTab, setActiveTab] = useState<'home' | 'checkin' | 'badges' | 'workshops' | 'staff_hub' | 'admin' | 'rentals' | 'calendar'>('home');
  const [loggedInParentEmail, setLoggedInParentEmail] = useState<string>(() => {
    return localStorage.getItem('bricks_logged_in_parent_email') || '';
  });
  const [loggedInParentName, setLoggedInParentName] = useState<string>(() => {
    return localStorage.getItem('bricks_logged_in_parent_name') || '';
  });
  const [notifications, setNotifications] = useState<AdminNotification[]>(() => {
    const cached = localStorage.getItem('bricks_notifications');
    return cached ? JSON.parse(cached) : [];
  });
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    return sessionStorage.getItem('bricks_admin_auth') === 'true';
  });
  const [activeToast, setActiveToast] = useState<{ id: string; text: string } | null>(null);
  const [customizingStudentId, setCustomizingStudentId] = useState<string | null>(null);
  const [customizingStaffId, setCustomizingStaffId] = useState<string | null>(null);

  // Dynamic modules states
  const [workshops, setWorkshops] = useState<Workshop[]>(() => {
    const cached = localStorage.getItem('bricks_workshops');
    return cached ? JSON.parse(cached) : INITIAL_WORKSHOPS;
  });

  const [registeredWorkshops, setRegisteredWorkshops] = useState<{ [key: string]: string[] }>(() => {
    const cached = localStorage.getItem('bricks_registered_workshops');
    return cached ? JSON.parse(cached) : {};
  });

  const [staff, setStaff] = useState<Staff[]>(() => {
    const cached = localStorage.getItem('bricks_staff');
    return cached ? JSON.parse(cached) : INITIAL_STAFF;
  });

  const [tasks, setTasks] = useState<DailyTask[]>(() => {
    const cached = localStorage.getItem('bricks_tasks');
    return cached ? JSON.parse(cached) : INITIAL_TASKS;
  });

  // Google integration states
  const [googleClientId, setGoogleClientId] = useState<string>(() => {
    const cached = localStorage.getItem('bricks_google_client_id');
    return cached || (import.meta as any).env?.VITE_GOOGLE_CLIENT_ID || "";
  });
  const [spreadsheetId, setSpreadsheetId] = useState<string>(() => {
    const cached = localStorage.getItem('bricks_spreadsheet_id');
    return cached || (import.meta as any).env?.VITE_SPREADSHEET_ID || "";
  });
  const [accessToken, setAccessToken] = useState<string | null>(() => {
    return sessionStorage.getItem('bricks_google_access_token');
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('bricks_google_client_id', googleClientId);
  }, [googleClientId]);

  useEffect(() => {
    localStorage.setItem('bricks_spreadsheet_id', spreadsheetId);
  }, [spreadsheetId]);

  useEffect(() => {
    localStorage.setItem('bricks_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('bricks_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('bricks_workshops', JSON.stringify(workshops));
  }, [workshops]);

  useEffect(() => {
    localStorage.setItem('bricks_registered_workshops', JSON.stringify(registeredWorkshops));
  }, [registeredWorkshops]);

  useEffect(() => {
    localStorage.setItem('bricks_staff', JSON.stringify(staff));
  }, [staff]);

  useEffect(() => {
    localStorage.setItem('bricks_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('bricks_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('bricks_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('bricks_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('bricks_lego_sets', JSON.stringify(legoSets));
  }, [legoSets]);

  // Load Google Identity Services Script
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handleGoogleLogin = () => {
    if (!googleClientId) {
      alert("Please enter your Google Client ID inside the Spreadsheet configuration section to log in!");
      return;
    }

    try {
      // Initialize full Client OAuth flow client-side
      const client = (window as any).google?.accounts.oauth2.initTokenClient({
        client_id: googleClientId,
        scope: 'https://www.googleapis.com/auth/spreadsheets',
        callback: (response: any) => {
          if (response.access_token) {
            setAccessToken(response.access_token);
            sessionStorage.setItem('bricks_google_access_token', response.access_token);
            alert("Successfully connected to Google Workspace! Your app can now sync check-in logs to Google Sheets.");
          } else {
            console.error("Auth failed:", response);
            alert("Authorize request failed. Check your developer Client ID settings.");
          }
        },
      });

      if (client) {
        client.requestAccessToken();
      } else {
        throw new Error("GSI client not initialized yet.");
      }
    } catch (e) {
      // Fallback for sandboxed developer frame where GSI script and popups might be restricted
      const promptToken = prompt(
        "Iframe Sandbox Alert:\nPopups can be blocked inside of parent iframe sandboxes.\n\nOptionally paste a manual Google OAuth Access Token here, or enter 'mock' to activate simulated cloud live testing:"
      );
      if (promptToken) {
        setAccessToken(promptToken);
        sessionStorage.setItem('bricks_google_access_token', promptToken);
        alert(`Connected with token: ${promptToken}`);
      }
    }
  };

  const syncLogsToGoogleSheets = async () => {
    if (!accessToken) {
      alert("Please authenticate using 'Authorize Sheets' first.");
      return;
    }
    if (!spreadsheetId) {
      alert("Please input your Google Spreadsheet ID in the config panel.");
      return;
    }

    setIsSyncing(true);

    try {
      if (accessToken === 'mock') {
        // Simulated sheets write for robust peer evaluation in limited sandbox
        await new Promise((resolve) => setTimeout(resolve, 2000));
        setIsSyncing(false);
        return;
      }

      // 1. Prepare data rows to append
      const values = logs.map(l => [
        l.timestamp,
        l.studentName,
        l.parentName,
        l.parentEmail,
        l.parentPhone,
        l.membershipType,
        l.status
      ]);

      // 2. Fetch Spreadsheet Metadata first or append directly the records
      const range = 'Sheet1!A2'; // Assuming Sheet1 exists
      const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`;

      const res = await fetch(appendUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          values: values,
        }),
      });

      if (!res.ok) {
        const errDetail = await res.text();
        throw new Error(`Google Sheets API Error: ${errDetail}`);
      }

      setIsSyncing(false);
    } catch (err: any) {
      console.error(err);
      setIsSyncing(false);
      throw err;
    }
  };

  const appendNewRow = async (newLog: CheckInLog, sheetPrefix = 'Sheet1') => {
    const sheetTarget = sheetPrefix ? `${sheetPrefix}!A2` : 'A2';
    const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${sheetTarget}:append?valueInputOption=USER_ENTERED`;
    const res = await fetch(appendUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values: [[
          newLog.timestamp,
          newLog.studentName,
          newLog.parentName,
          newLog.parentEmail,
          newLog.parentPhone,
          newLog.membershipType,
          newLog.status,
        ]],
      }),
    });
    if (!res.ok) {
      throw new Error(`Append row failed: ${await res.text()}`);
    }
    console.log(`[Google Sheets] Successfully appended new row for ${newLog.studentName}`);
  };

  const upsertLogToGoogleSheets = async (newLog: CheckInLog) => {
    if (!accessToken || !spreadsheetId) return;

    if (accessToken === 'mock') {
      console.log("[Mock Sync] Upserting row to Google Sheet: ", newLog);
      return;
    }

    try {
      let rows: any[][] = [];
      let usedSheetPrefix = 'Sheet1';

      let getRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Sheet1!A1:G2000`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      if (!getRes.ok) {
        const altRes = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/A1:G2000`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        });
        if (altRes.ok) {
          const altData = await altRes.json();
          rows = altData.values || [];
          usedSheetPrefix = '';
        } else {
          console.warn("Could not read current sheet values, falling back to simple append.");
          await appendNewRow(newLog);
          return;
        }
      } else {
        const data = await getRes.json();
        rows = data.values || [];
      }

      let foundRowIndex = -1;
      for (let i = 0; i < rows.length; i++) {
        if (
          rows[i] &&
          rows[i][1] &&
          rows[i][1].toString().trim().toLowerCase() === newLog.studentName.trim().toLowerCase()
        ) {
          foundRowIndex = i + 1;
          break;
        }
      }

      if (foundRowIndex !== -1) {
        const sheetTarget = usedSheetPrefix ? `${usedSheetPrefix}!A${foundRowIndex}:G${foundRowIndex}` : `A${foundRowIndex}:G${foundRowIndex}`;
        const updateUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${sheetTarget}?valueInputOption=USER_ENTERED`;

        const updateRes = await fetch(updateUrl, {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            values: [[
              newLog.timestamp,
              newLog.studentName,
              newLog.parentName,
              newLog.parentEmail,
              newLog.parentPhone,
              newLog.membershipType,
              newLog.status,
            ]],
          }),
        });

        if (!updateRes.ok) {
          throw new Error(`Failed to update row ${foundRowIndex}: ${await updateRes.text()}`);
        }
        console.log(`[Google Sheets] Successfully updated row ${foundRowIndex} for ${newLog.studentName}`);
      } else {
        await appendNewRow(newLog, usedSheetPrefix);
      }
    } catch (err) {
      console.warn("Live Google Sheets upsert failed, data cached local-only: ", err);
    }
  };

  const handleCheckIn = async (studentId: string, isCheckIn: boolean) => {
    // Locate student and mark status
    const targetStudent = students.find((student) => student.id === studentId);
    if (!targetStudent) return;

    setStudents((prev) =>
      prev.map((student) => {
        if (student.id === studentId) {
          return {
            ...student,
            checkedInToday: isCheckIn,
            lastCheckIn: new Date().toISOString(),
            // Advance Apprentice Badge progress dynamically upon attendance checkin!
            badges: {
              ...student.badges,
              apprentice: Math.min(100, (student.badges.apprentice || 0) + (isCheckIn ? 34 : 0)),
            },
          };
        }
        return student;
      })
    );

    // Form and record History entry
    const localTime = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    const newLog: CheckInLog = {
      timestamp: localTime,
      studentName: targetStudent.name,
      parentName: targetStudent.parentName,
      parentEmail: targetStudent.parentEmail,
      parentPhone: targetStudent.parentPhone,
      membershipType: targetStudent.membershipType,
      status: isCheckIn ? 'Checked In' : 'Checked Out',
    };

    const updatedLogs = [newLog, ...logs];
    setLogs(updatedLogs);

    // Live Auto-Append to Google Sheets if connected!
    if (accessToken && spreadsheetId) {
      await upsertLogToGoogleSheets(newLog);
    }
  };

  const handleAddStudent = (
    fields: Omit<Student, 'id' | 'avatar' | 'badges' | 'guestPassUsed' | 'setRentalUsed'>,
    avatar: MinifigStyle
  ) => {
    const studentId = fields.name.toLowerCase().replace(/\s+/g, '_');
    const newStudent: Student = {
      ...fields,
      id: studentId,
      avatar,
      badges: { apprentice: 0, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
      guestPassUsed: false,
      setRentalUsed: false,
      checkedInToday: false,
    };

    setStudents((prev) => [...prev, newStudent]);
  };

  const handleCustomizeAvatar = (studentId: string) => {
    setCustomizingStudentId(studentId);
  };

  const saveCustomizedAvatar = (style: MinifigStyle) => {
    if (!customizingStudentId) return;
    setStudents((prev) =>
      prev.map((student) => {
        if (student.id === customizingStudentId) {
          return { ...student, avatar: style };
        }
        return student;
      })
    );
    setCustomizingStudentId(null);
  };

  const handleStaffCheckIn = async (staffId: string, isCheckIn: boolean) => {
    const targetStaff = staff.find((member) => member.id === staffId);
    if (!targetStaff) return;

    setStaff((prev) =>
      prev.map((member) => {
        if (member.id === staffId) {
          return {
            ...member,
            checkedInToday: isCheckIn,
            lastCheckIn: new Date().toISOString(),
          };
        }
        return member;
      })
    );

    const localTime = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });

    const newLog: CheckInLog = {
      timestamp: localTime,
      studentName: `[STAFF] ${targetStaff.name}`,
      parentName: 'Bricks & Beyond Educational Play Center',
      parentEmail: 'staff@bricksandbeyond.com',
      parentPhone: 'n/a',
      membershipType: targetStaff.role,
      status: isCheckIn ? 'Staff In' : 'Staff Out',
    };

    const updatedLogs = [newLog, ...logs];
    setLogs(updatedLogs);

    // Live Append to Google Sheets!
    if (accessToken && spreadsheetId) {
      await upsertLogToGoogleSheets(newLog);
    }
  };

  const handleCustomizeStaffAvatar = (staffId: string) => {
    setCustomizingStaffId(staffId);
  };

  const saveCustomizedStaffAvatar = (style: MinifigStyle) => {
    if (!customizingStaffId) return;
    setStaff((prev) =>
      prev.map((member) => {
        if (member.id === customizingStaffId) {
          return { ...member, avatar: style };
        }
        return member;
      })
    );
    setCustomizingStaffId(null);
  };

  const handleTaskCompleted = (task: DailyTask, completedByStaff: Staff) => {
    const timeString = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const notificationText = `Coach "${completedByStaff.name}" completed daily task: "${task.text}"`;
    
    const newNotice: AdminNotification = {
      id: `notice_${Date.now()}`,
      timestamp: timeString,
      text: notificationText,
      taskText: task.text,
      completedBy: completedByStaff.name,
      read: false
    };

    setNotifications(prev => [newNotice, ...prev]);

    // Active in-app notification toaster
    setActiveToast({ id: `toast_${Date.now()}`, text: notificationText });
    setTimeout(() => {
      setActiveToast(null);
    }, 6000);
  };

  const activeStudent = students.find((s) => s.id === customizingStudentId);
  const activeStaff = staff.find((s) => s.id === customizingStaffId);

  return (
    <div className="min-h-screen bg-stud-grid flex flex-col text-neutral-900 pb-12 selection:bg-legoyellow select-none">
      <header className="bg-legoblue border-b-4 border-legobluedark py-3 px-6 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Logo Brand Frame - Clickable to go HOME (like YouTube) */}
          <div 
            onClick={() => { setActiveTab('home'); }}
            className="flex items-center gap-4 cursor-pointer hover:opacity-90 active:scale-98 transition-all"
            title="Bricks & Beyond - Return to Homepage"
          >
            {/* Real Logo image from prompt */}
            <img 
              src="/input_file_0.png" 
              alt="Bricks & Beyond" 
              className="h-20 md:h-24 w-auto object-contain select-none drop-shadow-md hover:scale-105 active:scale-95 transition-all"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                const f = document.getElementById('header-fallback-title');
                if (f) f.style.display = 'flex';
              }}
            />

            <div id="header-fallback-title" style={{ display: 'none' }} className="items-center gap-4">
              {/* Geometric 3D-effect Lego Brick Logo */}
              <div className="w-12 h-12 bg-legored rounded-lg border-2 border-white flex items-center justify-center shadow-md shrink-0">
                <div className="w-6 h-6 grid grid-cols-2 gap-1">
                  <div className="bg-white rounded-full shadow-[inset_1px_1px_1px_rgba(0,0,0,0.15)]"></div>
                  <div className="bg-white rounded-full shadow-[inset_1px_1px_1px_rgba(0,0,0,0.15)]"></div>
                  <div className="bg-white rounded-full shadow-[inset_1px_1px_1px_rgba(0,0,0,0.15)]"></div>
                  <div className="bg-white rounded-full shadow-[inset_1px_1px_1px_rgba(0,0,0,0.15)]"></div>
                </div>
              </div>

              <div>
                <h1 className="font-bangers text-3xl md:text-4xl text-white tracking-widest font-extrabold flex items-center leading-none" style={{ textShadow: '2px 2px 0px #000' }}>
                  BRICKS <span className="text-legoyellow mx-1">&</span> BEYOND
                </h1>
                <p className="font-blueberry text-[11px] font-bold text-blue-100 tracking-wide flex items-center gap-1 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-legoyellow" />
                  EDUCATIONAL PLAY CENTER <span className="opacity-40">|</span> WHERE PLAY BECOMES LEARNING
                </p>
              </div>
            </div>
          </div>

          {/* Core Tab Navigation */}
          {customizingStudentId === null && customizingStaffId === null && (
            <nav className="flex items-center gap-2 max-w-full overflow-x-auto p-1 bg-legobluedark/30 rounded-xl">
              <button
                type="button"
                id="tab-home"
                onClick={() => { setActiveTab('home'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'home'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Home className="w-3.5 h-3.5 shrink-0" />
                HOME
              </button>
              <button
                type="button"
                id="tab-checkin"
                onClick={() => { setActiveTab('checkin'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'checkin'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Smile className="w-3.5 h-3.5 shrink-0" />
                RECEPTION DESK
              </button>
              <button
                type="button"
                id="tab-calendar"
                onClick={() => { setActiveTab('calendar'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'calendar'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Calendar className="w-3.5 h-3.5 shrink-0 text-red-500" />
                CALENDAR
              </button>
              <button
                type="button"
                id="tab-rentals"
                onClick={() => { setActiveTab('rentals'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'rentals'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Package className="w-3.5 h-3.5 shrink-0 text-amber-500" />
                RENTALS
              </button>
              <button
                type="button"
                id="tab-badges"
                onClick={() => { setActiveTab('badges'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'badges'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Award className="w-3.5 h-3.5 shrink-0" />
                BADGES
              </button>
              <button
                type="button"
                id="tab-workshops"
                onClick={() => { setActiveTab('workshops'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'workshops'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Calendar className="w-3.5 h-3.5 shrink-0 text-emerald-500" />
                WORKSHOPS
              </button>
              <button
                type="button"
                id="tab-staff-hub"
                onClick={() => { setActiveTab('staff_hub'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'staff_hub'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Wrench className="w-3.5 h-3.5 shrink-0 text-indigo-500" />
                STAFF SPACE
              </button>
              <button
                type="button"
                id="tab-admin"
                onClick={() => { setActiveTab('admin'); }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-black font-bangers text-xs tracking-wide uppercase transition-all ${
                  activeTab === 'admin'
                    ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                    : 'bg-white text-black hover:bg-neutral-100'
                }`}
              >
                <Lock className="w-3.5 h-3.5 shrink-0 text-red-500 fill-red-200" />
                ADMIN PORTAL
              </button>
            </nav>
          )}
        </div>
      </header>

      {/* Primary Stage Panel */}
      <main className="max-w-7xl w-full mx-auto px-4 mt-6 flex-grow font-sans">
        {customizingStudentId !== null ? (
          <div className="space-y-4">
            <div className="bg-white border-4 border-legoyellow p-4 rounded-2xl flex items-center justify-between shadow-[6px_6px_0px_#FFD500]">
              <span className="font-bangers text-lg text-black">
                CUSTOMIZING AVATAR FOR: <strong className="text-legoblue">{activeStudent?.name}</strong>
              </span>
              <button
                type="button"
                onClick={() => setCustomizingStudentId(null)}
                className="bg-legored hover:bg-red-700 text-white border-2 border-black font-bangers text-xs px-3 py-1.5 rounded-lg active:translate-y-0.5 shadow-[2px_2px_0px_#000]"
              >
                CANCEL & RETURN
              </button>
            </div>
            
            <MinifigCreator
              initialStyle={activeStudent?.avatar}
              studentName={activeStudent?.name}
              onSave={saveCustomizedAvatar}
              onCancel={() => setCustomizingStudentId(null)}
            />
          </div>
        ) : customizingStaffId !== null ? (
          <div className="space-y-4">
            <div className="bg-white border-4 border-legoyellow p-4 rounded-2xl flex items-center justify-between shadow-[6px_6px_0px_#FFD500]">
              <span className="font-bangers text-lg text-black">
                CUSTOMIZING STAFF AVATAR FOR: <strong className="text-legoblue">{activeStaff?.name}</strong>
              </span>
              <button
                type="button"
                onClick={() => setCustomizingStaffId(null)}
                className="bg-legored hover:bg-red-700 text-white border-2 border-black font-bangers text-xs px-3 py-1.5 rounded-lg active:translate-y-0.5 shadow-[2px_2px_0px_#000]"
              >
                CANCEL & RETURN
              </button>
            </div>
            
            <MinifigCreator
              initialStyle={activeStaff?.avatar}
              studentName={activeStaff?.name}
              onSave={saveCustomizedStaffAvatar}
              onCancel={() => setCustomizingStaffId(null)}
            />
          </div>
        ) : (
          <>
            {/* Realtime Sliding LEGO Alert Bar */}
            {activeToast && (
              <div className="fixed top-20 right-6 z-50 bg-white border-4 border-black p-4 rounded-xl shadow-[6px_6px_0px_#000] max-w-sm w-full animate-bounce flex items-start gap-3 border-l-legoyellow animate-fade-in">
                <div className="bg-legoyellow border border-black p-1.5 rounded-full text-black">
                  <Bell className="w-4 h-4 animate-swing" />
                </div>
                <div>
                  <h6 className="font-bangers text-sm text-black tracking-wider uppercase leading-none mb-1">
                    LIVE PROTOCOL ALERT
                  </h6>
                  <p className="text-xs font-semibold text-neutral-600 leading-normal">
                    {activeToast.text}
                  </p>
                </div>
                <button
                  onClick={() => setActiveToast(null)}
                  className="text-neutral-400 hover:text-black shrink-0 ml-auto"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {activeTab === 'home' && (
              <HomeView
                staff={staff}
                setStaff={setStaff}
                onGoHome={() => setActiveTab('home')}
                onExploreWorkshops={() => setActiveTab('workshops')}
                onGoToCheckIn={() => setActiveTab('checkin')}
                events={events}
              />
            )}

            {activeTab === 'checkin' && (
              <CheckInStation
                students={students}
                setStudents={setStudents}
                bookings={bookings}
                setBookings={setBookings}
                onCheckIn={handleCheckIn}
                onAddStudent={handleAddStudent}
                onCustomizeAvatar={handleCustomizeAvatar}
                loggedInParentEmail={loggedInParentEmail}
                setLoggedInParentEmail={setLoggedInParentEmail}
                loggedInParentName={loggedInParentName}
                setLoggedInParentName={setLoggedInParentName}
              />
            )}

            {activeTab === 'calendar' && (
              <YearCalendar events={events} />
            )}

            {activeTab === 'rentals' && (
              loggedInParentEmail ? (
                <RentalCenter
                  students={students.filter(s => s.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim())}
                  legoSets={legoSets}
                  setLegoSets={setLegoSets}
                />
              ) : (
                <div className="bg-white border-4 border-black rounded-3xl p-8 max-w-lg mx-auto text-center shadow-[8px_8px_0px_#000] animate-fade-in my-8">
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto border-2 border-black mb-4 text-legored shadow">
                    <Lock className="w-8 h-8" />
                  </div>
                  <h3 className="font-bangers text-3xl text-black tracking-widest leading-none">PARENT HUB SIGN-IN REQUIRED</h3>
                  <p className="font-blueberry text-sm text-neutral-600 font-bold uppercase tracking-wide mt-2">
                    To rent educational LEGO sets for build time at home, you must first log in as a parent!
                  </p>
                  <p className="font-sans text-xs text-neutral-400 mt-2 max-w-sm mx-auto leading-relaxed">
                    This maps the inventory securely to your builder's registry card and tracks the return timeline.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('checkin');
                    }}
                    className="mt-6 inline-flex items-center gap-2 bg-legoyellow hover:bg-yellow-400 text-black border-2 border-black font-bangers tracking-widest text-sm py-3 px-6 rounded-xl shadow-[4px_4px_0px_#000] cursor-pointer"
                  >
                    <Smile className="w-4 h-4" />
                    GO SIGN-IN AT RECEPTION DESK
                  </button>
                </div>
              )
            )}

            {activeTab === 'badges' && (
              <BadgeBoard students={students} setStudents={setStudents} />
            )}

            {activeTab === 'workshops' && (
              <WorkshopList
                students={students}
                workshops={workshops}
                registeredWorkshops={registeredWorkshops}
                setRegisteredWorkshops={setRegisteredWorkshops}
              />
            )}

            {activeTab === 'staff_hub' && (
              <StaffHub
                staff={staff}
                setStaff={setStaff}
                tasks={tasks}
                setTasks={setTasks}
                onTaskCompleted={handleTaskCompleted}
                onStaffCheckIn={handleStaffCheckIn}
                logs={logs}
                setLogs={setLogs}
                workshops={workshops}
                setWorkshops={setWorkshops}
                registeredWorkshops={registeredWorkshops}
                setRegisteredWorkshops={setRegisteredWorkshops}
                legoSets={legoSets}
                setLegoSets={setLegoSets}
                students={students}
                setStudents={setStudents}
              />
            )}

            {activeTab === 'admin' && (
              <AdminPortal
                students={students}
                setStudents={setStudents}
                workshops={workshops}
                setWorkshops={setWorkshops}
                registeredWorkshops={registeredWorkshops}
                setRegisteredWorkshops={setRegisteredWorkshops}
                staff={staff}
                setStaff={setStaff}
                tasks={tasks}
                setTasks={setTasks}
                onStaffCheckIn={handleStaffCheckIn}
                onCustomizeStaffAvatar={handleCustomizeStaffAvatar}
                logs={logs}
                bookings={bookings}
                setBookings={setBookings}
                googleClientId={googleClientId}
                setGoogleClientId={setGoogleClientId}
                spreadsheetId={spreadsheetId}
                setSpreadsheetId={setSpreadsheetId}
                accessToken={accessToken}
                onGoogleLogin={handleGoogleLogin}
                onSyncLogs={syncLogsToGoogleSheets}
                isSyncing={isSyncing}
                notifications={notifications}
                setNotifications={setNotifications}
                isAdminLoggedIn={isAdminLoggedIn}
                setIsAdminLoggedIn={setIsAdminLoggedIn}
                events={events}
                setEvents={setEvents}
                legoSets={legoSets}
                setLegoSets={setLegoSets}
              />
            )}
          </>
        )}
      </main>

      {/* Visual background bottom toys banner decoration */}
      <footer className="mt-16 bg-slate-800 border-t-4 border-black py-4 px-8 flex flex-col sm:flex-row items-center justify-between text-white text-[10px] font-bold uppercase tracking-[0.2em] font-mono">
        <div>BRICKS & BEYOND EDUCATIONAL CENTER</div>
        <div className="flex gap-6 mt-2 sm:mt-0 font-bold font-mono">
          <span>CONNECTED TO EMBEDDED SHEET ✓</span>
          <span>VER 2.5.0</span>
        </div>
      </footer>
    </div>
  );
}
