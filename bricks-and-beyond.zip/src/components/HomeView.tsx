import React, { useState } from 'react';
import { Staff, CalendarEvent } from '../types';
import { MinifigAvatar } from './MinifigAvatar';
import { YearCalendar } from './YearCalendar';
import { Lock, Unlock, Upload, Info, Image, Plus, Trash2, ShieldCheck, Heart, Sparkles, Check, X } from 'lucide-react';

interface HomeViewProps {
  staff: Staff[];
  setStaff: React.Dispatch<React.SetStateAction<Staff[]>>;
  onGoHome: () => void;
  onExploreWorkshops: () => void;
  onGoToCheckIn: () => void;
  events: CalendarEvent[];
}

export const HomeView: React.FC<HomeViewProps> = ({
  staff,
  setStaff,
  onGoHome,
  onExploreWorkshops,
  onGoToCheckIn,
  events
}) => {
  // Passcode gate state
  const [passcode, setPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPasswordMask, setShowPasswordMask] = useState(false);
  const [imageError, setImageError] = useState(false);

  // New staff registration inside panel
  const [newStaffName, setNewStaffName] = useState('');
  const [newStaffRole, setNewStaffRole] = useState('');

  // Password retrieval log safely without display of hints
  const getStaffPasscode = (): string => {
    return localStorage.getItem('bricks_staff_password') || 'staff';
  };

  const decodeFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const correctCode = getStaffPasscode();
    const correctAdminCode = localStorage.getItem('bricks_admin_password') || 'admin';
    
    // Either the staff password or admin password can unlock the uploader!
    if (passcode === correctCode || passcode === correctAdminCode) {
      setIsUnlocked(true);
      setErrorMsg('');
      setPasscode('');
    } else {
      setIsUnlocked(false);
      setErrorMsg('INCORRECT PASSWORD! ACCESS DENIED.');
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>, staffId: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const base64 = await decodeFileToBase64(file);
      setStaff((prev) =>
        prev.map((member) => {
          if (member.id === staffId) {
            return {
              ...member,
              photoUrl: base64,
              showRealPhoto: true // default to showing the real photo once uploaded
            };
          }
          return member;
        })
      );
    } catch (err) {
      alert('Failed to upload and encode image. Please try another file.');
    }
  };

  const handleTogglePhotoDisplay = (staffId: string, showReal: boolean) => {
    setStaff((prev) =>
      prev.map((member) => {
        if (member.id === staffId) {
          return { ...member, showRealPhoto: showReal };
        }
        return member;
      })
    );
  };

  const handleUpdateStaffFields = (staffId: string, name: string, role: string) => {
    setStaff((prev) =>
      prev.map((member) => {
        if (member.id === staffId) {
          return { ...member, name, role };
        }
        return member;
      })
    );
  };

  const handleCreateStaffMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffName || !newStaffRole) {
      alert('Please fill out both Name and Role fields');
      return;
    }
    const newMember: Staff = {
      id: `staff_${Date.now()}`,
      name: newStaffName,
      role: newStaffRole,
      avatar: {
        hairType: 'classic',
        hairColor: '#78350F',
        expression: 'smile',
        torsoColor: '#EF4444',
        torsoPrint: 'brick',
        legsColor: '#1E3A8A'
      },
      checkedInToday: false
    };
    setStaff(prev => [...prev, newMember]);
    setNewStaffName('');
    setNewStaffRole('');
  };

  const handleDeleteStaffMember = (staffId: string) => {
    if (window.confirm('Are you sure you want to remove this staff member from the list?')) {
      setStaff(prev => prev.filter(member => member.id !== staffId));
    }
  };

  return (
    <div className="space-y-12 pb-12 animate-fade-in font-sans">
      
      {/* Dynamic YouTube-style Clicking Logo Header block */}
      <div className="bg-white border-4 border-black rounded-3xl p-8 shadow-[8px_8px_0px_#000] relative overflow-hidden" id="homepage-hero">
        <div className="absolute top-0 right-0 w-32 h-32 bg-legoyellow opacity-20 rounded-full blur-2xl transform translate-x-8 -translate-y-8"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-legoblue opacity-10 rounded-full blur-3xl transform -translate-x-12 translate-y-12"></div>
        
        {/* Floating LEGO studs / shapes decoration */}
        <div className="absolute top-4 left-4 flex gap-1.5 opacity-60">
          <div className="w-3.5 h-3.5 bg-legored rounded-full border border-black shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)]"></div>
          <div className="w-3.5 h-3.5 bg-legoyellow rounded-full border border-black shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)]"></div>
          <div className="w-3.5 h-3.5 bg-legogreen rounded-full border border-black shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)]"></div>
        </div>
        
        <div className="absolute top-4 right-16 flex gap-1.5 opacity-60">
          <div className="w-4 h-4 bg-legoblue rounded-lg border-2 border-black rotate-12 shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)]"></div>
        </div>
        
        <div className="relative text-center space-y-6">
          <div className="inline-block transform hover:scale-105 hover:rotate-1 transition-all duration-300">
            {/* The clickable logo requested by user */}
            {!imageError ? (
              <img 
                src="/input_file_0.png" 
                alt="Bricks & Beyond Logo"
                onError={() => setImageError(true)}
                className="max-w-[420px] w-full mx-auto select-none drop-shadow-md cursor-pointer animate-fade-in"
                onClick={onGoHome}
                title="Bricks & Beyond - Click to Go Home"
              />
            ) : (
              /* Beautiful LEGO-brick fallback is displayed cleanly if image is missing */
              <div 
                onClick={onGoHome}
                className="flex flex-col items-center justify-center p-6 border-4 border-black bg-legoyellow rounded-2xl shadow-[4px_4px_0px_#000] max-w-sm mx-auto cursor-pointer animate-fade-in select-none"
                title="Bricks & Beyond - Click to Go Home"
              >
                <div className="flex gap-1.5 mb-2">
                  <div className="w-5 h-5 bg-legored rounded border border-black shadow"></div>
                  <div className="w-5 h-5 bg-legoblue rounded border border-black shadow"></div>
                  <div className="w-5 h-5 bg-green-500 rounded border border-black shadow"></div>
                </div>
                <h3 className="font-bangers text-3xl text-black select-none tracking-widest leading-none">BRICKS & BEYOND</h3>
                <p className="text-[10px] font-mono font-bold tracking-widest text-neutral-600 uppercase mt-1">WHERE PLAY BECOMES LEARNING</p>
              </div>
            )}
          </div>

          <div className="max-w-3xl mx-auto space-y-4 pt-4 border-t-2 border-dashed border-slate-200">
            <h2 className="font-bangers text-4xl text-legored tracking-widest uppercase" style={{ textShadow: '1px 1px 0px #000' }}>
              WHO WE ARE!
            </h2>
            <p className="text-sm md:text-base leading-relaxed text-slate-800 font-medium font-sans max-w-2xl mx-auto">
              At our LEGO center, we believe kids learn best when they're having fun. Through play, 
              they build focus, problem-solving skills, and creativity. Every activity is designed for them 
              to explore, experiment, and discover. It's not about doing perfection, it's about trying, 
              rebuilding, and learning how things work. That's how kids become creative thinkers for life.
            </p>
          </div>
        </div>
      </div>

      {/* Grid elements displaying Highlights from Instragram bio */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" id="homepage-highlights-grid">
        
        {/* Item 1: STEM Center */}
        <div className="bg-white border-4 border-black p-5 rounded-2xl shadow-[5px_5px_0px_#000] relative overflow-hidden group hover:translate-y-[-2px] transition-all">
          <div className="w-10 h-3 bg-legoblue border-2 border-black rounded absolute top-2 right-2"></div>
          <h4 className="font-bangers text-xl text-legoblue tracking-wider mb-2">STEM EDUCATION</h4>
          <p className="text-xs font-semibold text-neutral-600 leading-normal">
            Hands-on LEGO STEM Learning Center focused on active scientific experimentation, motor controls, and engineering principles.
          </p>
        </div>

        {/* Item 2: English Learning */}
        <div className="bg-white border-4 border-black p-5 rounded-2xl shadow-[5px_5px_0px_#000] relative overflow-hidden group hover:translate-y-[-2px] transition-all">
          <div className="w-10 h-3 bg-legoyellow border-2 border-black rounded absolute top-2 right-2"></div>
          <h4 className="font-bangers text-xl text-emerald-700 tracking-wider mb-2">BILINGUAL BUILD</h4>
          <p className="text-xs font-semibold text-neutral-600 leading-normal">
            Learn English while creating, building, and presenting LEGO engineering blocks in an immersive natural environment.
          </p>
        </div>

        {/* Item 3: Age Range */}
        <div className="bg-white border-4 border-black p-5 rounded-2xl shadow-[5px_5px_0px_#000] relative overflow-hidden group hover:translate-y-[-2px] transition-all">
          <div className="w-10 h-3 bg-legored border-2 border-black rounded absolute top-2 right-2"></div>
          <h4 className="font-bangers text-xl text-legored tracking-wider mb-2">WHO IS IT FOR?</h4>
          <p className="text-xs font-semibold text-neutral-600 leading-normal">
            Specially tailored interactive modules for children aged 5 to 12. Safe, social, creative, and highly cooperative playtime.
          </p>
        </div>

        {/* Item 4: Headquarters */}
        <div className="bg-white border-4 border-black p-5 rounded-2xl shadow-[5px_5px_0px_#000] relative overflow-hidden group hover:translate-y-[-2px] transition-all">
          <div className="w-10 h-3 bg-neutral-800 border-2 border-black rounded absolute top-2 right-2"></div>
          <h4 className="font-bangers text-xl text-purple-700 tracking-wider mb-2">LOCATED IN COSTA RICA</h4>
          <p className="text-xs font-semibold text-neutral-600 leading-normal">
            Located in Del Rio Plaza, Santa Ana, Costa Rica! Stop by for expert-led classes and open custom free-playing sessions.
          </p>
        </div>
      </div>

      {/* Visual Creative Shelf/Brick Challenges Board */}
      <div className="bg-slate-50 border-4 border-black rounded-3xl p-6 shadow-[6px_6px_0px_rgba(0,0,0,1)] relative overflow-hidden" id="homepage-brick-challenges-shelf">
        {/* Playful side tab */}
        <div className="absolute top-0 right-0 bg-red-500 hover:bg-red-600 text-white font-bangers text-[10px] select-none tracking-widest px-3 py-1.5 rounded-bl-xl border-l-2 border-b-2 border-black flex items-center gap-1">
          <Sparkles className="w-3 h-3 animate-pulse" /> ACTIVE ZONE
        </div>

        <h3 className="font-bangers text-2xl text-black tracking-wider uppercase mb-1 flex items-center gap-2">
          THIS WEEK'S BRICK CHALLENGES
        </h3>
        <p className="text-xs font-mono font-bold text-gray-500 uppercase mb-6 leading-relaxed">
          Complete these builds at the check-in center with a coach to unlock secret badge progress points!
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border-2 border-black p-4 rounded-2xl shadow-[4px_4px_0px_rgba(0,0,0,1)] flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="bg-red-100 text-legored border border-red-300 font-mono font-black text-[9px] uppercase px-1.5 py-0.5 rounded">
                  ADVANCED
                </span>
                <span className="text-xs font-mono font-bold text-gray-400">#CHG-08</span>
              </div>
              <h4 className="font-bangers text-lg text-black tracking-wide leading-tight mb-1">
                MOUNT LEGO VOLCANO
              </h4>
              <p className="text-xs text-gray-600 font-medium leading-relaxed">
                Build a self-standing mountain volcano with a red brick lava cascade and a safety observation deck.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-gray-200 flex items-center justify-between text-[10px] font-mono font-bold text-slate-500 uppercase">
              <span>Points: 25 XP</span>
              <span className="text-legored font-black font-sans">Engineering</span>
            </div>
          </div>

          <div className="bg-white border-2 border-black p-4 rounded-2xl shadow-[4px_4px_0px_rgba(0,0,0,1)] flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="bg-blue-100 text-blue-700 border border-blue-300 font-mono font-black text-[9px] uppercase px-1.5 py-0.5 rounded">
                  INTERMEDIATE
                </span>
                <span className="text-xs font-mono font-bold text-gray-400">#CHG-09</span>
              </div>
              <h4 className="font-bangers text-lg text-black tracking-wide leading-tight mb-1">
                FLOATING SKY CASTLE
              </h4>
              <p className="text-xs text-gray-600 font-medium leading-relaxed">
                Construct a secure floating island or castle that suspends above the ground level using structural string tethers.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-gray-200 flex items-center justify-between text-[10px] font-mono font-bold text-slate-500 uppercase">
              <span>Points: 15 XP</span>
              <span className="text-blue-600 font-black font-sans">Creativity</span>
            </div>
          </div>

          <div className="bg-white border-2 border-black p-4 rounded-2xl shadow-[4px_4px_0px_rgba(0,0,0,1)] flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="bg-green-100 text-green-700 border border-green-300 font-mono font-black text-[9px] uppercase px-1.5 py-0.5 rounded">
                  BEGINNER
                </span>
                <span className="text-xs font-mono font-bold text-gray-400">#CHG-10</span>
              </div>
              <h4 className="font-bangers text-lg text-black tracking-wide leading-tight mb-1">
                RUBBER BAND ROVER
              </h4>
              <p className="text-xs text-gray-600 font-medium leading-relaxed">
                Assemble a simple wheeled vehicle powered strictly by a rubber band motor mechanism that travels over 2 meters.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-dashed border-gray-200 flex items-center justify-between text-[10px] font-mono font-bold text-slate-500 uppercase">
              <span>Points: 10 XP</span>
              <span className="text-green-600 font-black font-sans">Mechanics</span>
            </div>
          </div>
        </div>

        {/* Fun Tip Indicator */}
        <div className="bg-white border-2 border-black rounded-xl p-3 mt-4 flex items-start gap-2.5 shadow-[2px_2px_0px_rgba(0,0,0,1)]">
          <div className="bg-legoyellow border border-black p-1 rounded-lg shrink-0">
            <Sparkles className="w-4 h-4 text-black animate-spin-slow" />
          </div>
          <div className="text-xs text-gray-750">
            <span className="font-bold uppercase tracking-wider text-black block mb-0.5 font-mono">MASTER BUILDER CREDO:</span>
            "If a piece doesn't fit, don't force it — rebuild the support frame, try another color contrast, or ask a partner builder for an idea!"
          </div>
        </div>
      </div>

      {/* Interactive Year Schedule Calendar */}
      <YearCalendar events={events} />

      {/* Enrolling alert banner */}
      <div className="bg-legoyellow border-4 border-black p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4 shadow-[5px_5px_0px_#000]">
        <div className="flex items-center gap-3">
          <div className="bg-black text-legoyellow p-1.5 rounded-lg font-bangers text-sm uppercase tracking-widest spin-animation">
            NOW ENROLLING!
          </div>
          <div>
            <h5 className="font-bangers text-lg text-black leading-none uppercase">JOIN THE COSTA RICA MASTER BUILDERS HUB</h5>
            <p className="text-xs font-mono font-bold text-neutral-700 mt-1 uppercase">Limited spots left for summer tech & robotics camps • Register kids today</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={onGoToCheckIn}
            className="bg-legoblue hover:bg-blue-600 text-white font-bangers text-xs uppercase px-4 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
          >
            Check In Station
          </button>
          <button 
            onClick={onExploreWorkshops}
            className="bg-legored hover:bg-red-600 text-white font-bangers text-xs uppercase px-4 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
          >
            Explore Workshops
          </button>
        </div>
      </div>

      {/* MEET THE STAFF SECTION */}
      <div className="space-y-6" id="homepage-meet-the-staff">
        <div className="border-b-4 border-black pb-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bangers text-3xl text-black tracking-widest uppercase flex items-center gap-2">
              MEET THE STAFF TEAM
            </h3>
            <p className="text-xs font-mono font-bold text-neutral-500 uppercase">
              Bricks & Beyond Educational Play Center professional instructors and creators
            </p>
          </div>

          {/* Quick Lock toggle */}
          <button
            onClick={() => {
              if (isUnlocked) {
                setIsUnlocked(false);
              } else {
                // toggle lock input
                const el = document.getElementById('passcode-prompt-gate');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }
            }}
            className={`flex items-center gap-1 text-xs font-bold uppercase px-3 py-1.5 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] transition-colors ${
              isUnlocked ? 'bg-orange-400 text-black hover:bg-orange-500' : 'bg-neutral-800 text-white hover:bg-neutral-900'
            }`}
          >
            {isUnlocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            {isUnlocked ? 'LOCK MANAGE' : 'MANAGE TEAM PHOTOS'}
          </button>
        </div>

        {/* Staff Showcase grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {staff.map((member) => (
            <div 
              key={member.id} 
              className={`bg-white border-4 border-black rounded-3xl p-6 shadow-[6px_6px_0px_#000] flex flex-col items-center justify-between text-center relative overflow-hidden ${
                member.checkedInToday ? 'ring-4 ring-emerald-500 ring-offset-2' : ''
              }`}
            >
              {/* Check-in badge marker */}
              <span className={`absolute top-3 left-3 text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border border-black uppercase ${
                member.checkedInToday ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-100 text-neutral-400'
              }`}>
                {member.checkedInToday ? 'Checked In' : 'Checked Out'}
              </span>

              {/* Staff Member Portrait Area */}
              <div className="my-4 relative group flex items-center justify-center">
                {member.showRealPhoto && member.photoUrl ? (
                  <div className="w-32 h-32 rounded-full border-4 border-black overflow-hidden bg-slate-100 shadow-md transform group-hover:scale-105 transition-all">
                    <img 
                      src={member.photoUrl} 
                      alt={member.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="bg-slate-50 border-4 border-black rounded-3xl p-4 w-32 h-32 flex items-center justify-center transform group-hover:scale-105 transition-all">
                    <MinifigAvatar style={member.avatar} size={100} />
                  </div>
                )}
                
                {/* Mini badge icon at bottom corner */}
                <div className="absolute -bottom-1 -right-1 bg-legoyellow border-2 border-black rounded-full p-1.5 shadow">
                  <Sparkles className="w-3.5 h-3.5 text-black" />
                </div>
              </div>

              {/* Profile Meta text */}
              <div className="space-y-1">
                <h4 className="font-bangers text-2xl text-slate-900 tracking-wider leading-none mt-2">{member.name}</h4>
                <p className="text-[11px] font-mono font-bold text-neutral-500 uppercase tracking-widest">{member.role}</p>
              </div>

              {/* Toggle real vs minifig if unlocked or if real photo exists */}
              {member.photoUrl && (
                <div className="mt-4 flex gap-1 bg-slate-100 border border-slate-300 p-1 rounded-xl text-[10px] font-mono leading-none">
                  <button
                    onClick={() => handleTogglePhotoDisplay(member.id, false)}
                    className={`px-2 py-1 rounded-lg font-bold uppercase transition-colors ${
                      !member.showRealPhoto ? 'bg-black text-white' : 'bg-transparent text-neutral-600 hover:bg-slate-200'
                    }`}
                  >
                    Lego
                  </button>
                  <button
                    onClick={() => handleTogglePhotoDisplay(member.id, true)}
                    className={`px-2 py-1 rounded-lg font-bold uppercase transition-colors ${
                      member.showRealPhoto ? 'bg-black text-white' : 'bg-transparent text-neutral-600 hover:bg-slate-200'
                    }`}
                  >
                    Photo
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* PASSWORD GATE PROMPT (No hints shown) */}
        {!isUnlocked && (
          <div className="max-w-md mx-auto bg-slate-50 border-4 border-black rounded-3xl p-6 shadow-[5px_5px_0px_#000] space-y-4 pt-5" id="passcode-prompt-gate">
            <div className="text-center">
              <Lock className="w-8 h-8 text-neutral-700 mx-auto mb-2" />
              <h5 className="font-bangers text-xl text-black uppercase tracking-wider">STAFF PHOTO PORTAL LOCK</h5>
              <p className="text-[10px] font-mono font-bold text-neutral-500 uppercase">Enter staff code to upload photos and customize team cards</p>
            </div>

            <form onSubmit={handlePasscodeSubmit} className="space-y-3">
              <div className="relative">
                <input
                  type={showPasswordMask ? 'text' : 'password'}
                  placeholder="Enter passcode..."
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full bg-white border-2 border-black rounded-xl px-4 py-2.5 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-legoyellow font-mono text-center"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPasswordMask(!showPasswordMask)}
                  className="text-neutral-500 hover:text-black absolute right-3.5 top-3.5 text-xs font-mono font-bold uppercase select-none"
                >
                  {showPasswordMask ? 'HIDE' : 'SHOW'}
                </button>
              </div>

              {errorMsg && (
                <div className="bg-red-50 border border-red-300 text-red-600 rounded-xl p-2 text-center text-xs font-bold uppercase font-mono">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-black hover:bg-neutral-800 text-white font-bangers text-xs uppercase tracking-widest py-2.5 border-2 border-black rounded-xl shadow-[2px_2px_0px_#000] active:translate-y-0.5"
              >
                UNLOCK PHOTO EDITOR
              </button>
            </form>
          </div>
        )}

        {/* STAFF MANAGEMENT PANEL (Unlocked) */}
        {isUnlocked && (
          <div className="bg-amber-50/50 border-4 border-dashed border-amber-500 rounded-3xl p-6 shadow-[6px_6px_0px_#F59E0B] space-y-6 animate-fade-in">
            <div className="flex items-start justify-between gap-4 border-b border-dashed border-amber-300 pb-3">
              <div>
                <h4 className="font-bangers text-2xl text-amber-900 tracking-wider flex items-center gap-2 uppercase">
                  <ShieldCheck className="w-6 h-6 text-amber-500" />
                  STAFF TEAM PORTRAIT & DETAIL CUSTOMIZER
                </h4>
                <p className="text-[10px] font-mono font-bold text-amber-700 uppercase">
                  ADMINISTRATIVE ACCESS ACTIVE • UPLOAD STAFF MEMBER PHOTOS & CHANGE LABELS
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsUnlocked(false)}
                className="bg-black hover:bg-neutral-900 text-white font-bold text-xs px-3 py-1.5 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
              >
                Lock Controls
              </button>
            </div>

            {/* Individual uploads/modifications */}
            <div className="space-y-4">
              {staff.map((member) => (
                <div key={member.id} className="bg-white border-2 border-black rounded-2xl p-4 flex flex-col md:flex-row items-center gap-4 shadow-sm font-sans justify-between">
                  
                  <div className="flex flex-col sm:flex-row items-center gap-4 flex-grow w-full md:w-auto">
                    {/* Tiny visual badge avatar */}
                    <div className="w-16 h-16 rounded-xl border-2 border-black bg-slate-50 flex items-center justify-center shrink-0 overflow-hidden">
                      {member.photoUrl ? (
                        <img src={member.photoUrl} alt="Real Profile" className="w-full h-full object-cover" />
                      ) : (
                        <MinifigAvatar style={member.avatar} size={50} />
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-grow max-w-lg w-full">
                      <div className="space-y-1">
                        <label className="text-[9px] font-mono font-bold text-neutral-400 uppercase">STAFF FULL NAME</label>
                        <input
                          type="text"
                          value={member.name}
                          onChange={(e) => handleUpdateStaffFields(member.id, e.target.value, member.role)}
                          className="w-full bg-slate-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold focus:bg-white"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-mono font-bold text-neutral-400 uppercase">ASSIGNED ROLE / TITLE</label>
                        <input
                          type="text"
                          value={member.role}
                          onChange={(e) => handleUpdateStaffFields(member.id, member.name, e.target.value)}
                          className="w-full bg-slate-50 border border-neutral-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold focus:bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Actions area */}
                  <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 w-full sm:w-auto">
                    
                    {/* Upload real Photo Button */}
                    <div className="relative w-full sm:w-auto">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handlePhotoUpload(e, member.id)}
                        className="absolute inset-0 opacity-0 w-full h-full cursor-pointer z-10"
                        id={`file_input_${member.id}`}
                      />
                      <button
                        type="button"
                        className="w-full sm:w-auto flex items-center justify-center gap-1 bg-slate-100 hover:bg-slate-200 text-neutral-800 text-xs font-bold uppercase px-3 py-2 border-2 border-black rounded-lg shadow"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        {member.photoUrl ? 'Replace Photo' : 'Upload photo'}
                      </button>
                    </div>

                    {/* Delete Photo option if exists */}
                    {member.photoUrl && (
                      <button
                        type="button"
                        onClick={() => {
                          setStaff(prev =>
                            prev.map((m) => {
                              if (m.id === member.id) {
                                return { ...m, photoUrl: undefined, showRealPhoto: false };
                              }
                              return m;
                            })
                          );
                        }}
                        className="w-full sm:w-auto text-xs font-semibold text-red-500 hover:text-red-700 bg-red-50 hover:bg-red-100 px-2.5 py-2 border border-red-200 rounded-lg uppercase"
                      >
                        Remove Photo
                      </button>
                    )}

                    {/* Delete Member Option */}
                    <button
                      type="button"
                      onClick={() => handleDeleteStaffMember(member.id)}
                      className="w-full sm:w-auto bg-red-50 hover:bg-red-100 border border-red-300 text-red-600 rounded-lg p-2 hover:border-red-400"
                      title="Delete profile"
                    >
                      <Trash2 className="w-4 h-4 mx-auto" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* REGISTER NEW MEMBER BLOCK */}
            <div className="bg-white border-2 border-black p-5 rounded-2xl max-w-md mx-auto shadow-sm">
              <h5 className="font-bangers text-lg text-black mb-3 border-b border-dashed pb-1 uppercase">
                ADD NEW STAFF INSTRUCTOR
              </h5>
              <form onSubmit={handleCreateStaffMember} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-neutral-500 uppercase">INSTRUCTOR FULL NAME</label>
                  <input
                    type="text"
                    placeholder="Enter full name (e.g. Coach Brandon)..."
                    value={newStaffName}
                    onChange={(e) => setNewStaffName(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-neutral-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-mono font-bold text-neutral-500 uppercase">ASSIGNED ROLE / SPECIALIZATION</label>
                  <input
                    type="text"
                    placeholder="Enter specialty (e.g. Lead Robotic Coach)..."
                    value={newStaffRole}
                    onChange={(e) => setNewStaffRole(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-neutral-300 rounded-xl px-3 py-2 text-xs font-semibold"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bangers text-xs uppercase tracking-wider py-2.5 border-2 border-black rounded-xl shadow-[2px_2px_0px_#000]"
                >
                  <Plus className="w-4 h-4" /> APPEND NEW STAFF MEMBER
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
