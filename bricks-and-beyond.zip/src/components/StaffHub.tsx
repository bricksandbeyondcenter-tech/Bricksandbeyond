import React, { useState } from 'react';
import { Staff, DailyTask, MinifigStyle, CheckInLog, Workshop, LegoSet, Student } from '../types';
import { MinifigAvatar } from './MinifigAvatar';
import { EmbeddedSpreadsheet } from './EmbeddedSpreadsheet';
import { 
  Clock, 
  CheckSquare, 
  Square, 
  Calendar, 
  Check, 
  Smile, 
  Award, 
  Plus, 
  RefreshCw,
  Hourglass,
  CalendarDays,
  Play,
  Lock,
  Unlock,
  LogOut,
  Filter,
  Users,
  Edit3,
  Trash2,
  Package,
  Wrench,
  Key,
  X
} from 'lucide-react';

interface StaffHubProps {
  staff: Staff[];
  setStaff: React.Dispatch<React.SetStateAction<Staff[]>>;
  tasks: DailyTask[];
  setTasks: React.Dispatch<React.SetStateAction<DailyTask[]>>;
  onTaskCompleted: (task: DailyTask, completedByStaff: Staff) => void;
  onStaffCheckIn: (staffId: string, isCheckIn: boolean) => void;
  logs: CheckInLog[];
  setLogs: React.Dispatch<React.SetStateAction<CheckInLog[]>>;
  workshops: Workshop[];
  setWorkshops: React.Dispatch<React.SetStateAction<Workshop[]>>;
  registeredWorkshops: { [key: string]: string[] };
  setRegisteredWorkshops: React.Dispatch<React.SetStateAction<{ [key: string]: string[] }>>;
  legoSets: LegoSet[];
  setLegoSets: React.Dispatch<React.SetStateAction<LegoSet[]>>;
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
}

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const;

export const StaffHub: React.FC<StaffHubProps> = ({
  staff,
  setStaff,
  tasks,
  setTasks,
  onTaskCompleted,
  onStaffCheckIn,
  logs,
  setLogs,
  workshops,
  setWorkshops,
  registeredWorkshops,
  setRegisteredWorkshops,
  legoSets,
  setLegoSets,
  students,
  setStudents
}) => {
  // Authentication Form States
  const [typedName, setTypedName] = useState<string>('');
  const [typedPassword, setTypedPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [loginError, setLoginError] = useState<string>('');

  const [selectedStaffId, setSelectedStaffId] = useState<string>(() => {
    return localStorage.getItem('bricks_active_staff_id') || '';
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return !!localStorage.getItem('bricks_active_staff_id') && localStorage.getItem('bricks_staff_logged_in') === 'true';
  });

  // Toggle filter to see all chores or only their individual assigned tasks
  const [showAllTasks, setShowAllTasks] = useState<boolean>(false);
  const [spreadsheetLogsFilter, setSpreadsheetLogsFilter] = useState<'staff' | 'students'>('staff');

  // Staff Sub-Panel State (Tasks vs. Workshops vs. Rentals vs. Parents)
  const [staffActivePanel, setStaffActivePanel] = useState<'tasks' | 'workshops' | 'rentals' | 'parents'>('tasks');

  // Workshop states inside StaffHub
  const [editingWorkshopId, setEditingWorkshopId] = useState<string | null>(null);
  const [showAddWorkshopModal, setShowAddWorkshopModal] = useState<boolean>(false);
  const [workshopForm, setWorkshopForm] = useState<Omit<Workshop, 'id'>>({
    title: '',
    description: '',
    date: 'Saturday, June 20th',
    time: '2:00 PM - 4:00 PM',
    minAge: 6,
    spotsLeft: 8,
    price: '$25 / session',
    tag: 'Creative Play',
  });

  // Rental inventory states inside StaffHub
  const [editingLegoSetId, setEditingLegoSetId] = useState<string | null>(null);
  const [showAddLegoSetModal, setShowAddLegoSetModal] = useState<boolean>(false);
  const [legoSetForm, setLegoSetForm] = useState<Omit<LegoSet, 'id'>>({
    name: '',
    theme: 'City',
    pieces: 250,
    difficulty: 'Beginner',
    rented: false,
  });

  const handleCreateWorkshop = (e: React.FormEvent) => {
    e.preventDefault();
    const newWk: Workshop = {
      id: 'wk_' + Math.random().toString(36).substring(2, 11),
      ...workshopForm
    };
    setWorkshops(prev => [...prev, newWk]);
    setShowAddWorkshopModal(false);
    resetWorkshopForm();
  };

  const triggerEditWorkshop = (wk: Workshop) => {
    setEditingWorkshopId(wk.id);
    setWorkshopForm({
      title: wk.title,
      description: wk.description,
      date: wk.date,
      time: wk.time,
      minAge: wk.minAge,
      spotsLeft: wk.spotsLeft,
      price: wk.price,
      tag: wk.tag,
    });
    setShowAddWorkshopModal(true);
  };

  const handleSaveWorkshopEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWorkshopId) return;

    setWorkshops(prev => prev.map(wk => {
      if (wk.id === editingWorkshopId) {
        return {
          ...wk,
          ...workshopForm
        };
      }
      return wk;
    }));

    setEditingWorkshopId(null);
    setShowAddWorkshopModal(false);
    resetWorkshopForm();
  };

  const handleDeleteWorkshop = (id: string) => {
    if (window.confirm('Are you sure you want to delete this workshop?')) {
      setWorkshops(prev => prev.filter(wk => wk.id !== id));
      setRegisteredWorkshops(prev => {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      });
    }
  };

  const resetWorkshopForm = () => {
    setWorkshopForm({
      title: '',
      description: '',
      date: 'Saturday, June 20th',
      time: '2:00 PM - 4:00 PM',
      minAge: 6,
      spotsLeft: 8,
      price: '$25 / session',
      tag: 'Creative Play',
    });
  };

  const handleCreateLegoSet = (e: React.FormEvent) => {
    e.preventDefault();
    const newSet: LegoSet = {
      id: 'set_' + Math.random().toString(36).substring(2, 11),
      ...legoSetForm
    };
    setLegoSets(prev => [...prev, newSet]);
    setShowAddLegoSetModal(false);
    resetLegoSetForm();
  };

  const triggerEditLegoSet = (s: LegoSet) => {
    setEditingLegoSetId(s.id);
    setLegoSetForm({
      name: s.name,
      theme: s.theme,
      pieces: s.pieces,
      difficulty: s.difficulty,
      rented: s.rented,
      rentedByStudentId: s.rentedByStudentId,
      rentedByStudentName: s.rentedByStudentName,
      rentedDate: s.rentedDate,
      parentEmail: s.parentEmail,
    });
    setShowAddLegoSetModal(true);
  };

  const handleSaveLegoSetEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLegoSetId) return;

    setLegoSets(prev => prev.map(s => {
      if (s.id === editingLegoSetId) {
        return {
          ...s,
          ...legoSetForm
        };
      }
      return s;
    }));

    setEditingLegoSetId(null);
    setShowAddLegoSetModal(false);
    resetLegoSetForm();
  };

  const handleDeleteLegoSet = (id: string) => {
    if (window.confirm('Are you sure you want to delete this LEGO set from inventory?')) {
      setLegoSets(prev => prev.filter(s => s.id !== id));
    }
  };

  const handleReturnLegoSet = (id: string) => {
    if (window.confirm('Register return of this LEGO set? It will be marked as available.')) {
      setLegoSets(prev => prev.map(s => {
        if (s.id === id) {
          return {
            ...s,
            rented: false,
            rentedByStudentId: undefined,
            rentedByStudentName: undefined,
            rentedDate: undefined,
            parentEmail: undefined,
          };
        }
        return s;
      }));
    }
  };

  const resetLegoSetForm = () => {
    setLegoSetForm({
      name: '',
      theme: 'City',
      pieces: 250,
      difficulty: 'Beginner',
      rented: false,
    });
  };

  // Current day view state
  const [currentDay, setCurrentDay] = useState<string>(() => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const idx = new Date().getDay();
    return days[idx];
  });

  // Manual hours add input
  const [manualHoursInput, setManualHoursInput] = useState<string>('');
  const [hoursFeedback, setHoursFeedback] = useState<string>('');
  const [taskDisclaimer, setTaskDisclaimer] = useState<string>('');

  const activeStaff = staff.find(s => s.id === selectedStaffId);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    if (!typedName.trim()) {
      setLoginError('PLEASE ENTER YOUR STAFF NAME');
      return;
    }

    // Match case insensitively & trimmed
    const matched = staff.find(
      s => s.name.trim().toLowerCase() === typedName.trim().toLowerCase()
    );

    if (!matched) {
      setLoginError(`STAFF MEMBER "${typedName.toUpperCase()}" NOT FOUND IN DIRECTORY.`);
      return;
    }

    const individualPassword = matched.password || localStorage.getItem('bricks_staff_password') || 'staff';
    if (typedPassword !== individualPassword) {
      setLoginError('INCORRECT PASSWORD. PLEASE TRY AGAIN.');
      return;
    }

    // Success login!
    setSelectedStaffId(matched.id);
    setIsLoggedIn(true);
    localStorage.setItem('bricks_active_staff_id', matched.id);
    localStorage.setItem('bricks_staff_logged_in', 'true');
    setTypedName('');
    setTypedPassword('');
    setHoursFeedback('Authenticated successfully! Welcome back.');
    setTaskDisclaimer('');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setSelectedStaffId('');
    localStorage.removeItem('bricks_active_staff_id');
    localStorage.setItem('bricks_staff_logged_in', 'false');
    setShowAllTasks(false);
    setHoursFeedback('');
    setTaskDisclaimer('');
    setLoginError('');
  };

  const handleSelectStaff = (id: string) => {
    setSelectedStaffId(id);
    localStorage.setItem('bricks_active_staff_id', id);
    setHoursFeedback('');
    setManualHoursInput('');
    setTaskDisclaimer('');
  };

  const handleClockInOut = () => {
    if (!activeStaff) return;

    const isClockingIn = !activeStaff.clockedIn;
    const nowISO = new Date().toISOString();

    setStaff(prev => prev.map(member => {
      if (member.id === activeStaff.id) {
        let updatedHours = member.hoursWorked || 0;
        let shiftStart = member.shiftStartTimestamp;

        if (!isClockingIn && shiftStart) {
          // Clocking out: calculate elapsed decimal hours
          const elapsedMs = Date.now() - new Date(shiftStart).getTime();
          const elapsedHours = parseFloat((elapsedMs / (1000 * 60 * 60)).toFixed(2));
          updatedHours = parseFloat((updatedHours + elapsedHours).toFixed(2));
          setHoursFeedback(`Added +${elapsedHours} hours automatically to your timesheet!`);
          shiftStart = undefined;
        } else if (isClockingIn) {
          shiftStart = nowISO;
          setHoursFeedback("Clocked in successfully! Have an awesome shift.");
        }

        return {
          ...member,
          clockedIn: isClockingIn,
          shiftStartTimestamp: shiftStart,
          hoursWorked: updatedHours,
          checkedInToday: isClockingIn ? true : member.checkedInToday
        };
      }
      return member;
    }));

    // Trigger main center staff check in log
    onStaffCheckIn(activeStaff.id, isClockingIn);
  };

  const handleUpdateHoursManually = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStaff || !manualHoursInput) return;

    const parsed = parseFloat(manualHoursInput);
    if (isNaN(parsed)) {
      alert("Please enter a valid number for hours");
      return;
    }

    setStaff(prev => prev.map(member => {
      if (member.id === activeStaff.id) {
        const updated = parseFloat(((member.hoursWorked || 0) + parsed).toFixed(2));
        return {
          ...member,
          hoursWorked: updated < 0 ? 0 : updated
        };
      }
      return member;
    }));

    setHoursFeedback(`Manually updated timesheet of ${activeStaff.name} by ${parsed > 0 ? '+' : ''}${parsed} hours.`);
    setManualHoursInput('');
  };

  const handleToggleTask = (task: DailyTask) => {
    if (!activeStaff) {
      setTaskDisclaimer("PLEASE CLICK YOUR NAME ON THE LEFT TO LOG IN FIRST!");
      return;
    }

    // Check if the task is assigned to a specific person
    if (task.assignedTo) {
      const isAssignedToMe = task.assignedTo === activeStaff.id || task.assignedTo === activeStaff.name;
      if (!isAssignedToMe) {
        const assignedName = staff.find(s => s.id === task.assignedTo || s.name === task.assignedTo)?.name || task.assignedTo;
        setTaskDisclaimer(`ACCESS DENIED: This task is specifically assigned to ${assignedName.toUpperCase()}. Only they can complete it!`);
        return;
      }
    }

    setTaskDisclaimer('');
    const nextCompleted = !task.completed;

    setTasks(prev => prev.map(t => {
      if (t.id === task.id) {
        return {
          ...t,
          completed: nextCompleted,
          completedBy: nextCompleted ? activeStaff.name : undefined,
          completedAt: nextCompleted ? new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined
        };
      }
      return t;
    }));

    if (nextCompleted) {
      onTaskCompleted(task, activeStaff);
    }
  };

  // Filter tasks to show those for selected day + 'All Days' and match logged-in coach (or show all if toggled)
  const filteredTasks = tasks.filter(task => {
    // Must match the selected day
    const dayMatch = task.day === currentDay || task.day === 'All Days';
    if (!dayMatch) return false;

    // Filter by assignment if showAllTasks is false
    if (!showAllTasks && activeStaff) {
      const isAssignedToMe = task.assignedTo === activeStaff.id || task.assignedTo === activeStaff.name;
      const isGeneralChore = !task.assignedTo || task.assignedTo === 'All' || task.assignedTo === '';
      return isAssignedToMe || isGeneralChore;
    }

    return true; // if showAllTasks is true, show all chores for that day
  });

  // Login Gate
  if (!isLoggedIn || !activeStaff) {
    return (
      <div className="max-w-md mx-auto space-y-6 py-6 font-sans">
        <div className="bg-white border-4 border-black rounded-3xl p-6 shadow-[8px_8px_0px_#000] relative overflow-hidden">
          {/* Top yellow brick aesthetic strip */}
          <div className="absolute top-0 inset-x-0 h-4 bg-legoyellow border-b-4 border-black"></div>
          
          <div className="text-center pt-4 space-y-2">
            <div className="bg-slate-100 border-4 border-black inline-block p-4 rounded-2xl relative">
              <Lock className="w-10 h-10 text-slate-800" />
              <div className="bg-red-500 w-3 h-3 absolute top-2 right-2 rounded-full border border-black animate-ping"></div>
            </div>
            
            <h1 className="font-bangers text-3xl tracking-wider text-black mt-3">
              STAFF SPACE GATE
            </h1>
            <p className="text-xs font-mono font-bold text-gray-400 uppercase tracking-wide">
              AUTHENTICATE TO ACCESS YOUR INDIVIDUAL PROFILE &amp; TASKS
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 mt-6">
            <div className="space-y-1.5 text-left">
              <label className="block text-[10px] font-mono font-black text-neutral-500 uppercase tracking-widest">
                COACH / INSTRUCTOR NAME
              </label>
              <input
                type="text"
                placeholder="e.g. Tutor Clara or Coach Brandon"
                value={typedName}
                onChange={(e) => setTypedName(e.target.value)}
                className="w-full bg-slate-50 border-2 border-black rounded-xl px-4 py-3 text-xs font-semibold focus:outline-none focus:bg-white font-mono"
                required
              />
              <p className="text-[10px] text-gray-400 font-medium">
                Enter your exact name as stored in the roster database.
              </p>
            </div>

            <div className="space-y-1.5 text-left">
              <div className="flex justify-between items-center">
                <label className="block text-[10px] font-mono font-black text-neutral-500 uppercase tracking-widest">
                  SYSTEM PASSWORD
                </label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-[10px] font-mono font-bold uppercase text-neutral-600 hover:text-black focus:outline-none"
                >
                  {showPassword ? 'Hide' : 'Show'}
                </button>
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="Default password is 'staff'..."
                value={typedPassword}
                onChange={(e) => setTypedPassword(e.target.value)}
                className="w-full bg-slate-50 border-2 border-black rounded-xl px-4 py-3 text-sm font-semibold focus:outline-none focus:bg-white font-mono tracking-wide"
                required
              />
            </div>

            {loginError && (
              <div className="bg-red-50 border-2 border-dashed border-red-500 text-red-600 rounded-xl p-3 text-center text-[11px] font-bold uppercase font-mono leading-normal">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-black hover:bg-neutral-800 text-white font-bangers text-sm uppercase tracking-widest py-3 border-2 border-black rounded-2xl shadow-[4px_4px_0px_rgba(0,0,0,1)] hover:shadow-[2px_2px_0px_rgba(0,0,0,1)] active:translate-y-0.5 active:shadow-none transition-all cursor-pointer"
            >
              AUTHENTICATE &amp; LOG IN
            </button>
          </form>

          {/* Help box */}
          <div className="mt-6 pt-4 border-t-2 border-dashed border-gray-150 text-left font-mono text-[10px] text-gray-500">
            <span className="font-bold uppercase text-black block mb-0.5">NEED PASSWORD OR ACCOUNT CREATION?</span>
            Add or manage staff directly from the <span className="font-extrabold text-indigo-600 uppercase">Admin Portal</span>. The current system staff password can be set by the Director.
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-legoblue to-indigo-600 text-white p-6 rounded-2xl border-4 border-black shadow-[6px_6px_0px_#000] relative overflow-hidden">
        <div className="absolute right-0 top-0 w-32 h-32 bg-white/10 rounded-full translate-x-12 -translate-y-12"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <span className="bg-yellow-400 text-black text-[10px] font-black uppercase px-2.5 py-1 rounded-md border-2 border-black inline-block mb-2 font-mono">
              STAFF SPACE • LOGGED IN
            </span>
            <h1 className="font-bangers text-3xl md:text-4xl tracking-wide">
              WELCOME BACK, {activeStaff.name.toUpperCase()}!
            </h1>
            <p className="text-sm font-medium opacity-90 max-w-xl font-mono mt-1">
              Currently managing individual shift tools &amp; assigned creative center checklists.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2 shrink-0">
            <button
              onClick={handleLogout}
              className="bg-black hover:bg-neutral-850 text-white font-bangers text-xs uppercase px-3.5 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#fff] active:translate-y-0.5 active:shadow-[1px_1px_0px_#fff] flex items-center gap-1.5 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              Sign Out Hub
            </button>
            <div className="bg-black/30 p-2.5 rounded-lg border border-white/20 text-right font-mono text-[10px]">
              <span className="text-yellow-300 font-bold block uppercase">Center Live Date:</span>
              <span className="font-bold text-white">
                {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: ACTIVE ACCOUNT DETAILS & TIMECARD (lg:span-5) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000]">
            <h2 className="font-bangers text-xl text-black mb-3 flex items-center gap-2 border-b-2 border-dashed border-neutral-200 pb-2">
              <Smile className="w-5 h-5 text-legoyellow fill-yellow-200" />
              1. ACTIVE ACCOUNT PROFILE
            </h2>
            
            <div className="bg-neutral-50 p-4 border-2 border-black rounded-xl space-y-3 relative overflow-hidden">
              <div className="absolute top-2 right-2 flex gap-1">
                <span className="bg-indigo-100 text-indigo-800 border border-indigo-200 font-mono text-[9px] font-black px-1.5 rounded uppercase">
                  COACH SESSION
                </span>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-16 h-16 border-4 border-black rounded-xl overflow-hidden shrink-0 bg-white flex items-center justify-center shadow-sm">
                  <MinifigAvatar style={activeStaff.avatar} size={60} />
                </div>
                <div className="min-w-0">
                  <div className="font-bangers text-xl text-black truncate leading-tight">{activeStaff.name}</div>
                  <div className="text-[11px] text-neutral-500 font-mono font-bold uppercase tracking-wider truncate mb-1">
                    {activeStaff.role}
                  </div>
                  <div className="flex items-center gap-1">
                    {activeStaff.clockedIn ? (
                      <span className="bg-emerald-500 text-white font-mono text-[9px] font-black uppercase px-2 py-0.5 rounded border border-black animate-pulse">
                        ON SHIFT
                      </span>
                    ) : (
                      <span className="bg-neutral-200 text-neutral-600 font-mono text-[9px] font-black uppercase px-2 py-0.5 rounded border border-neutral-300">
                        OFF SHIFT
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="border-t border-dashed border-neutral-300 pt-3 flex justify-between items-center bg-white rounded-lg p-2.5 border border-neutral-200">
                <div className="font-mono text-xs text-neutral-500 font-semibold">Total Hours log this period:</div>
                <div className="font-bangers text-lg text-indigo-700 bg-indigo-50 px-2 py-0.5 border border-indigo-200 rounded">
                  {activeStaff.hoursWorked || 0} Hours
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] space-y-4">
            <h2 className="font-bangers text-xl text-black flex items-center gap-2 border-b-2 border-dashed border-neutral-200 pb-2">
              <Clock className="w-5 h-5 text-legoblue" />
              2. SHIFT TIME CARD
            </h2>

            {/* Status block */}
            <div className="flex items-center justify-between p-3 bg-neutral-50 rounded-xl border border-neutral-200 font-mono text-xs">
              <div>
                <span className="text-neutral-500 font-bold block text-left">CURRENT STATUS:</span>
                <span className={`text-sm font-extrabold flex items-center ${activeStaff.clockedIn ? "text-green-600 animate-pulse" : "text-red-500"}`}>
                  <span className={`w-2 h-2 rounded-full mr-1.5 ${activeStaff.clockedIn ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
                  {activeStaff.clockedIn ? "ACTIVE ON-DUTY" : "CLOCKED OUT"}
                </span>
              </div>
              {activeStaff.clockedIn && activeStaff.shiftStartTimestamp && (
                <div className="text-right">
                  <span className="text-neutral-500 font-bold block">SHIFT STARTED:</span>
                  <span className="font-bold text-black">
                    {new Date(activeStaff.shiftStartTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              )}
            </div>

            {/* Time Actions Panel */}
            <div className="space-y-3">
              <button
                type="button"
                onClick={handleClockInOut}
                className={`w-full py-3 px-4 font-bangers text-lg border-2 border-black rounded-xl shadow-[3px_3px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all flex items-center justify-center gap-2 cursor-pointer ${
                  activeStaff.clockedIn
                    ? 'bg-red-500 hover:bg-red-600 text-white'
                    : 'bg-green-500 hover:bg-green-600 text-white'
                }`}
              >
                <Clock className="w-5 h-5 shrink-0" />
                {activeStaff.clockedIn ? "TAP TO CLOCK OUT (SAVE HOURS)" : "TAP TO CLOCK IN"}
              </button>

              {hoursFeedback && (
                <p className="bg-yellow-50 text-indigo-900 border border-yellow-300 rounded-lg p-2.5 font-mono text-xs font-bold leading-relaxed text-left">
                  {hoursFeedback}
                </p>
              )}

              {/* Direct Manual Shift logging */}
              <form onSubmit={handleUpdateHoursManually} className="pt-2 border-t border-neutral-100">
                <label className="block text-[11px] font-mono font-bold text-neutral-500 uppercase tracking-wide mb-1.5 label text-left">
                  MANUALLY LOG / UPDATE SHIFT HOURS (E.G. +4.5 or -2.0)
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="e.g. 4.5"
                    value={manualHoursInput}
                    onChange={(e) => setManualHoursInput(e.target.value)}
                    className="flex-grow rounded-lg border-2 border-neutral-300 font-mono text-sm px-3 py-1.5 focus:border-black outline-none"
                  />
                  <button
                    type="submit"
                    className="bg-legoblue text-white font-bangers text-xs px-4 py-2 border-2 border-black rounded-lg shadow-[2px_2px_0px_#000] hover:bg-blue-600 active:translate-y-0.5 cursor-pointer"
                  >
                    LOG HOURS
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: STAFF DASHBOARD SUBPANELS (lg:span-7) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Subpanel Tab Bar */}
          <div className="flex gap-2 max-w-full overflow-x-auto p-1 bg-slate-100 border-2 border-black rounded-xl">
            <button
              type="button"
              onClick={() => setStaffActivePanel('tasks')}
              className={`flex-1 min-w-[125px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border-2 border-black font-bangers text-[11px] tracking-wide uppercase transition-all cursor-pointer ${
                staffActivePanel === 'tasks'
                  ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000]'
                  : 'bg-white text-gray-700 hover:bg-neutral-50'
              }`}
            >
              <CheckSquare className="w-4 h-4 shrink-0 text-red-500" />
              My Checklists
            </button>
            <button
              type="button"
              onClick={() => setStaffActivePanel('workshops')}
              className={`flex-1 min-w-[125px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border-2 border-black font-bangers text-[11px] tracking-wide uppercase transition-all cursor-pointer ${
                staffActivePanel === 'workshops'
                  ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000]'
                  : 'bg-white text-gray-700 hover:bg-neutral-50'
              }`}
            >
              <CalendarDays className="w-4 h-4 shrink-0 text-emerald-500" />
              Manage Workshops
            </button>
            <button
              type="button"
              onClick={() => setStaffActivePanel('rentals')}
              className={`flex-1 min-w-[125px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border-2 border-black font-bangers text-[11px] tracking-wide uppercase transition-all cursor-pointer ${
                staffActivePanel === 'rentals'
                  ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000]'
                  : 'bg-white text-gray-700 hover:bg-neutral-50'
              }`}
            >
              <Package className="w-4 h-4 shrink-0 text-indigo-500" />
              Manage Rental Sets
            </button>
            <button
              type="button"
              onClick={() => setStaffActivePanel('parents')}
              className={`flex-1 min-w-[125px] flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg border-2 border-black font-bangers text-[11px] tracking-wide uppercase transition-all cursor-pointer ${
                staffActivePanel === 'parents'
                  ? 'bg-legoyellow text-black shadow-[2px_2px_0px_#000]'
                  : 'bg-white text-gray-700 hover:bg-neutral-50'
              }`}
            >
              <Key className="w-4 h-4 shrink-0 text-amber-500" />
              Parent Passwords
            </button>
          </div>

          {/* TAB 1: DAILY CHORES & TASKS */}
          {staffActivePanel === 'tasks' && (
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] flex-grow">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b-2 border-dashed border-neutral-200 pb-3 mb-4">
                <h2 className="font-bangers text-xl text-black flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-legored" />
                  3. TODAY'S CHECKLISTS &amp; TASKS
                </h2>
                
                {/* Day filter selector */}
                <select
                  value={currentDay}
                  onChange={(e) => setCurrentDay(e.target.value)}
                  className="bg-neutral-100 font-mono text-xs font-black uppercase text-neutral-700 px-3 py-1.5 rounded-lg border-2 border-black tracking-wide"
                >
                  {DAYS_OF_WEEK.map(d => (
                    <option key={d} value={d}>{d.toUpperCase()}</option>
                  ))}
                </select>
              </div>

              {/* Filter Toggle for Tasks */}
              <div className="bg-slate-50 border border-neutral-200 p-2.5 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-2.5 mb-4 text-left font-sans">
                <div className="font-mono text-xs font-bold text-gray-650 flex items-center gap-1">
                  <Filter className="w-3.5 h-3.5 text-gray-500 shrink-0" />
                  <span>TASK PERSPECTIVE FILTER:</span>
                </div>
                <div className="flex gap-1.5 bg-neutral-200 p-1 rounded-xl w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={() => setShowAllTasks(false)}
                    className={`flex-1 sm:flex-none text-[10px] font-mono font-black uppercase px-3 py-1 rounded-lg border transition-all cursor-pointer ${
                      !showAllTasks 
                        ? 'bg-black text-white border-black shadow-sm' 
                        : 'bg-white text-gray-600 border-neutral-250 hover:bg-neutral-100'
                    }`}
                  >
                    My Individual Tasks
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAllTasks(true)}
                    className={`flex-1 sm:flex-none text-[10px] font-mono font-black uppercase px-3 py-1 rounded-lg border transition-all cursor-pointer ${
                      showAllTasks 
                        ? 'bg-black text-white border-black shadow-sm' 
                        : 'bg-white text-gray-600 border-neutral-250 hover:bg-neutral-100'
                    }`}
                  >
                    All Center Chores
                  </button>
                </div>
              </div>

              <p className="text-[11px] text-neutral-500 font-mono font-normal tracking-wide mb-4 leading-relaxed text-left">
                {showAllTasks 
                  ? `Showing general chores and student helper schedules requested for ${currentDay}.` 
                  : `Showing chores and team challenges assigned specifically to YOU (${activeStaff.name}) or open to all coaches on ${currentDay}.`}
              </p>

              {taskDisclaimer && (
                <div className="bg-red-50 p-3 rounded-xl border-2 border-red-500 font-mono font-black text-[11px] text-red-650 uppercase tracking-wide mb-4 animate-pulse text-left leading-normal">
                  {taskDisclaimer}
                </div>
              )}

              {/* Task Checklist Lists */}
              {filteredTasks.length === 0 ? (
                <div className="bg-neutral-50 rounded-xl border border-dashed border-neutral-300 py-12 px-4 text-center font-mono text-xs font-bold text-neutral-500">
                  No tasks scheduled for {currentDay} matching your selected filter.
                </div>
              ) : (
                <div className="space-y-2.5 font-sans">
                  {filteredTasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task)}
                      className={`flex items-start gap-3 p-3.5 rounded-xl border-2 cursor-pointer transition-all ${
                        task.completed
                          ? 'bg-green-50 border-green-500/60 opacity-80'
                          : 'bg-white border-black hover:bg-neutral-50 shadow-[2px_2px_0px_#000] hover:translate-x-0.5'
                      }`}
                    >
                      <button
                        type="button"
                        className="mt-0.5 shrink-0 focus:outline-none"
                      >
                        {task.completed ? (
                          <div className="w-5 h-5 bg-green-500 border-2 border-black rounded flex items-center justify-center text-white">
                            <Check className="w-3.5 h-3.5 stroke-[3px]" />
                          </div>
                        ) : (
                          <div className="w-5 h-5 bg-white border-2 border-black rounded hover:bg-neutral-100"></div>
                        )}
                      </button>

                      <div className="min-w-0 flex-grow text-left">
                        <span className={`text-xs md:text-sm font-bold text-black ${task.completed ? 'line-through text-neutral-400 font-normal' : ''}`}>
                          {task.text}
                        </span>
                        <div className="flex flex-wrap items-center gap-2 mt-1">
                          <span className="bg-neutral-100 text-[9px] font-mono font-black text-neutral-500 border border-neutral-200 rounded px-1.5 py-0.2 uppercase font-mono">
                            {task.day}
                          </span>
                          {task.assignedTo && (
                            <span className="bg-indigo-50 text-indigo-700 text-[9px] font-mono font-black border border-indigo-200 rounded px-1.5 py-0.2 uppercase font-mono">
                              Coach: {staff.find(s => s.id === task.assignedTo || s.name === task.assignedTo)?.name || task.assignedTo}
                            </span>
                          )}
                          {task.completed && (
                            <span className="bg-green-100 text-green-700 text-[9px] font-mono font-black px-2 py-0.5 rounded flex items-center gap-1 font-mono">
                              ✓ Done by {task.completedBy} at {task.completedAt || 'today'}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: WORKSHOP OPERATIONS */}
          {staffActivePanel === 'workshops' && (
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] space-y-4 text-left">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b-2 border-dashed border-neutral-200 pb-3">
                <div>
                  <h2 className="font-bangers text-xl text-black flex items-center gap-2">
                    <CalendarDays className="w-5 h-5 text-emerald-600" />
                    COACH WORKSHOP MANAGER
                  </h2>
                  <p className="text-[10px] font-mono font-bold text-neutral-500 uppercase">
                    Publish or modify upcoming holiday camps, robotics challenges, and architecture labs.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    resetWorkshopForm();
                    setEditingWorkshopId(null);
                    setShowAddWorkshopModal(true);
                  }}
                  className="bg-emerald-650 hover:bg-emerald-700 text-white font-bangers text-xs uppercase px-3.5 py-2 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 cursor-pointer"
                >
                  + Publish Workshop
                </button>
              </div>

              {/* Add/Edit Workshop Modal inside StaffHub */}
              {showAddWorkshopModal && (
                <div className="bg-slate-50 border-4 border-black rounded-xl p-4 shadow-sm">
                  <h4 className="font-bangers text-lg text-black mb-3">
                    {editingWorkshopId ? 'EDIT WORKSHOP DETAILS' : 'PUBLISH NEW WORKSHOP'}
                  </h4>
                  <form onSubmit={editingWorkshopId ? handleSaveWorkshopEdit : handleCreateWorkshop} className="space-y-3 font-sans">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Title *</label>
                        <input
                          type="text"
                          required
                          value={workshopForm.title}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, title: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                          placeholder="e.g. Minecraft Brick Build"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Tag / Category *</label>
                        <input
                          type="text"
                          required
                          value={workshopForm.tag}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, tag: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                          placeholder="e.g. Robotics, Architecture"
                        />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Description *</label>
                      <textarea
                        required
                        value={workshopForm.description}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, description: e.target.value }))}
                        className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold h-16 resize-none"
                        placeholder="Explain the building goals and educational core components..."
                      />
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Date *</label>
                        <input
                          type="text"
                          required
                          value={workshopForm.date}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, date: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Time *</label>
                        <input
                          type="text"
                          required
                          value={workshopForm.time}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, time: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Min Age *</label>
                        <input
                          type="number"
                          required
                          value={workshopForm.minAge}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, minAge: parseInt(e.target.value) || 5 }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Total Spots *</label>
                        <input
                          type="number"
                          required
                          value={workshopForm.spotsLeft}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, spotsLeft: parseInt(e.target.value) || 8 }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Price / Option *</label>
                        <input
                          type="text"
                          required
                          value={workshopForm.price}
                          onChange={(e) => setWorkshopForm(prev => ({ ...prev, price: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        />
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end pt-3 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={() => {
                          setShowAddWorkshopModal(false);
                          setEditingWorkshopId(null);
                        }}
                        className="px-3.5 py-1.5 border-2 border-black rounded-lg text-[11px] font-mono font-bold uppercase hover:bg-gray-150"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg border-2 border-black text-[11px] font-mono font-black uppercase shadow-[2px_2px_0px_#000] active:translate-y-0.5"
                      >
                        {editingWorkshopId ? 'Save Changes' : 'Publish Workshop'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Workshops Grid lists */}
              {workshops.length === 0 ? (
                <div className="bg-slate-50 border border-dashed border-neutral-300 rounded-xl p-8 text-center font-mono text-xs font-bold text-neutral-500">
                  No registered upcoming workshops.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-sans text-left">
                  {workshops.map(wk => {
                    const registered = registeredWorkshops[wk.id] || [];
                    const spotsRem = Math.max(0, wk.spotsLeft - registered.length);
                    return (
                      <div key={wk.id} className="bg-white border-2 border-black rounded-xl p-4 shadow-[3px_3px_0px_#000] flex flex-col justify-between">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between border-b border-dashed border-neutral-100 pb-2">
                            <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                              {wk.tag}
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => triggerEditWorkshop(wk)}
                                className="bg-white hover:bg-slate-50 border border-neutral-300 p-1 rounded-lg cursor-pointer"
                                title="Edit"
                              >
                                <Edit3 className="w-3.5 h-3.5 text-legoblue" />
                              </button>
                              <button
                                onClick={() => handleDeleteWorkshop(wk.id)}
                                className="bg-white hover:bg-red-50 border border-neutral-300 p-1 rounded-lg cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-legored" />
                              </button>
                            </div>
                          </div>

                          <div>
                            <h4 className="font-bangers text-lg text-black leading-tight uppercase">{wk.title}</h4>
                            <p className="text-[11px] text-neutral-500 font-semibold mt-0.5 leading-snug">{wk.description}</p>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-[9px] font-mono font-black uppercase text-neutral-600 bg-slate-50 rounded-lg p-2">
                            <div>Date: {wk.date}</div>
                            <div>Time: {wk.time}</div>
                            <div>Age: {wk.minAge}+</div>
                            <div className="text-emerald-700">Price: {wk.price}</div>
                          </div>
                        </div>

                        <div className="text-[10px] font-mono font-bold text-neutral-500 mt-4 border-t border-slate-100 pt-2">
                          RESERVATIONS: <strong className="text-emerald-600 font-extrabold">{registered.length} Registered</strong> ({spotsRem} spots left)
                          {registered.length > 0 && (
                            <span className="block mt-1 text-slate-400 truncate">Attendees: {registered.join(', ')}</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: LEGO RENTAL SET MANAGEMENT */}
          {staffActivePanel === 'rentals' && (
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] space-y-4 text-left">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b-2 border-dashed border-neutral-200 pb-3">
                <div>
                  <h2 className="font-bangers text-xl text-black flex items-center gap-2">
                    <Package className="w-5 h-5 text-indigo-600" />
                    COACH RENTAL INVENTORY TRACKER
                  </h2>
                  <p className="text-[10px] font-mono font-bold text-neutral-500 uppercase">
                    Track rented packages, return sets to available stock, or add high-difficulty boxes.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    resetLegoSetForm();
                    setEditingLegoSetId(null);
                    setShowAddLegoSetModal(true);
                  }}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-bangers text-xs uppercase px-3.5 py-2 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 cursor-pointer"
                >
                  + Add LEGO Set
                </button>
              </div>

              {/* Add/Edit LEGO Set Modal inside StaffHub */}
              {showAddLegoSetModal && (
                <div className="bg-slate-50 border-4 border-black rounded-xl p-4 shadow-sm">
                  <h4 className="font-bangers text-lg text-black mb-3">
                    {editingLegoSetId ? 'EDIT LEGO SET DETAILS' : 'ADD NEW SPECIALTY LEGO SET'}
                  </h4>
                  <form onSubmit={editingLegoSetId ? handleSaveLegoSetEdit : handleCreateLegoSet} className="space-y-3 font-sans">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Set Name *</label>
                        <input
                          type="text"
                          required
                          value={legoSetForm.name}
                          onChange={(e) => setLegoSetForm(prev => ({ ...prev, name: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                          placeholder="e.g. Star Wars Millennium Falcon"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Theme Series *</label>
                        <input
                          type="text"
                          required
                          value={legoSetForm.theme}
                          onChange={(e) => setLegoSetForm(prev => ({ ...prev, theme: e.target.value }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                          placeholder="e.g. Technic, Star Wars"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Number of Pieces *</label>
                        <input
                          type="number"
                          required
                          value={legoSetForm.pieces}
                          onChange={(e) => setLegoSetForm(prev => ({ ...prev, pieces: parseInt(e.target.value) || 100 }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="block text-[10px] font-mono font-bold text-gray-500 uppercase">Build Difficulty *</label>
                        <select
                          value={legoSetForm.difficulty}
                          onChange={(e) => setLegoSetForm(prev => ({ ...prev, difficulty: e.target.value as any }))}
                          className="w-full bg-white border-2 border-black rounded-lg px-2 py-1 text-xs font-semibold"
                        >
                          <option value="Beginner">Beginner</option>
                          <option value="Intermediate">Intermediate</option>
                          <option value="Master">Master</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex gap-2 justify-end pt-3 border-t border-slate-200">
                      <button
                        type="button"
                        onClick={() => {
                          setShowAddLegoSetModal(false);
                          setEditingLegoSetId(null);
                        }}
                        className="px-3.5 py-1.5 border-2 border-black rounded-lg text-[11px] font-mono font-bold uppercase hover:bg-gray-150"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg border-2 border-black text-[11px] font-mono font-black uppercase shadow-[2px_2px_0px_#000] active:translate-y-0.5"
                      >
                        {editingLegoSetId ? 'Save Changes' : 'Add to Catalog'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Lego Sets Catalog Roster */}
              {legoSets.length === 0 ? (
                <div className="bg-slate-50 border border-dashed border-neutral-300 rounded-xl p-8 text-center font-mono text-xs font-bold text-neutral-500">
                  No LEGO sets listed in inventory.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-sans text-left">
                  {legoSets.map(set => {
                    return (
                      <div key={set.id} className="bg-white border-2 border-black rounded-xl p-4 shadow-[3px_3px_0px_#000] flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between border-b border-dashed border-neutral-100 pb-2 mb-2">
                            <span className="bg-indigo-50 text-indigo-800 border border-indigo-200 text-[10px] font-mono font-bold px-2 py-0.5 rounded uppercase">
                              {set.theme}
                            </span>
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => triggerEditLegoSet(set)}
                                className="bg-white hover:bg-slate-50 border border-neutral-300 p-1 rounded-lg cursor-pointer"
                                title="Edit"
                              >
                                <Edit3 className="w-3.5 h-3.5 text-legoblue" />
                              </button>
                              <button
                                onClick={() => handleDeleteLegoSet(set.id)}
                                className="bg-white hover:bg-red-50 border border-neutral-300 p-1 rounded-lg cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5 text-legored" />
                              </button>
                            </div>
                          </div>

                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-bangers text-lg text-black leading-tight uppercase">{set.name}</h4>
                              <p className="text-[10px] text-neutral-400 font-semibold mt-0.5 font-mono uppercase">
                                Diff: <strong className="text-black font-extrabold">{set.difficulty}</strong> | {set.pieces} pcs
                              </p>
                            </div>
                            {set.rented ? (
                              <span className="bg-red-100 text-red-800 border border-red-200 text-[9px] font-mono font-black px-1.5 py-0.5 rounded uppercase">
                                Rented
                              </span>
                            ) : (
                              <span className="bg-green-100 text-green-800 border border-green-200 text-[9px] font-mono font-black px-1.5 py-0.5 rounded uppercase">
                                Active
                              </span>
                            )}
                          </div>
                        </div>

                        {set.rented ? (
                          <div className="bg-red-50 border border-red-200 rounded-lg p-2.5 text-[10px] font-mono font-semibold space-y-0.5 mt-3">
                            <div className="text-red-750 font-black">CURRENT RENTER INFO:</div>
                            <div>Builder: <strong>{set.rentedByStudentName?.toUpperCase()}</strong></div>
                            <div>Parent: <strong>{set.parentEmail}</strong></div>
                            <div>Out: <strong>{set.rentedDate}</strong></div>
                            
                            <button
                              type="button"
                              onClick={() => handleReturnLegoSet(set.id)}
                              className="mt-2 w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bangers tracking-wider text-[10px] py-1.5 rounded border border-black shadow-[1px_1px_0px_#000] active:translate-y-0.5 cursor-pointer"
                            >
                              ✓ REGISTER RETURN
                            </button>
                          </div>
                        ) : (
                          <p className="text-[10px] font-mono font-bold text-emerald-600 mt-4">
                            ✓ READY FOR CHECK-OUT
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {staffActivePanel === 'parents' && (
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] space-y-4 text-left">
              <div>
                <h2 className="font-bangers text-xl text-black flex items-center gap-2">
                  <Key className="w-5 h-5 text-amber-500" />
                  PARENT PASSWORD REGISTRY
                </h2>
                <p className="text-[10px] font-mono font-bold text-neutral-500 uppercase">
                  Staff access to assist parents who forgot their passwords or need to reset credentials.
                </p>
              </div>

              <div className="border-t-2 border-dashed border-neutral-200 pt-4">
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-100 border-b-2 border-black">
                        <th className="p-2 font-black uppercase text-neutral-600">Student Name</th>
                        <th className="p-2 font-black uppercase text-neutral-600">Parent Name</th>
                        <th className="p-2 font-black uppercase text-neutral-600">Parent Email</th>
                        <th className="p-2 font-black uppercase text-neutral-600 text-right">Login Password</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {students.map((student) => (
                        <tr key={student.id} className="hover:bg-slate-50">
                          <td className="p-2 font-bold text-black">{student.name}</td>
                          <td className="p-2 text-neutral-700">{student.parentName}</td>
                          <td className="p-2 text-neutral-500">{student.parentEmail}</td>
                          <td className="p-2 text-right">
                            <input
                              type="text"
                              value={student.parentPassword || 'password'}
                              onChange={(e) => {
                                const newPass = e.target.value;
                                setStudents((prev) =>
                                  prev.map((s) =>
                                    s.id === student.id ? { ...s, parentPassword: newPass } : s
                                  )
                                );
                              }}
                              className="border-2 border-black rounded px-2 py-1 text-xs font-mono font-black text-amber-600 bg-amber-50 focus:bg-white w-40 text-right"
                            />
                          </td>
                        </tr>
                      ))}
                      {students.length === 0 && (
                        <tr>
                          <td colSpan={4} className="p-4 text-center text-gray-400">
                            No students registered.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

      </div>

      {/* 4. Staff Spreadsheet Hub */}
      <div className="pt-6 border-t-4 border-dashed border-neutral-300 space-y-4">
        <div className="bg-slate-50 border-4 border-black rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <h4 className="font-bangers text-xl text-black uppercase tracking-wider">
              STAFF SPREADSHEET PORTAL
            </h4>
            <p className="text-xs font-mono font-bold text-neutral-500 uppercase">
              Toggle between Coach workhours and Student attendance grids to view, edit, download or back up.
            </p>
          </div>
          <div className="flex gap-2 bg-neutral-200 p-1 rounded-xl w-full md:w-auto">
            <button
              type="button"
              onClick={() => setSpreadsheetLogsFilter('staff')}
              className={`flex-1 md:flex-none text-[11px] font-mono font-black uppercase px-4 py-2 rounded-lg border transition-all cursor-pointer ${
                spreadsheetLogsFilter === 'staff'
                  ? 'bg-emerald-600 text-white border-black shadow-sm'
                  : 'bg-white text-gray-600 border-neutral-250 hover:bg-neutral-100'
              }`}
            >
              COACH SHIFT RECORDS
            </button>
            <button
              type="button"
              onClick={() => setSpreadsheetLogsFilter('students')}
              className={`flex-1 md:flex-none text-[11px] font-mono font-black uppercase px-4 py-2 rounded-lg border transition-all cursor-pointer ${
                spreadsheetLogsFilter === 'students'
                  ? 'bg-indigo-600 text-white border-black shadow-sm'
                  : 'bg-white text-gray-600 border-neutral-250 hover:bg-neutral-100'
              }`}
            >
              STUDENT ATTENDANCE RECORDS
            </button>
          </div>
        </div>

        <EmbeddedSpreadsheet logs={logs} setLogs={setLogs} logsFilter={spreadsheetLogsFilter} />
      </div>
    </div>
  );
};
