import React from 'react';
import { MinifigStyle } from '../types';

interface MinifigAvatarProps {
  style: MinifigStyle;
  size?: number;
  className?: string;
}

export const MinifigAvatar: React.FC<MinifigAvatarProps> = ({ style, size = 100, className = "" }) => {
  const { hairType, hairColor, expression, torsoColor, torsoPrint, legsColor } = style;

  // Render expression SVGs
  const renderExpression = () => {
    switch (expression) {
      case 'wink':
        return (
          <g id="exp-wink">
            {/* Playful wink on Left, Starry-gleam eye on Right */}
            {/* Left winking eye arc */}
            <path d="M 14 24 Q 18 20 22 24" stroke="#1E293B" strokeWidth="3" fill="none" strokeLinecap="round" />
            
            {/* Right eye - Large anime-style eye with dual highlights */}
            <circle cx="32" cy="23" r="4" fill="#1E293B" />
            <circle cx="30.5" cy="21.5" r="1.3" fill="#FFFFFF" />
            <circle cx="33.5" cy="24.5" r="0.7" fill="#FFFFFF" />
            
            {/* Rosy cheeks for dopamine appeal */}
            <circle cx="14" cy="29" r="3.5" fill="#FF5A79" opacity="0.65" />
            <circle cx="34" cy="29" r="3.5" fill="#FF5A79" opacity="0.65" />

            {/* Mischievous smile with cheeky pink tongue peeking out */}
            <path d="M 17 30 Q 23 37 29 29.5" stroke="#1E293B" strokeWidth="3.5" fill="none" strokeLinecap="round" />
            <path d="M 21 33.2 Q 23 38 25 33.2" fill="#FF5A79" stroke="#1E293B" strokeWidth="1" />
          </g>
        );
      case 'cool':
        return (
          <g id="exp-cool">
            {/* Cyberpunk high-tempo Gradient Sunglasses */}
            <defs>
              <linearGradient id="cool-sunglasses-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#EC4899" />
                <stop offset="50%" stopColor="#8B5CF6" />
                <stop offset="100%" stopColor="#3B82F6" />
              </linearGradient>
            </defs>
            {/* Sunglasses frame backing */}
            <path d="M 10 19 L 40 19 L 37 26 C 35 29 27 29 26 24 L 24 24 C 23 29 15 29 13 26 Z" fill="#000000" />
            {/* Neon lenses */}
            <path d="M 11 20 L 39 20 L 36 25 C 34 28 28 28 27 23 L 23 23 C 22 28 16 28 14 25 Z" fill="url(#cool-sunglasses-grad)" />
            {/* Pure white diagonal sheen speedlines */}
            <line x1="13" y1="21" x2="19" y2="21" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="28" y1="21" x2="34" y2="21" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" />
            {/* Highlights over the nose bridge */}
            <line x1="23" y1="21" x2="27" y2="21" stroke="#000000" strokeWidth="2.5" />
            {/* Cocky smirk */}
            <path d="M 16 32 Q 22 36 29 30.5" stroke="#1E293B" strokeWidth="3.5" fill="none" strokeLinecap="round" />
          </g>
        );
      case 'glasses':
        return (
          <g id="exp-glasses">
            {/* Elegant Tech Specs with semi-transparent glossy lenses */}
            {/* Semi-transparent blue reflections inside glasses */}
            <circle cx="17" cy="24" r="6.5" fill="#38BDF8" opacity="0.3" />
            <circle cx="33" cy="24" r="6.5" fill="#38BDF8" opacity="0.3" />
            
            {/* Outer frames */}
            <circle cx="17" cy="24" r="6.5" stroke="#000000" strokeWidth="2.5" fill="none" />
            <circle cx="33" cy="24" r="6.5" stroke="#000000" strokeWidth="2.5" fill="none" />
            <line x1="23.5" y1="24" x2="26.5" y2="24" stroke="#000000" strokeWidth="2.5" />
            
            {/* Cute eyes peeking through glasses */}
            <circle cx="17" cy="24" r="1.8" fill="#1E293B" />
            <circle cx="16.3" cy="23.3" r="0.6" fill="#FFFFFF" />
            
            <circle cx="33" cy="24" r="1.8" fill="#1E293B" />
            <circle cx="32.3" cy="23.3" r="0.6" fill="#FFFFFF" />
            
            {/* Happy blushing spots */}
            <ellipse cx="11" cy="28.5" rx="2" ry="1.2" fill="#FF5A79" opacity="0.5" />
            <ellipse cx="39" cy="28.5" rx="2" ry="1.2" fill="#FF5A79" opacity="0.5" />
            
            {/* Generous open smile */}
            <path d="M 18 31.5 Q 25 38 32 31.5" stroke="#1E293B" strokeWidth="3" fill="none" strokeLinecap="round" />
          </g>
        );
      case 'determined':
        return (
          <g id="exp-determined">
            {/* Sporty builder athletic headband with a gear emblem on head */}
            <rect x="11" y="14" width="28" height="6.5" fill="#EF4444" stroke="#000" strokeWidth="1.2" />
            {/* Tie ribbons of headband sticking out left side */}
            <path d="M 11 16 L 4 13 L 6 18 Z" fill="#EF4444" stroke="#000" strokeWidth="1" />
            
            {/* Action brows */}
            <path d="M 12 21.5 L 21 23.5" stroke="#1E293B" strokeWidth="2.8" strokeLinecap="round" />
            <path d="M 38 21.5 L 29 23.5" stroke="#1E293B" strokeWidth="2.8" strokeLinecap="round" />
            
            {/* Focused starry eyes */}
            <circle cx="17" cy="26" r="3.2" fill="#1E293B" />
            <polygon points="17,24 17.5,25.5 19,26 17.5,26.5 17,28 16.5,26.5 15,26 16.5,25.5" fill="#FFFFFF" />

            <circle cx="33" cy="26" r="3.2" fill="#1E293B" />
            <polygon points="33,24 33.5,25.5 35,26 33.5,26.5 33,28 32.5,26.5 31,26 32.5,25.5" fill="#FFFFFF" />
            
            {/* Confident firm smirk */}
            <path d="M 19 33.5 L 31 33.5" stroke="#1E293B" strokeWidth="3.2" strokeLinecap="round" />
          </g>
        );
      case 'smile':
      default:
        return (
          <g id="exp-smile">
            {/* Classic but extra lively LEGO face */}
            {/* Expressive happy eyebrows */}
            <path d="M 13 18.5 Q 17 17 21 18.5" stroke="#1E293B" strokeWidth="2.2" fill="none" strokeLinecap="round" />
            <path d="M 29 18.5 Q 33 17 37 18.5" stroke="#1E293B" strokeWidth="2.2" fill="none" strokeLinecap="round" />
            
            {/* Big friendly sparkling eyes */}
            <circle cx="17.5" cy="23.5" r="3.2" fill="#1E293B" />
            <circle cx="16.2" cy="22.2" r="1" fill="#FFFFFF" />
            <circle cx="18.5" cy="24.5" r="0.5" fill="#FFFFFF" />
            
            <circle cx="32.5" cy="23.5" r="3.2" fill="#1E293B" />
            <circle cx="31.2" cy="22.2" r="1" fill="#FFFFFF" />
            <circle cx="33.5" cy="24.5" r="0.5" fill="#FFFFFF" />

            {/* Glowing cute cheeks */}
            <circle cx="13" cy="28.5" r="3" fill="#F43F5E" opacity="0.45" />
            <circle cx="37" cy="28.5" r="3" fill="#F43F5E" opacity="0.45" />

            {/* Broad joyful smile */}
            <path d="M 17 30 Q 25 38.5 33 30" stroke="#1E293B" strokeWidth="3.2" fill="none" strokeLinecap="round" />
          </g>
        );
    }
  };

  // Render detailed torso prints
  const renderTorsoDecoration = () => {
    switch (torsoPrint) {
      case 'classic-space':
        return (
          <g transform="translate(14, 46) scale(0.45)" id="print-space">
            {/* Metallic Golden Orbit Ring */}
            <ellipse cx="25" cy="25" rx="22" ry="6" fill="none" stroke="#FBBF24" strokeWidth="3" transform="rotate(-15 25 25)" />
            {/* Retro planet sphere */}
            <circle cx="21" cy="26" r="10" fill="#F59E0B" stroke="#000" strokeWidth="1" />
            {/* Miniature sleek red spaceship charging ahead */}
            <path d="M 32 15 L 42 10 L 37 22 Z" fill="#EF4444" stroke="#000" strokeWidth="1" />
            <circle cx="35" cy="14" r="1.5" fill="#FFF" />
          </g>
        );
      case 'brick':
        return (
          <g transform="translate(14, 46) scale(0.48)" id="print-brick">
            {/* Detailed 3D Lego Studded Brick decal */}
            <rect x="10" y="12" width="30" height="20" rx="3" fill="#FF2E42" stroke="#000000" strokeWidth="2.5" />
            {/* brick depth shadow */}
            <rect x="12" y="27" width="26" height="3" fill="#B91C1C" />
            {/* 4 distinct detailed round studs */}
            <rect x="14" y="6" width="8" height="6" rx="1.5" fill="#FF2E42" stroke="#000000" strokeWidth="2" />
            <rect x="28" y="6" width="8" height="6" rx="1.5" fill="#FF2E42" stroke="#000000" strokeWidth="2" />
            <circle cx="18" cy="9" r="1" fill="#FFAAAA" />
            <circle cx="32" cy="9" r="1" fill="#FFAAAA" />
          </g>
        );
      case 'ninja':
        return (
          <g transform="translate(13, 46) scale(0.48)" id="print-ninja">
            {/* Detailed crossed shiny silver swords */}
            <line x1="4" y1="4" x2="42" y2="42" stroke="#000000" strokeWidth="4.5" strokeLinecap="round" />
            <line x1="4" y1="4" x2="42" y2="42" stroke="#E2E8F0" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="4" cy="4" r="2.5" fill="#FBBF24" stroke="#000" strokeWidth="1" />

            <line x1="42" y1="4" x2="4" y2="42" stroke="#000000" strokeWidth="4.5" strokeLinecap="round" />
            <line x1="42" y1="4" x2="4" y2="42" stroke="#E2E8F0" strokeWidth="2.5" strokeLinecap="round" />
            <circle cx="42" cy="4" r="2.5" fill="#FBBF24" stroke="#000" strokeWidth="1" />

            {/* Golden emblem wrap-belt */}
            <circle cx="23" cy="24" r="12" fill="#FBBF24" stroke="#000" strokeWidth="2.2" />
            {/* Tiny crisp throwing star symbol */}
            <polygon points="23,17 25,22 30,23 25,25 23,30 21,25 16,23 21,22" fill="#1C1917" />
          </g>
        );
      case 'heart':
        return (
          <g transform="translate(13, 46) scale(0.48)" id="print-heart">
            {/* Double nested neon heart */}
            <path d="M 23 15 Q 16 7 11 15 Q 5 22 23 38 Q 41 22 35 15 Q 30 7 23 15 Z" fill="#FF5A79" stroke="#000000" strokeWidth="2.5" />
            <path d="M 23 19 Q 18 13 14 19 Q 10 24 23 34 Q 36 24 32 19 Q 28 13 23 19 Z" fill="#EF4444" />
            {/* Glossy reflection line inside heart */}
            <path d="M 31 16 Q 34 19 32 24" stroke="#FFFFFF" strokeWidth="2" strokeLinecap="round" fill="none" opacity="0.6" />
          </g>
        );
      case 'tie':
        return (
          <g transform="translate(14, 44) scale(0.45)" id="print-tie">
            {/* Classy crisp collar flaps */}
            <polygon points="8,1 18,17 21,1" fill="#FFFFFF" stroke="#000" strokeWidth="1.8" />
            <polygon points="34,1 24,17 21,1" fill="#FFFFFF" stroke="#000" strokeWidth="1.8" />
            {/* Bold red-crimson striped necktie */}
            <polygon points="17,17 25,17 28,42 21,47 14,42" fill="#FF2E42" stroke="#000" strokeWidth="1.8" />
            {/* Gold tie clip bar */}
            <line x1="16" y1="28" x2="26" y2="28" stroke="#FBBF24" strokeWidth="2.5" strokeLinecap="round" />
            {/* Diagonal crisp stripes */}
            <line x1="16" y1="22" x2="23" y2="25" stroke="#FFFFFF" strokeWidth="1.8" />
            <line x1="15" y1="34" x2="25" y2="38" stroke="#FFFFFF" strokeWidth="1.8" />
          </g>
        );
      case 'none':
      default:
        return null;
    }
  };

  // Render high-character Hair/Hat paths
  const renderHairOrHat = () => {
    switch (hairType) {
      case 'spiky':
        return (
          <g fill={hairColor} stroke="#000000" strokeWidth="1.8" id="hair-spiky">
            {/* Advanced detailed spiky hair outline */}
            <path d="M 4 17 
                     C 2 11, 6 6, 8 4 
                     L 11 9 
                     C 12 4, 16 1, 18 1 
                     L 21 8
                     C 22 2, 27 0, 29 0 
                     L 31 8
                     C 32 3, 37 1, 39 3 
                     L 40 10
                     C 42 5, 46 8, 48 11
                     L 46 19 L 42 16 L 38 18 C 34 14, 16 14, 12 17 L 8 15 Z" />
            {/* Highlight overlay */}
            <path d="M 9 6 L 11 10 M 19 4 L 21 8 M 29 3 L 31 7" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
          </g>
        );
      case 'long':
        return (
          <g fill={hairColor} stroke="#000000" strokeWidth="1.8" id="hair-long">
            {/* Beautiful voluminous layered hair locks */}
            {/* Behind base */}
            <path d="M 4 16 L 3 36 C 3 40, 9 40, 9 36 L 9 16 Z" />
            <path d="M 46 16 L 47 36 C 47 40, 41 40, 41 36 L 41 16 Z" />
            {/* Front volume */}
            <path d="M 6 16 C 5 7, 45 7, 44 16 C 42 18, 38 18, 36 15 C 32 10, 18 10, 14 15 C 12 18, 8 18, 6 16 Z" />
            {/* Lock curves details */}
            <path d="M 12 12 Q 25 7 38 12" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.3" />
            <path d="M 7 24 Q 6 32 8 36" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.3" />
            <path d="M 43 24 Q 44 32 42 36" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.3" />
          </g>
        );
      case 'cap':
        return (
          <g id="hair-cap">
            {/* High-contrast cool sideways baseball cap */}
            {/* Cap Dome dome body */}
            <path d="M 7 17 C 8 4, 42 4, 43 17 Z" fill={hairColor} stroke="#000000" strokeWidth="1.8" />
            {/* Stylish dynamic cap visor extending to right */}
            <path d="M 37 13 L 53 14 Q 54 18 36 19.5 Z" fill={hairColor} stroke="#000000" strokeWidth="1.8" />
            {/* Visual stitching lines */}
            <path d="M 25 4 L 25 17 M 12 9 Q 25 14 38 9" stroke="#000" strokeWidth="1" strokeDasharray="2,2" opacity="0.4" fill="none" />
            <ellipse cx="25" cy="5" rx="3.2" ry="1.8" fill="#FFFFFF" opacity="0.35" />
          </g>
        );
      case 'helmet':
        return (
          <g id="hair-helmet">
            {/* Deep Retro Space exploration helmet with reflections */}
            {/* Back pack tubes */}
            <path d="M 13 -2 L 37 -2" stroke={hairColor} strokeWidth="4" strokeLinecap="round" />
            {/* Outer strong heavy safety rim */}
            <circle cx="25" cy="18" r="22.5" fill="none" stroke="#000000" strokeWidth="1.8" />
            <circle cx="25" cy="18" r="21" fill="none" stroke={hairColor} strokeWidth="5" />
            {/* Soft glass screen base */}
            <circle cx="25" cy="18" r="16" fill="#38BDF8" opacity="0.2" />
            {/* Exquisite diagonal shiny glass bubble curves */}
            <path d="M 14 10 A 16 16 0 0 1 36 10" fill="none" stroke="#FFFFFF" strokeWidth="2.5" strokeLinecap="round" opacity="0.75" />
            <path d="M 16 28 A 16 16 0 0 0 34 28" fill="none" stroke="#FFFFFF" strokeWidth="1" strokeLinecap="round" opacity="0.4" />
          </g>
        );
      case 'wizard':
        return (
          <g id="hair-wizard">
            {/* Beautiful starry violet wizard cone hat with brim */}
            <polygon points="25,-14 3,14 47,14" fill="#6D28D9" stroke="#000000" strokeWidth="2" />
            <ellipse cx="25" cy="14" rx="25.5" ry="4.5" fill="#4C1D95" stroke="#000000" strokeWidth="2" />
            
            {/* Golden Ribbon band at base of cone */}
            <path d="M 11 11 Q 25 15 39 11" fill="none" stroke="#FBBF24" strokeWidth="3" />
            {/* Glowing gold shiny star decal */}
            <polygon points="25, -2 26.5,1 29,1 27,3 28,6 25,4 22,6 23,3 21,1 23.5,1" fill="#FFCD00" />
            
            {/* Mage hair sideburns peeking below */}
            <path d="M 6 14 C 6 19, 10 21, 11 21" fill="none" stroke="#B45309" strokeWidth="3" strokeLinecap="round" />
            <path d="M 44 14 C 44 19, 40 21, 39 21" fill="none" stroke="#B45309" strokeWidth="3" strokeLinecap="round" />
          </g>
        );
      case 'classic':
      default:
        return (
          <g fill={hairColor} stroke="#000000" strokeWidth="1.8" id="hair-classic">
            {/* High-fidelity layered classic Lego hairdo */}
            <path d="M 6 16 C 7 7, 43 7, 44 16 C 45 22, 41 21, 39 19 Q 34 16 25 16 Q 16 16 11 19 C 9 21, 5 22, 6 16" />
            <path d="M 4 14 C 3 21, 9 23, 9 23" fill="none" stroke="#000" strokeWidth="1.8" strokeLinecap="round" />
            <path d="M 46 14 C 47 21, 41 23, 41 23" fill="none" stroke="#000" strokeWidth="1.8" strokeLinecap="round" />
            <path d="M 12 11 Q 25 8 38 11" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.3" />
          </g>
        );
    }
  };

  return (
    <svg 
      id={`minifig-${expression}-${torsoColor.replace('#','')}`}
      width={size} 
      height={size} 
      viewBox="-12 -18 74 114" 
      className={`${className} overflow-visible`}
    >
      {/* GLOW & DROP SHADOWS FOR DOPAMINE INTRO */}
      <defs>
        {/* Soft 3D plastic head radial gradient */}
        <radialGradient id="plastic-yellow-head" cx="35%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FFF275" />
          <stop offset="60%" stopColor="#FFC107" />
          <stop offset="100%" stopColor="#DF9A00" />
        </radialGradient>
        
        {/* Soft toy body gradient for extra richness */}
        <linearGradient id="body-shine-grad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.25" />
          <stop offset="40%" stopColor="#FFFFFF" stopOpacity="0.0" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.2" />
        </linearGradient>
      </defs>

      <g>
        {/* 1. LEGS & HIPS */}
        <g id="minifig-legs">
          {/* Hips connection bar */}
          <rect x="11" y="72" width="28" height="6.5" rx="1.5" fill="#1C1A17" stroke="#000000" strokeWidth="1.8" />
          <rect x="13.5" y="73" width="23" height="4.5" rx="1.2" fill={legsColor} />
          
          {/* Left leg with realistic 3D foot caps */}
          <rect x="11.5" y="78" width="11.5" height="15.5" rx="1.5" fill={legsColor} stroke="#000000" strokeWidth="1.8" />
          <rect x="11.5" y="90" width="11.5" height="3.5" rx="1" fill="#1E293B" opacity="0.2" />

          {/* Right leg with realistic 3D foot caps */}
          <rect x="27" y="78" width="11.5" height="15.5" rx="1.5" fill={legsColor} stroke="#000000" strokeWidth="1.8" />
          <rect x="27" y="90" width="11.5" height="3.5" rx="1" fill="#1E293B" opacity="0.2" />
          
          {/* Feet bottom shadows */}
          <path d="M 11 93.5 L 23.5 93.5" stroke="#000000" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M 26.5 93.5 L 39 93.5" stroke="#000000" strokeWidth="1.8" strokeLinecap="round" />
        </g>

        {/* 2. TORSO */}
        <g id="minifig-torso">
          {/* Robust classic Trapezoid Torso */}
          <polygon points="14.5,44 35.5,44 41.5,72 8.5,72" fill={torsoColor} stroke="#000000" strokeWidth="2" />
          {/* Glossy sheen overlay on Torso */}
          <polygon points="14.5,44 35.5,44 41.5,72 8.5,72" fill="url(#body-shine-grad)" pointerEvents="none" />
          
          {/* LEFT ARM: Detailed angle joints */}
          <path d="M 12 45.5 Q 3.5 54, 7 65.5" stroke="#000" strokeWidth="7.5" strokeLinecap="round" fill="none" />
          <path d="M 12 45.5 Q 3.5 54, 7 65.5" stroke={torsoColor} strokeWidth="4.5" strokeLinecap="round" fill="none" strokeDasharray="none" />
          
          {/* Left LEGO Claw Hand (C-shape with wrist rotation link!) */}
          <g transform="translate(6.2, 66.5) rotate(35)">
            <circle cx="0" cy="0" r="1.5" fill="#000000" />
            <path d="M -4.5,0.5 C -4.5,-4 3.5,-4 3.5,0.5 L 3.5,2.5 C 3.5,7 -4.5,7 -4.5,2.5" fill="none" stroke="#000000" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M -4.5,0.5 C -4.5,-4 3.5,-4 3.5,0.5 L 3.5,2.5 C 3.5,7 -4.5,7 -4.5,2.5" fill="none" stroke="#FFC107" strokeWidth="2.2" strokeLinecap="round" />
          </g>

          {/* RIGHT ARM: Detailed angle joints */}
          <path d="M 38 45.5 Q 46.5 54, 43 65.5" stroke="#000" strokeWidth="7.5" strokeLinecap="round" fill="none" />
          <path d="M 38 45.5 Q 46.5 54, 43 65.5" stroke={torsoColor} strokeWidth="4.5" strokeLinecap="round" fill="none" strokeDasharray="none" />
          
          {/* Right LEGO Claw Hand (C-shape with wrist rotation link!) */}
          <g transform="translate(43.8, 66.5) rotate(-35)">
            <circle cx="0" cy="0" r="1.5" fill="#000000" />
            <path d="M -3.5,0.5 C -3.5,-4 4.5,-4 4.5,0.5 L 4.5,2.5 C 4.5,7 -3.5,7 -3.5,2.5" fill="none" stroke="#000000" strokeWidth="4.5" strokeLinecap="round" />
            <path d="M -3.5,0.5 C -3.5,-4 4.5,-4 4.5,0.5 L 4.5,2.5 C 4.5,7 -3.5,7 -3.5,2.5" fill="none" stroke="#FFC107" strokeWidth="2.2" strokeLinecap="round" />
          </g>

          {/* High-fidelity Decal Prints */}
          {renderTorsoDecoration()}
        </g>

        {/* 3. NECK - Yellow joint cylinder */}
        <rect x="20.5" y="38" width="9" height="6" fill="#FFC107" stroke="#000000" strokeWidth="1.8" />

        {/* 4. HEAD */}
        <g id="minifig-head">
          {/* 3D Cylindrical Yellow LEGO Head with radial shiny highlights */}
          <rect x="11" y="14" width="28" height="26.5" rx="8.5" fill="url(#plastic-yellow-head)" stroke="#000000" strokeWidth="2" />
          
          {/* Stud spacer disk on top of head */}
          <rect x="19.5" y="7.5" width="11" height="6.5" rx="1.5" fill="#FFC107" stroke="#000000" strokeWidth="2" />

          {/* Seductive 3D curved gloss line representing physical light reflection */}
          <path d="M 14.5 17 Q 20 12 25.5 17" fill="none" stroke="#FFFFFF" strokeWidth="1.8" strokeLinecap="round" opacity="0.65" pointerEvents="none" />

          {/* Expression details (eyes, cheeks, mouths, eyebrows) */}
          {renderExpression()}
        </g>

        {/* 5. HAIR OR HAT (Always rendered on very top for layering) */}
        <g id="minifig-hair-hat">
          {renderHairOrHat()}
        </g>
      </g>
    </svg>
  );
};
