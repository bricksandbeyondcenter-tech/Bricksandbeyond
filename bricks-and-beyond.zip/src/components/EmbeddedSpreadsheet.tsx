import React, { useState, useEffect } from 'react';
import { CheckInLog } from '../types';
import { FileSpreadsheet, Download, RefreshCw, Plus, Trash2, Search, Table, HelpCircle, Save } from 'lucide-react';

interface EmbeddedSpreadsheetProps {
  logs: CheckInLog[];
  setLogs: React.Dispatch<React.SetStateAction<CheckInLog[]>>;
  logsFilter?: 'staff' | 'students';
}

export const EmbeddedSpreadsheet: React.FC<EmbeddedSpreadsheetProps> = ({ logs, setLogs, logsFilter }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [gridData, setGridData] = useState<string[][]>([]);
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null);
  const [editValue, setEditValue] = useState('');
  const [selectedRow, setSelectedRow] = useState<number | null>(null);

  const columns = [
    { label: 'A', name: 'Timestamp' },
    { label: 'B', name: 'Student/Staff Name' },
    { label: 'C', name: 'Parent/Org' },
    { label: 'D', name: 'Parent Email' },
    { label: 'E', name: 'Parent Phone' },
    { label: 'F', name: 'Membership Type/Role' },
    { label: 'G', name: 'Status' }
  ];

  // Map of visual row index to original global logs index
  const filteredIndices: number[] = [];
  logs.forEach((log, index) => {
    const isStaff = log.studentName && log.studentName.startsWith('[STAFF]');
    if (logsFilter === 'staff') {
      if (isStaff) filteredIndices.push(index);
    } else if (logsFilter === 'students') {
      if (!isStaff) filteredIndices.push(index);
    } else {
      filteredIndices.push(index);
    }
  });

  const numFilteredLogs = filteredIndices.length;

  // Initialize spreadsheet grid with actual logs (with padding for empty rows up to 100)
  useEffect(() => {
    const formatted: string[][] = filteredIndices.map(originalIdx => {
      const log = logs[originalIdx];
      return [
        log.timestamp || '',
        log.studentName || '',
        log.parentName || '',
        log.parentEmail || '',
        log.parentPhone || '',
        log.membershipType || '',
        log.status || ''
      ];
    });

    // Pad to 100 rows for real spreadsheet feel!
    while (formatted.length < 100) {
      formatted.push(['', '', '', '', '', '', '']);
    }

    setGridData(formatted);
  }, [logs, logsFilter]);

  const handleCellDoubleClick = (rowIndex: number, colIndex: number) => {
    setEditingCell({ row: rowIndex, col: colIndex });
    setEditValue(gridData[rowIndex][colIndex]);
  };

  const handleCellBlur = (rowIndex: number, colIndex: number) => {
    if (!editingCell) return;
    saveCellChange(rowIndex, colIndex, editValue);
  };

  const handleCellKeyDown = (e: React.KeyboardEvent, rowIndex: number, colIndex: number) => {
    if (e.key === 'Enter') {
      saveCellChange(rowIndex, colIndex, editValue);
      setEditingCell(null);
    } else if (e.key === 'Escape') {
      setEditingCell(null);
    }
  };

  const saveCellChange = (rowIndex: number, colIndex: number, val: string) => {
    const updatedGrid = [...gridData];
    updatedGrid[rowIndex] = [...updatedGrid[rowIndex]];
    updatedGrid[rowIndex][colIndex] = val;
    setGridData(updatedGrid);

    // Update real logs state if inside logs range
    if (rowIndex < numFilteredLogs) {
      const globalIndex = filteredIndices[rowIndex];
      const updatedLogs = [...logs];
      const log = { ...updatedLogs[globalIndex] };

      if (colIndex === 0) log.timestamp = val;
      else if (colIndex === 1) log.studentName = val;
      else if (colIndex === 2) log.parentName = val;
      else if (colIndex === 3) log.parentEmail = val;
      else if (colIndex === 4) log.parentPhone = val;
      else if (colIndex === 5) log.membershipType = val;
      else if (colIndex === 6) log.status = val;

      updatedLogs[globalIndex] = log;
      setLogs(updatedLogs);
    } else {
      // If user typed in non-empty row just beyond logs, compile it into logs!
      const rowHasData = updatedGrid[rowIndex].some(cell => cell.trim() !== '');
      if (rowHasData) {
        const isStaffFilter = logsFilter === 'staff';
        const newLog: CheckInLog = {
          timestamp: updatedGrid[rowIndex][0] || new Date().toLocaleString(),
          studentName: updatedGrid[rowIndex][1] || (isStaffFilter ? '[STAFF] New Staff' : 'New Record'),
          parentName: updatedGrid[rowIndex][2] || (isStaffFilter ? 'Bricks & Beyond Educational Play Center' : 'Bricks & Beyond'),
          parentEmail: updatedGrid[rowIndex][3] || (isStaffFilter ? 'staff@bricksandbeyond.com' : ''),
          parentPhone: updatedGrid[rowIndex][4] || '',
          membershipType: updatedGrid[rowIndex][5] || (isStaffFilter ? 'Coach' : 'Member'),
          status: updatedGrid[rowIndex][6] || (isStaffFilter ? 'Staff In' : 'In')
        };
        const updatedLogs = [...logs];
        updatedLogs.push(newLog);
        setLogs(updatedLogs);
      }
    }
    setEditingCell(null);
  };

  const handleAddBlankRow = () => {
    const isStaffFilter = logsFilter === 'staff';
    const newLog: CheckInLog = {
      timestamp: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) + ' ' + new Date().toLocaleTimeString(),
      studentName: isStaffFilter ? '[STAFF] Manual Coach Entry' : 'Manual Entry',
      parentName: isStaffFilter ? 'Bricks & Beyond Educational Play Center' : 'Parent Name',
      parentEmail: isStaffFilter ? 'staff@bricksandbeyond.com' : '',
      parentPhone: '',
      membershipType: isStaffFilter ? 'Instructor' : 'Adventurer',
      status: isStaffFilter ? 'Staff In' : 'Checked In'
    };
    setLogs([newLog, ...logs]);
  };

  const handleDeleteSelectedRow = () => {
    if (selectedRow === null || selectedRow >= numFilteredLogs) {
      alert('Please select a valid rows containing log data!');
      return;
    }
    if (window.confirm('Are you sure you want to delete this row from the BnB Spreadsheet?')) {
      const globalIndex = filteredIndices[selectedRow];
      const updatedLogs = logs.filter((_, i) => i !== globalIndex);
      setLogs(updatedLogs);
      setSelectedRow(null);
    }
  };

  const handleClearAllLogs = () => {
    if (window.confirm('WARNING: Are you sure you want to completely clear the BnB Embedded Spreadsheet? This cannot be undone.')) {
      if (logsFilter === 'staff') {
        setLogs(prev => prev.filter(log => !log.studentName.startsWith('[STAFF]')));
      } else if (logsFilter === 'students') {
        setLogs(prev => prev.filter(log => log.studentName.startsWith('[STAFF]')));
      } else {
        setLogs([]);
      }
      setSelectedRow(null);
    }
  };

  const handleDownloadCSV = () => {
    const activeData = gridData.filter(row => row.some(cell => cell.trim() !== ''));
    if (activeData.length === 0) {
      alert('No data inside spreadsheet to export!');
      return;
    }

    const headers = columns.map(c => `"${c.name}"`).join(',');
    const csvRows = activeData.map(row => row.map(v => `"${v.replace(/"/g, '""')}"`).join(','));
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...csvRows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `bnb_${logsFilter || 'general'}_spreadsheet_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter logs based on search query
  const searchFilteredIndices = gridData
    .map((row, idx) => ({ row, idx }))
    .filter(({ row, idx }) => {
      if (idx >= numFilteredLogs) return false; // only filter actual logs
      if (!searchQuery) return true;
      return row.some(cell => cell.toLowerCase().includes(searchQuery.toLowerCase()));
    })
    .map(({ idx }) => idx);

  return (
    <div className="bg-white border-4 border-black rounded-3xl p-6 shadow-[8px_8px_0px_#000] space-y-4 font-sans animate-fade-in" id="bnb-spreadsheet-container">
      {/* Top action header bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b-4 border-black pb-4">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-100 border-2 border-black p-2 rounded-xl text-emerald-600">
            <FileSpreadsheet className="w-7 h-7" />
          </div>
          <div>
            <h2 className="font-bangers text-3xl text-emerald-700 tracking-wider flex items-center gap-2">
              {logsFilter === 'staff' ? 'COACH WORKTimes SHEET' : logsFilter === 'students' ? 'STUDENT ATTENDANCE SHEET' : 'B&B LOGS SPREADSHEET'} 
              <span className="bg-emerald-600 text-white font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-normal">AUTOMATIC REAL-TIME</span>
            </h2>
            <p className="text-xs font-mono font-bold text-neutral-500 uppercase">
              {logsFilter === 'staff' 
                ? 'Purely staff workhours & shift checkins. Double-click cells to modify values.' 
                : 'Purely student builder attendance records. Double-click cells to modify values.'}
            </p>
          </div>
        </div>

        {/* Search controls */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search cells..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-1.5 bg-slate-50 border-2 border-black rounded-xl text-xs font-semibold focus:bg-white w-48 font-mono"
            />
          </div>

          <button
            onClick={handleAddBlankRow}
            className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase px-3 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
            title="Insert record row"
          >
            <Plus className="w-3.5 h-3.5" /> Row
          </button>

          <button
            onClick={handleDeleteSelectedRow}
            disabled={selectedRow === null}
            className={`flex items-center gap-1 font-bold text-xs uppercase px-3 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 ${
              selectedRow !== null ? 'bg-red-500 hover:bg-red-600 text-white cursor-pointer' : 'bg-neutral-100 text-neutral-400 border-neutral-300 opacity-60 cursor-not-allowed'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" /> Delete
          </button>

          <button
            onClick={handleDownloadCSV}
            className="flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs uppercase px-3 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
          >
            <Download className="w-3.5 h-3.5" /> CSV
          </button>

          <button
            onClick={handleClearAllLogs}
            className="bg-neutral-800 hover:bg-neutral-900 text-red-400 font-bold text-xs uppercase px-3 py-2 rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5"
          >
            Clear Grid
          </button>
        </div>
      </div>

      {/* Spreadsheet Formula / Cell Editor representation */}
      <div className="flex items-center gap-2 bg-slate-50 border-2 border-black rounded-xl p-2 font-mono text-xs">
        <span className="bg-emerald-600 text-white font-bold px-2 py-0.5 rounded uppercase">fx</span>
        <span className="text-neutral-400 font-bold w-12 border-r border-neutral-300 pr-1 text-center">
          {selectedRow !== null ? `${columns[editingCell?.col ?? 0]?.label}${selectedRow + 1}` : 'CELL'}
        </span>
        <div className="flex-grow font-semibold text-neutral-700 font-mono italic">
          {selectedRow !== null && gridData[selectedRow]
            ? `Row Data: [${gridData[selectedRow].filter(Boolean).join(' | ')}]`
            : 'Select any cell to view and double-click to instantly type.'}
        </div>
      </div>

      {/* Google spreadsheet viewport */}
      <div className="border-4 border-black rounded-2xl overflow-hidden bg-slate-200">
        <div className="max-h-96 overflow-auto">
          <table className="w-full border-collapse bg-white font-mono text-xs text-left" id="bnb-grid-table">
            <thead>
              <tr className="bg-slate-100 sticky top-0 z-10 border-b-2 border-black select-none">
                <th className="w-10 bg-slate-200 border-r-2 border-b-2 border-black p-2 text-center text-neutral-600 font-bold">#</th>
                {columns.map((col, idx) => (
                  <th key={idx} className="border-r border-b-2 border-neutral-300 p-2 font-bold text-center text-neutral-700 bg-slate-100 min-w-[130px]" style={{ borderRight: '1px solid #7f8c8d' }}>
                    <div className="text-[10px] text-emerald-800 leading-none mb-0.5 font-bold uppercase">{col.label}</div>
                    <div className="text-[11px] font-sans tracking-tight text-neutral-800">{col.name}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {gridData.map((row, rowIndex) => {
                // Determine if we should show this row based on search query
                const isLoadedLog = rowIndex < numFilteredLogs;
                const matchesSearch = searchQuery === '' || !isLoadedLog || searchFilteredIndices.includes(rowIndex);

                if (!matchesSearch) return null;

                const isSelected = selectedRow === rowIndex;

                return (
                  <tr
                    key={rowIndex}
                    className={`border-b border-slate-200 hover:bg-slate-50 transition-colors ${
                      isSelected ? 'bg-emerald-50/75 border-l-4 border-l-emerald-600' : ''
                    }`}
                    onClick={() => setSelectedRow(rowIndex)}
                  >
                    {/* Row Index Indicator */}
                    <td className="bg-slate-50 border-r-2 border-b border-black text-center text-[11px] p-1.5 font-bold text-neutral-500 select-none">
                      {rowIndex + 1}
                    </td>

                    {/* Columns Cells */}
                    {row.map((cellValue, colIndex) => {
                      const isEditing = editingCell?.row === rowIndex && editingCell?.col === colIndex;

                      return (
                        <td
                          key={colIndex}
                          onDoubleClick={() => handleCellDoubleClick(rowIndex, colIndex)}
                          className={`p-2 border-r border-neutral-200 relative truncate cursor-text ${
                            isEditing ? 'p-0 !overflow-visible !z-20 min-w-[150px]' : ''
                          }`}
                          style={{
                            borderRight: '1px solid #e2e8f0',
                            borderBottom: '1px solid #e2e8f0'
                          }}
                        >
                          {isEditing ? (
                            <input
                              type="text"
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              onBlur={() => handleCellBlur(rowIndex, colIndex)}
                              onKeyDown={(e) => handleCellKeyDown(e, rowIndex, colIndex)}
                              className="absolute inset-0 w-full h-full bg-yellow-50 border-2 border-emerald-600 font-mono text-xs px-2 focus:outline-none ring-2 ring-emerald-500/20 shadow-lg"
                              autoFocus
                            />
                          ) : (
                            <span className={cellValue === '' ? 'text-neutral-300 italic' : 'text-neutral-800 font-semibold'}>
                              {cellValue === '' ? '(empty)' : cellValue}
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Spreadsheet stats info */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono font-bold text-neutral-500 px-1 pt-1 border-t border-dashed border-neutral-300">
        <div className="flex items-center gap-4">
          <span>ACTIVE ENTRIES: <strong className="text-emerald-700 font-bold">{numFilteredLogs} Rows</strong></span>
          <span>CELL CAP: <strong>700 Cells (Columns A-G / Rows 1-100)</strong></span>
        </div>
        <div className="text-right text-[10px]">
          DOUBLE-CLICK ANY CELL TO ENTER THE INLINE DATA EDITOR • AUTO-SAVING SUPPORTED
        </div>
      </div>
    </div>
  );
};
