import React, { useState, useEffect } from 'react';
import { CheckInLog } from '../types';
import { Database, FileSpreadsheet, Lock, AlertCircle, HelpCircle, Download, Check, RefreshCw, LogIn } from 'lucide-react';

interface GoogleSheetsConfigProps {
  logs: CheckInLog[];
  googleClientId: string;
  setGoogleClientId: (id: string) => void;
  spreadsheetId: string;
  setSpreadsheetId: (id: string) => void;
  accessToken: string | null;
  onGoogleLogin: () => void;
  onSyncLogs: () => Promise<void>;
  isSyncing: boolean;
}

export const GoogleSheetsConfig: React.FC<GoogleSheetsConfigProps> = ({
  logs,
  googleClientId,
  setGoogleClientId,
  spreadsheetId,
  setSpreadsheetId,
  accessToken,
  onGoogleLogin,
  onSyncLogs,
  isSyncing,
}) => {
  const [showGuide, setShowGuide] = useState(false);
  const [syncedCount, setSyncedCount] = useState<number>(0);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSyncClick = async () => {
    try {
      await onSyncLogs();
      setSyncedCount(logs.length);
      setSuccessMsg(`Successfully synchronized all ${logs.length} check-in logs to Google Sheets!`);
      setTimeout(() => setSuccessMsg(null), 5000);
    } catch (e: any) {
      alert(`Synchronizing to Google Sheets failed. Ready details: ${e?.message ?? e}`);
    }
  };

  // Convert logs to local CSV backup download
  const handleExportCSV = () => {
    if (logs.length === 0) {
      alert("No logs available to export.");
      return;
    }
    const headers = ["Timestamp", "Student Name", "Parent Name", "Parent Email", "Parent Phone", "Membership Type", "Status"];
    const rows = logs.map(l => [
      l.timestamp,
      l.studentName,
      l.parentName,
      l.parentEmail,
      l.parentPhone,
      l.membershipType,
      l.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.map(val => `"${val.replace(/"/g, '""')}"`).join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `bricks_and_beyond_checkins_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Configuration Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Area: Setup inputs */}
        <div className="lg:col-span-2 bg-white rounded-2xl border-4 border-black p-6 shadow-[8px_8px_0px_#008542] space-y-4">
          <div className="flex items-center gap-2 border-b-2 border-dashed border-slate-200 pb-3">
            <div className="bg-green-100 p-2 rounded-full border-2 border-black text-legogreen shadow-[2px_2px_0px_#000]">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bangers text-2xl text-black leading-none tracking-widest uppercase">GOOGLE SPREADSHEET LINK</h3>
              <p className="text-xs font-bold text-gray-500 font-blueberry uppercase">Integrate your play center's live check-ins directly.</p>
            </div>
          </div>

          <div className="space-y-4 font-blueberry text-sm font-semibold">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[11px] text-gray-700 block mb-1 uppercase font-bold tracking-wider">Google App Client ID</label>
                <input
                  type="text"
                  placeholder="Paste your Google Developer Client ID here..."
                  value={googleClientId}
                  onChange={(e) => setGoogleClientId(e.target.value)}
                  className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold font-blueberry focus:outline-none focus:ring-2 focus:ring-legogreen shadow-[2px_2px_0px_#000]"
                />
              </div>
              <div>
                <label className="text-[11px] text-gray-700 block mb-1 uppercase font-bold tracking-wider">Target Google Spreadsheet ID</label>
                <input
                  type="text"
                  placeholder="e.g., 1bH67_Z-Nmsv4D_e_..."
                  value={spreadsheetId}
                  onChange={(e) => setSpreadsheetId(e.target.value)}
                  className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold font-blueberry focus:outline-none focus:ring-2 focus:ring-legogreen shadow-[2px_2px_0px_#000] bg-yellow-50/10"
                />
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2 justify-between items-center">
              <div className="flex items-center gap-2 text-xs">
                {accessToken ? (
                  <span className="bg-green-100 border border-green-500 text-green-700 font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <Check className="w-4 h-4 stroke-[3]" /> Google Authorized
                  </span>
                ) : (
                  <span className="bg-gray-100 border border-gray-400 text-gray-600 font-bold px-3 py-1 rounded-full flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" /> Authorization Needed
                  </span>
                )}
              </div>

              <div className="flex gap-2 w-full sm:w-auto">
                {!accessToken ? (
                  <button
                    type="button"
                    onClick={onGoogleLogin}
                    className="flex-1 sm:flex-none bg-legoblue hover:opacity-95 text-white font-bangers text-xs tracking-widest uppercase px-6 py-2.5 border-2 border-black rounded-lg shadow-[3px_3px_0px_#000] flex items-center justify-center gap-2 active:translate-y-0.5 cursor-pointer"
                  >
                    <LogIn className="w-4 h-4" />
                    AUTHORIZE SHEETS
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleSyncClick}
                    disabled={isSyncing}
                    className="flex-1 sm:flex-none bg-legogreen hover:opacity-95 text-white font-bangers text-xs tracking-widest uppercase px-6 py-2.5 border-2 border-black rounded-lg shadow-[3px_3px_0px_#000] flex items-center justify-center gap-2 active:translate-y-0.5 disabled:opacity-50 cursor-pointer"
                  >
                    {isSyncing ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <RefreshCw className="w-4 h-4" />
                    )}
                    {isSyncing ? 'SYNCING...' : 'SYNC SHEETS NOW'}
                  </button>
                )}
              </div>
            </div>

            {successMsg && (
              <div className="bg-green-50 border-2 border-green-500 rounded-xl p-3 text-green-800 text-xs flex items-start gap-2 shadow-[3px_3px_0px_#000]">
                <Check className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                <span>{successMsg}</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Area: Status Summary Widget */}
        <div className="bg-legoyellow rounded-2xl border-4 border-black p-6 shadow-[8px_8px_0px_#000] flex flex-col justify-between">
          <div>
            <h4 className="font-bangers text-2xl text-black mb-1 flex items-center gap-1.5 tracking-widest uppercase">
              <Database className="w-5 h-5 text-legoblue stroke-[2.5]" />
              OFFLINE ENTRANT LOGS
            </h4>
            <p className="font-blueberry text-xs text-gray-700 leading-snug font-semibold uppercase">
              Every local check-in is buffered in browser storage, so paper is never needed even without internet.
            </p>

            <div className="mt-4 grid grid-cols-2 gap-3 text-center">
              <div className="bg-white border-2 border-black rounded-xl p-2 shadow-[3px_3px_0px_#000]">
                <span className="text-[9px] font-extrabold text-gray-400 block font-blueberry uppercase tracking-wider">Total Entries</span>
                <span className="font-bangers text-2xl text-black">{logs.length}</span>
              </div>
              <div className="bg-white border-2 border-black rounded-xl p-2 shadow-[3px_3px_0px_#000]">
                <span className="text-[9px] font-extrabold text-gray-400 block font-blueberry uppercase tracking-wider">Buffered Logs</span>
                <span className="font-bangers text-2xl text-legored">{logs.length - syncedCount}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-black/10 flex gap-2 w-full">
            <button
              onClick={handleExportCSV}
              className="w-full bg-white hover:bg-slate-50 font-bangers text-xs tracking-widest uppercase text-black py-2.5 rounded-lg border-2 border-black flex items-center justify-center gap-2 shadow-[4px_4px_0px_#000] active:translate-y-0.5 cursor-pointer"
            >
              <Download className="w-4 h-4 text-legoblue" />
              DOWNLOAD CSV BACKUP
            </button>
          </div>
        </div>
      </div>

      {/* Accordion / Block instructions */}
      <div className="bg-white rounded-2xl border-4 border-black p-6 shadow-[8px_8px_0px_#005596]">
        <button
          onClick={() => setShowGuide(!showGuide)}
          className="w-full flex items-center justify-between font-bangers text-xl text-black text-left tracking-wider uppercase cursor-pointer"
        >
          <span className="flex items-center gap-2"><HelpCircle className="w-5 h-5 text-legoblue" /> HOW TO LINK YOUR GOOGLE SHEET?</span>
          <span className="text-xl font-bold">{showGuide ? "[-]" : "[+]"}</span>
        </button>

        {showGuide && (
          <div className="mt-4 pt-4 border-t border-dashed border-slate-200 text-sm font-semibold text-gray-700 font-blueberry space-y-3">
            <p>Ready to sync entries in real time? Follow these steps to generate credentials:</p>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Open Google Drive and create a new <strong className="text-legogreen font-extrabold">Google Spreadsheet</strong>.</li>
              <li>The first row of columns must be formatted as:
                <div className="bg-slate-100 border-2 border-black rounded-lg p-2 font-mono text-[11px] mt-1 text-black font-semibold">
                  Timestamp | Student Name | Parent Name | Parent Email | Parent Phone | Membership Type | Status
                </div>
              </li>
              <li>Copy the <strong className="text-legoblue font-extrabold">Spreadsheet ID</strong> from the URL (the random letters and numbers between <code>/d/</code> and <code>/edit</code>).</li>
              <li>Create a Google Cloud Project, enable the <strong className="text-legogreen font-extrabold">Google Sheets API</strong>, and set up an OAuth Consent Screen to get your <strong className="text-legoblue font-extrabold">Google App Client ID</strong>.</li>
              <li>Optionally, define them directly inside the <code>.env</code> file of this development workspace as:
                <pre className="bg-slate-100 border-2 border-black rounded-lg p-2 font-mono text-[11px] mt-1 text-black font-semibold">
                  VITE_GOOGLE_CLIENT_ID="[Your ID]"<br />
                  VITE_SPREADSHEET_ID="[Your Sheet ID]"
                </pre>
              </li>
              <li>Click <strong className="text-legoblue font-extrabold">Authorize Sheets</strong>, sign in with your Google Workspace credentials, and click <strong className="text-legogreen font-extrabold">Sync Sheets Now</strong> to sync check-ins!</li>
            </ol>
            <div className="bg-blue-50 border border-blue-400 p-3 rounded-xl flex items-start gap-2 text-blue-800 text-xs mt-3 shadow-[2px_2px_0px_rgba(0,0,0,0.15)]">
              <AlertCircle className="w-5 h-5 text-legoblue shrink-0 mt-0.5" />
              <span>
                <strong>Note:</strong> Until you connect Google Sheets, your data is securely cached in local storage. Everything runs offline so your check-in ipad stays active even if the Wi-Fi drops!
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Live Check-In Database Table */}
      <div className="bg-white rounded-2xl border-4 border-black p-6 shadow-[8px_8px_0px_#000]">
        <div className="border-b-2 border-black pb-3 mb-4">
          <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">LIVE ENTRANT DATA LOG</h4>
          <p className="text-xs text-slate-500 font-bold font-blueberry uppercase">
            Real-time track records of check-ins and check-outs, logged instantly by parents.
          </p>
        </div>

        {logs.length === 0 ? (
          <div className="text-center py-10 font-blueberry text-gray-500 font-semibold uppercase">
            "No entries recorded today yet. Select check-in under a student above!"
          </div>
        ) : (
          <div className="overflow-x-auto border-2 border-black rounded-xl shadow-[4px_4px_0px_#000]">
            <table className="w-full text-left font-blueberry text-xs font-semibold">
              <thead className="bg-slate-100 border-b-2 border-black text-slate-700 uppercase tracking-wider font-bangers text-sm">
                <tr>
                  <th className="p-3">DATE / TIME</th>
                  <th className="p-3">STUDENT BUILDER</th>
                  <th className="p-3">PARENT NAME</th>
                  <th className="p-3">EMAIL / PHONE</th>
                  <th className="p-3 text-center">MEMBERSHIP</th>
                  <th className="p-3 text-center">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-slate-100">
                {logs.map((log, idx) => (
                  <tr key={idx} className="hover:bg-slate-50 text-black">
                    <td className="p-3 whitespace-nowrap font-mono font-bold text-legoblue">{log.timestamp}</td>
                    <td className="p-3 font-bold">{log.studentName}</td>
                    <td className="p-3 font-bold">{log.parentName}</td>
                    <td className="p-3">
                      <div className="font-semibold">{log.parentEmail}</div>
                      <div className="text-[10px] text-gray-400 font-semibold">{log.parentPhone}</div>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap font-semibold">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bangers border ${
                        log.membershipType === 'Master Builder' ? 'bg-red-50 border-legored text-legored' :
                        log.membershipType === 'Adventurer' ? 'bg-blue-50 border-legoblue text-legoblue' :
                        'bg-gray-100 border-gray-400 text-gray-600'
                      }`}>
                        {log.membershipType}
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap font-semibold">
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bangers border-2 ${
                        log.status === 'Checked In' 
                          ? 'bg-green-50 border-legogreen text-legogreen' 
                          : 'bg-red-50 border-legored text-legored'
                      }`}>
                        {log.status.toUpperCase()}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
