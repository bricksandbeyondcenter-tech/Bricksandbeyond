import React, { useState } from 'react';
import { Student, Badge } from '../types';
import { Award, ShieldAlert, Sparkles, Trophy, Flame, Pencil, Settings2, Sliders, Check, Plus, Minus } from 'lucide-react';

interface BadgeBoardProps {
  students: Student[];
  setStudents?: React.Dispatch<React.SetStateAction<Student[]>>;
}

const BRICK_BADGES: Badge[] = [
  {
    id: 'apprentice',
    name: 'Master Builder Apprentice',
    description: 'Attend Bricks & Beyond and complete your first 3 build models.',
    category: 'Creativity',
    reqSteps: 3,
    iconName: 'Sparkles',
  },
  {
    id: 'bridge_builder',
    name: 'Bridge Force Expert',
    description: 'Build a bridge over 2 feet wide that supports a 5-pound weight block.',
    category: 'Engineering',
    reqSteps: 1,
    iconName: 'Trophy',
  },
  {
    id: 'space_cadet',
    name: 'Apollo Rocket Pioneer',
    description: 'Assemble a custom interstellar spacecraft using clean white and neon block sets.',
    category: 'Creativity',
    reqSteps: 1,
    iconName: 'Award',
  },
  {
    id: 'helper',
    name: 'Brick Sorter Hero',
    description: 'Help clean up and classify bricks into their correct container drawers.',
    category: 'Teamwork',
    reqSteps: 2,
    iconName: 'Award',
  },
  {
    id: 'technic',
    name: 'Technic Gear Wizard',
    description: 'Construct a complex mechanical device with interlocking rotating gears.',
    category: 'Engineering',
    reqSteps: 1,
    iconName: 'Flame',
  },
];

export const BadgeBoard: React.FC<BadgeBoardProps> = ({ students, setStudents }) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [isTuningMode, setIsTuningMode] = useState<boolean>(false);
  const activeStudent = students.find((s) => s.id === selectedStudentId);

  const handleUpdateBadgeProgress = (badgeId: string, value: number) => {
    if (!setStudents) return;
    const cleanVal = Math.max(0, Math.min(100, Math.round(value)));
    setStudents(prev => prev.map(s => {
      if (s.id === selectedStudentId) {
        return {
          ...s,
          badges: {
            ...s.badges,
            [badgeId]: cleanVal
          }
        };
      }
      return s;
    }));
  };

  // Helper to color code categories
  const getCategoryTheme = (category: string) => {
    switch (category) {
      case 'Engineering':
        return { bg: 'bg-legored', text: 'text-legored', bdr: 'border-legored', light: 'bg-red-50' };
      case 'Teamwork':
        return { bg: 'bg-legogreen', text: 'text-legogreen', bdr: 'border-legogreen', light: 'bg-green-50' };
      case 'Focus':
        return { bg: 'bg-legoyellow text-black border-black', text: 'text-black', bdr: 'border-black', light: 'bg-yellow-50' };
      case 'Creativity':
      default:
        return { bg: 'bg-legoblue', text: 'text-legoblue', bdr: 'border-legoblue', light: 'bg-blue-50' };
    }
  };

  if (!activeStudent) {
    return (
      <div className="bg-white border-4 border-black rounded-2xl p-8 text-center shadow-[8px_8px_0px_#E3000B]">
        <ShieldAlert className="w-12 h-12 text-legored mx-auto mb-2" />
        <h3 className="font-bangers text-2xl text-black">NO ACTIVE STUDENTS</h3>
        <p className="font-blueberry text-gray-600">Register a student to view their badges!</p>
      </div>
    );
  }

  // Calculate stats
  const badgesEarnedCount = Object.values(activeStudent.badges).filter((score: any) => score >= 100).length;

  return (
    <div id="badge-board" className="space-y-6">
      {/* Student Selector Row - Green theme */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-4 border-legogreen p-5 rounded-2xl shadow-[8px_8px_0px_#008542]">
        <div>
          <label className="text-sm font-bangers text-black block mb-1.5 tracking-wider">SELECT BUILDER TO VIEW BADGES</label>
          <select
            value={selectedStudentId}
            onChange={(e) => setSelectedStudentId(e.target.value)}
            className="bg-white border-2 border-black rounded-lg px-4 py-2 font-blueberry text-black font-bold text-sm focus:outline-none focus:ring-2 focus:ring-legogreen shadow-[3px_3px_0px_#000] cursor-pointer"
          >
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.name} ({student.membershipType})
              </option>
            ))}
          </select>
        </div>

        {/* Builder Quick Stats Card */}
        <div className="flex gap-4 items-center bg-white border-2 border-black px-4 py-2.5 rounded-xl shadow-[4px_4px_0px_#000]">
          <div className="bg-legoyellow border border-black p-1.5 rounded-full shrink-0">
            <Trophy className="w-6 h-6 text-black fill-yellow-250 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] font-bold text-gray-500 font-blueberry block tracking-wider uppercase">TOTAL BADGES EARNED</span>
            <span className="font-bangers text-2xl text-black">
              {badgesEarnedCount} / {BRICK_BADGES.length}
            </span>
          </div>
        </div>

        {/* Toggle Tuning Mode for Coaches */}
        {setStudents && (
          <button
            onClick={() => setIsTuningMode(!isTuningMode)}
            className={`flex items-center justify-center gap-2 font-bangers text-sm uppercase px-4 py-2.5 rounded-xl border-2 border-black shadow-[4px_4px_0px_#000] active:translate-y-0.5 cursor-pointer transition-colors ${
              isTuningMode 
                ? 'bg-legored text-white hover:bg-red-600 shadow-[2px_2px_0px_#000] translate-y-0.5' 
                : 'bg-legoyellow text-black hover:bg-yellow-400'
            }`}
          >
            {isTuningMode ? (
              <>
                <Check className="w-4 h-4" />
                Done Tuning Badges
              </>
            ) : (
              <>
                <Pencil className="w-4 h-4" />
                Tune Badge Progress
              </>
            )}
          </button>
        )}
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {BRICK_BADGES.map((badge) => {
          const progress = activeStudent.badges[badge.id] || 0;
          const isComplete = progress >= 100;
          const theme = getCategoryTheme(badge.category);

          return (
            <div
              key={badge.id}
              className={`bg-white rounded-2xl border-4 border-black p-5 relative overflow-hidden flex flex-col justify-between transition-all hover:translate-y-[-2px] ${
                isComplete 
                  ? 'border-black ring-4 ring-legoyellow shadow-[8px_8px_0px_#FFD500]' 
                  : 'shadow-[8px_8px_0px_#000]'
              }`}
            >
              {/* Badge Category Header */}
              <div className="flex items-center justify-between mb-4">
                <span className={`text-[10px] uppercase font-bangers px-2.5 py-1 text-white rounded-md border border-black shadow-[1.5px_1.5px_0px_rgba(0,0,0,1)] ${theme.bg}`}>
                  {badge.category}
                </span>

                <div className="flex items-center gap-1.5 font-bangers text-sm text-black">
                  <span>PROGRESS:</span>
                  <span className={`${isComplete ? 'text-legogreen font-bold' : 'text-legoblue font-bold'}`}>
                    {progress}%
                  </span>
                </div>
              </div>

              {/* Centered Lego Brick Emblem */}
              <div className="flex gap-4 items-start mb-4">
                {/* Visual Studded Badge Block */}
                <div className={`w-14 h-14 rounded-2xl border-2 border-black flex items-center justify-center shrink-0 shadow-[3px_3px_0px_#000] relative ${isComplete ? 'bg-legoyellow rotate-3' : 'bg-slate-50 -rotate-3'}`}>
                  {/* Lego studs */}
                  <div className="absolute -top-1 left-2.5 w-2.5 h-1 bg-current rounded-t border-t border-x border-black" />
                  <div className="absolute -top-1 right-2.5 w-2.5 h-1 bg-current rounded-t border-t border-x border-black" />
                  
                  {isComplete ? (
                    <Trophy className="w-7 h-7 text-black fill-yellow-250" />
                  ) : (
                    <Sparkles className="w-6 h-6 text-gray-400" />
                  )}
                </div>

                <div>
                  <h4 className="font-bangers text-xl text-black tracking-wide leading-tight">
                    {badge.name}
                  </h4>
                  <p className="font-blueberry text-xs text-gray-500 mt-1 leading-snug">
                    {badge.description}
                  </p>
                </div>
              </div>

              {/* Progress Bar & Status */}
              <div className="space-y-3 mt-4 pt-4 border-t-2 border-dashed border-gray-150">
                {isTuningMode ? (
                  <div className="bg-slate-50 border border-neutral-300 p-2.5 rounded-xl space-y-2 text-left">
                    <div className="flex items-center justify-between text-[11px] font-mono font-bold text-slate-600">
                      <span>TUNING PRESETS:</span>
                      <span className="bg-indigo-100 text-indigo-700 font-black px-1.5 py-0.2 rounded border border-indigo-200">{progress}%</span>
                    </div>
                    
                    {/* Quick Preset Buttons */}
                    <div className="flex gap-1 justify-between">
                      {[0, 25, 50, 75, 100].map((presetVal) => (
                        <button
                          key={presetVal}
                          onClick={() => handleUpdateBadgeProgress(badge.id, presetVal)}
                          className={`flex-1 text-[10px] font-mono font-extrabold py-1 rounded border text-center transition-colors cursor-pointer ${
                            progress === presetVal
                              ? 'bg-black text-white border-black ring-1 ring-black'
                              : 'bg-white text-slate-800 hover:bg-neutral-100 border-neutral-300'
                          }`}
                        >
                          {presetVal}%
                        </button>
                      ))}
                    </div>

                    {/* Step Adjustment Slider */}
                    <div className="flex items-center gap-2 pt-1.5 border-t border-dashed border-neutral-200">
                      <button
                        onClick={() => handleUpdateBadgeProgress(badge.id, Math.max(0, progress - 10))}
                        className="bg-white hover:bg-gray-150 border border-black p-1 rounded text-black cursor-pointer"
                        title="Minus 10%"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={progress}
                        onChange={(e) => handleUpdateBadgeProgress(badge.id, parseInt(e.target.value) || 0)}
                        className="w-full accent-black cursor-ew-resize h-1 bg-neutral-200 rounded-lg appearance-none"
                      />
                      
                      <button
                        onClick={() => handleUpdateBadgeProgress(badge.id, Math.min(100, progress + 10))}
                        className="bg-white hover:bg-gray-150 border border-black p-1 rounded text-black cursor-pointer"
                        title="Plus 10%"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="w-full bg-gray-100 rounded-full h-3 border-2 border-black overflow-hidden relative">
                      <div
                        className={`h-full border-r-2 border-black rounded-full transition-all duration-500 ${
                          isComplete ? 'bg-green-500' : 'bg-blue-600'
                        }`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>

                    <div className="flex justify-between items-center text-[11px] font-bold font-blueberry">
                      {isComplete ? (
                        <span className="text-green-600 flex items-center gap-1 font-black">
                          <Sparkles className="w-3.5 h-3.5 text-green-600 fill-green-200" />
                          UNLOCKED MASTER BADGE!
                        </span>
                      ) : (
                        <span className="text-gray-500">KEEP ASSEMBLING AT THE CENTER</span>
                      )}
                      <span className="bg-yellow-400 text-black px-1.5 py-0.5 rounded border border-black text-[10px] font-extrabold">
                        {badge.reqSteps} Step{badge.reqSteps > 1 ? 's' : ''}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
