import React, { useState } from 'react';
import { Workshop, Student } from '../types';
import { Calendar, Clock, MapPin, Users, DollarSign, CheckCircle, Award } from 'lucide-react';

interface WorkshopListProps {
  students: Student[];
  workshops: Workshop[];
  registeredWorkshops: { [key: string]: string[] };
  setRegisteredWorkshops: React.Dispatch<React.SetStateAction<{ [key: string]: string[] }>>;
}

export const WorkshopList: React.FC<WorkshopListProps> = ({
  students,
  workshops,
  registeredWorkshops,
  setRegisteredWorkshops,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [bookingWorkshopId, setBookingWorkshopId] = useState<string | null>(null);

  const handleRegisterClick = (workshopId: string) => {
    setBookingWorkshopId(workshopId);
  };

  const confirmRegistration = () => {
    if (!selectedStudentId || !bookingWorkshopId) return;
    const student = students.find((s) => s.id === selectedStudentId);
    if (!student) return;

    setRegisteredWorkshops((prev) => {
      const currentStudents = prev[bookingWorkshopId] || [];
      if (currentStudents.includes(student.name)) {
        alert(`${student.name} is already registered for this workshop!`);
        return prev;
      }
      return {
        ...prev,
        [bookingWorkshopId]: [...currentStudents, student.name],
      };
    });

    setBookingWorkshopId(null);
    alert(`Success! ${student.name} has been registered for the workshop.`);
  };

  return (
    <div id="workshops-schedule" className="space-y-6">
      <div className="border-b-4 border-legored pb-3 mb-6">
        <h3 className="font-bangers text-3xl text-black tracking-widest uppercase" style={{ textShadow: '1px 1px 0px rgba(0,0,0,0.05)' }}>
          UPCOMING LEGO WORKSHOPS
        </h3>
        <p className="text-sm font-semibold text-gray-600 font-blueberry">
          Sign up your student builder for interactive structural mechanics and educational courses.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {workshops.map((workshop) => {
          const registered = registeredWorkshops[workshop.id] || [];
          const isFull = workshop.spotsLeft - registered.length <= 0;
          const spotsAvailable = Math.max(0, workshop.spotsLeft - registered.length);

          return (
            <div
              key={workshop.id}
              className="bg-white rounded-2xl border-4 border-black p-6 flex flex-col justify-between shadow-[8px_8px_0px_#E3000B] relative transition-all hover:translate-y-[-2px]"
            >
              {/* Category tag */}
              <div className="absolute top-4 right-4">
                <span className="bg-legoyellow text-black font-bangers text-[10px] tracking-wider px-2.5 py-1 rounded border-2 border-black shadow-[2px_2px_0px_#000] block uppercase">
                  {workshop.tag}
                </span>
              </div>

              <div>
                <h4 className="font-bangers text-2xl text-black tracking-wide pr-32 leading-tight mb-3" style={{ textShadow: '1px 1px 0px rgba(0,0,0,0.05)' }}>
                  {workshop.title}
                </h4>
                <p className="font-blueberry text-gray-600 text-sm mb-4 leading-normal font-medium">
                  {workshop.description}
                </p>

                {/* Details layout */}
                <div className="grid grid-cols-2 gap-3 text-sm font-bold font-blueberry text-gray-700 bg-slate-50 border-2 border-black rounded-xl p-3.5 mb-4 shadow-[2px_2px_0px_#000]">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-legoblue shrink-0" />
                    <span>{workshop.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-legoblue shrink-0" />
                    <span>{workshop.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-legogreen shrink-0" />
                    <span>Age {workshop.minAge}+</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="font-extrabold text-black">{workshop.price}</span>
                  </div>
                </div>
              </div>

              {/* Booking panel */}
              <div className="border-t-2 border-dashed border-gray-200 pt-4 flex items-center justify-between gap-2">
                <div className="text-xs font-bold font-blueberry text-gray-500">
                  {isFull ? (
                    <span className="text-legored">WORKSHOP IS FULL</span>
                  ) : (
                    <span className="text-legogreen uppercase">{spotsAvailable} SPOT{spotsAvailable > 1 ? 'S' : ''} REMAINING!</span>
                  )}
                  {registered.length > 0 && (
                    <p className="text-xs text-legogreen font-extrabold mt-1">
                      Registered: {registered.join(', ')}
                    </p>
                  )}
                </div>

                {!isFull ? (
                  <button
                    type="button"
                    onClick={() => handleRegisterClick(workshop.id)}
                    className="bg-legoblue hover:opacity-95 text-white font-bangers text-xs tracking-widest uppercase px-4 py-2.5 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all cursor-pointer"
                  >
                    BOOK SPOT
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    className="bg-gray-200 text-gray-400 font-bangers text-xs tracking-widest uppercase px-4 py-2 rounded-lg border-2 border-gray-300"
                  >
                    FULL
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* QUICK WORKSHOP REGISTRATION MODAL */}
      {bookingWorkshopId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl border-4 border-black max-w-sm w-full p-6 shadow-[10px_10px_0px_#000]">
            <h3 className="font-bangers text-2xl text-black tracking-widest uppercase mb-2 flex items-center gap-1.5" style={{ textShadow: '1px 1px 0px rgba(0,0,0,0.05)' }}>
              <CheckCircle className="w-6 h-6 text-legogreen" />
              CONFIRM REGISTRATION
            </h3>
            <p className="font-blueberry text-sm text-gray-600 mb-4 leading-relaxed font-semibold">
              Choose which builder you would like to sign up for this workshop:
            </p>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 font-blueberry block mb-1.5 tracking-wider">SELECT BUILDER</label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-sm font-blueberry font-bold focus:outline-none focus:ring-2 focus:ring-legoblue shadow-[2px_2px_0px_#000] cursor-pointer"
                >
                  {students.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 justify-end pt-3 border-t-2 border-slate-150">
                <button
                  type="button"
                  onClick={() => setBookingWorkshopId(null)}
                  className="px-4 py-2 border-2 border-black rounded-lg text-xs tracking-wider uppercase font-bangers hover:bg-gray-100 cursor-pointer"
                >
                  CLOSE
                </button>
                <button
                  type="button"
                  onClick={confirmRegistration}
                  className="px-5 py-2 bg-legogreen hover:opacity-95 text-white rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all cursor-pointer"
                >
                  CONFIRM BOOKING
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
