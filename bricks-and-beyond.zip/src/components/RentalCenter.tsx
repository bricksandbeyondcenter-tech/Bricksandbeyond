import React, { useState } from 'react';
import { LegoSet, Student } from '../types';
import { Package, Search, Filter, BookOpen, AlertCircle, Sparkles, Check, CheckCircle, ArrowRight, X } from 'lucide-react';

interface RentalCenterProps {
  students: Student[];
  legoSets: LegoSet[];
  setLegoSets: React.Dispatch<React.SetStateAction<LegoSet[]>>;
}

export const RentalCenter: React.FC<RentalCenterProps> = ({ students, legoSets, setLegoSets }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTheme, setSelectedTheme] = useState('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  
  // Renting Modal States
  const [rentingSet, setRentingSet] = useState<LegoSet | null>(null);
  const [renterStudentId, setRenterStudentId] = useState('');
  const [renterEmail, setRenterEmail] = useState('');
  const [rentSuccessMessage, setRentSuccessMessage] = useState('');

  // Extract unique themes for filter dropdown
  const uniqueThemes = ['All', ...Array.from(new Set(legoSets.map(set => set.theme)))];

  // Filter logic
  const filteredSets = legoSets.filter(set => {
    const matchesSearch = set.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          set.theme.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTheme = selectedTheme === 'All' || set.theme === selectedTheme;
    const matchesDifficulty = selectedDifficulty === 'All' || set.difficulty === selectedDifficulty;
    return matchesSearch && matchesTheme && matchesDifficulty;
  });

  const handleOpenRentModal = (set: LegoSet) => {
    setRentingSet(set);
    setRenterStudentId(students[0]?.id || '');
    setRenterEmail(students[0]?.parentEmail || '');
    setRentSuccessMessage('');
  };

  const handleStudentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const studentId = e.target.value;
    setRenterStudentId(studentId);
    const student = students.find(s => s.id === studentId);
    if (student) {
      setRenterEmail(student.parentEmail);
    }
  };

  const handleConfirmRental = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rentingSet || !renterStudentId) return;

    const student = students.find(s => s.id === renterStudentId);
    if (!student) return;

    // Update LegoSet state
    setLegoSets(prevSets => prevSets.map(set => {
      if (set.id === rentingSet.id) {
        return {
          ...set,
          rented: true,
          rentedByStudentId: student.id,
          rentedByStudentName: student.name,
          rentedDate: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
          parentEmail: renterEmail
        };
      }
      return set;
    }));

    setRentSuccessMessage(`SUCCESS! "${rentingSet.name}" has been registered for rental under ${student.name.toUpperCase()}! Please pick up the box and manual from our coach front desk.`);
    
    // Auto close after some time
    setTimeout(() => {
      setRentingSet(null);
      setRentSuccessMessage('');
    }, 4000);
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans pb-12" id="lego-rental-center">
      {/* Hero Header Card */}
      <div className="bg-white border-4 border-black rounded-3xl p-8 shadow-[8px_8px_0px_#FFD500] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-36 h-36 bg-legoyellow opacity-20 rounded-full blur-2xl transform translate-x-8 -translate-y-8"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-legoblue opacity-10 rounded-full blur-3xl transform -translate-x-12 translate-y-12"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl text-left">
            <span className="bg-legoblue text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-md border-2 border-black inline-block font-mono">
              CREATIVE PLAY EXTENSION
            </span>
            <h1 className="font-bangers text-4xl tracking-widest text-black uppercase leading-tight" style={{ textShadow: '1px 1px 0px rgba(0,0,0,0.05)' }}>
              LEGO RENTAL INVENTORY
            </h1>
            <p className="text-sm md:text-base leading-relaxed text-slate-700 font-semibold font-sans">
              Want to continue building your structural designs at home? Rent our specialty high-difficulty sets, 
              including LEGO Technic, Star Wars, and Harry Potter series. Return them completed to earn extra bonus merit points!
            </p>
          </div>
          
          <div className="flex flex-col items-center justify-center p-5 border-4 border-black bg-legoyellow rounded-2xl shadow-[4px_4px_0px_#000] min-w-[220px] shrink-0 transform rotate-1">
            <Package className="w-10 h-10 text-neutral-800 mb-2 animate-bounce" />
            <h4 className="font-bangers text-xl text-black">FREE ACTIVE RENTALS</h4>
            <p className="text-[10px] font-mono font-bold text-neutral-600 mt-1 uppercase text-center leading-tight">
              AVAILABLE FOR ALL SYSTEM ADVENTURER & MASTER BUILDERS
            </p>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar controls */}
      <div className="bg-slate-50 border-4 border-black rounded-2xl p-4 md:p-6 shadow-[5px_5px_0px_#000] flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search by LEGO set name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border-2 border-black rounded-xl text-xs font-semibold bg-white font-mono"
          />
        </div>

        <div className="flex flex-wrap gap-3 items-center w-full md:w-auto justify-end font-blueberry">
          <div className="flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-neutral-500" />
            <span className="text-xs font-bold text-gray-500 uppercase font-mono">THEME:</span>
          </div>
          <select
            value={selectedTheme}
            onChange={(e) => setSelectedTheme(e.target.value)}
            className="bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-bold font-mono"
          >
            {uniqueThemes.map(theme => (
              <option key={theme} value={theme}>{theme}</option>
            ))}
          </select>

          <span className="text-xs font-bold text-gray-500 uppercase font-mono">DIFFICULTY:</span>
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-bold font-mono"
          >
            <option value="All">All Difficulty</option>
            <option value="Beginner">Beginner</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Master">Master</option>
          </select>
        </div>
      </div>

      {/* Grid displaying Lego sets */}
      {filteredSets.length === 0 ? (
        <div className="bg-white border-4 border-black border-dashed rounded-3xl p-12 text-center max-w-md mx-auto">
          <AlertCircle className="w-12 h-12 text-neutral-400 mx-auto mb-3" />
          <h4 className="font-bangers text-2xl text-black">NO MATCHING SETS FOUND</h4>
          <p className="text-xs font-semibold text-gray-500 mt-1 font-mono uppercase">
            Try adjusting your search filters or theme selection to see available brick models.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSets.map(set => {
            const isRented = set.rented;
            
            return (
              <div
                key={set.id}
                className={`bg-white rounded-2xl border-4 border-black p-5 flex flex-col justify-between shadow-[6px_6px_0px_#000] transition-all relative ${
                  isRented ? 'opacity-85' : 'hover:translate-y-[-2px]'
                }`}
              >
                {/* Theme indicator tag */}
                <div className="absolute top-4 right-4">
                  <span className="bg-legoblue text-white font-bangers text-[9px] tracking-widest px-2 py-0.5 rounded border border-black uppercase font-mono">
                    {set.theme}
                  </span>
                </div>

                <div className="space-y-3 text-left">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-mono font-black uppercase px-2 py-0.5 rounded border ${
                      set.difficulty === 'Master' ? 'bg-red-100 text-red-700 border-red-300' :
                      set.difficulty === 'Intermediate' ? 'bg-amber-100 text-amber-700 border-amber-300' :
                      'bg-green-100 text-green-700 border-green-300'
                    }`}>
                      {set.difficulty}
                    </span>
                    <span className="text-[10px] font-mono font-bold text-gray-400">
                      {set.pieces} Pieces
                    </span>
                  </div>

                  <h3 className="font-bangers text-xl text-black leading-snug pr-12 uppercase tracking-wide">
                    {set.name}
                  </h3>

                  {isRented ? (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-left font-mono text-[10px] text-red-950 font-semibold space-y-1">
                      <span className="text-red-700 font-extrabold block">CURRENTLY RENTED OUT</span>
                      <span>Builder: <strong className="font-bold">{set.rentedByStudentName?.toUpperCase()}</strong></span>
                      <span className="block text-neutral-500">Rent Date: {set.rentedDate}</span>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-left font-mono text-[10px] text-emerald-950 font-semibold">
                      <span className="text-emerald-700 font-extrabold block flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" /> AVAILABLE FOR RENTAL
                      </span>
                      <span className="text-neutral-500 block mt-0.5 leading-tight">Can be rented for up to 14 days of educational build time at home.</span>
                    </div>
                  )}
                </div>

                <div className="mt-5 pt-3 border-t-2 border-dashed border-neutral-100">
                  {isRented ? (
                    <button
                      disabled
                      className="w-full bg-slate-100 text-neutral-400 border-2 border-neutral-300 font-bangers text-xs tracking-widest py-2 rounded-xl cursor-not-allowed uppercase"
                    >
                      OUT OF STOCK
                    </button>
                  ) : (
                    <button
                      onClick={() => handleOpenRentModal(set)}
                      className="w-full bg-legoyellow hover:bg-yellow-400 text-black border-2 border-black font-bangers text-xs tracking-widest py-2 rounded-xl shadow-[3px_3px_0px_#000] active:translate-y-0.5 transition-all flex items-center justify-center gap-1.5 cursor-pointer uppercase"
                    >
                      <BookOpen className="w-4 h-4" />
                      RENT THIS LEGO SET
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Rental Transaction Modal */}
      {rentingSet && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white border-4 border-black rounded-3xl max-w-md w-full overflow-hidden shadow-[8px_8px_0px_#000] relative">
            {/* Header top bar color */}
            <div className="bg-legoyellow border-b-4 border-black p-4 flex justify-between items-center">
              <h3 className="font-bangers text-xl text-black flex items-center gap-1.5 tracking-wide">
                <Sparkles className="w-5 h-5 text-indigo-700" />
                SECURE LEGO RENTAL REGISTER
              </h3>
              <button
                onClick={() => setRentingSet(null)}
                className="bg-legored hover:opacity-90 text-white border-2 border-black p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {rentSuccessMessage ? (
              <div className="p-6 text-center space-y-4">
                <div className="bg-green-100 border-2 border-green-500 text-green-950 rounded-xl p-4 text-xs font-mono font-bold leading-relaxed">
                  {rentSuccessMessage}
                </div>
                <button
                  onClick={() => setRentingSet(null)}
                  className="px-6 py-2 bg-black text-white font-bangers text-xs uppercase tracking-widest rounded-xl border-2 border-black shadow-[2px_2px_0px_rgba(0,0,0,0.25)]"
                >
                  CLOSE
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmRental} className="p-6 space-y-4 text-left">
                <div className="bg-slate-50 border-2 border-black p-3.5 rounded-xl text-xs font-semibold leading-relaxed font-sans">
                  <span className="font-mono text-neutral-400 block font-bold text-[9px] uppercase">Lego Set Selected:</span>
                  <span className="font-bangers text-base tracking-wide text-black block mt-0.5">{rentingSet.name}</span>
                  <span className="font-mono text-neutral-500 text-[10px] block font-bold">
                    Difficulty: {rentingSet.difficulty} | {rentingSet.pieces} pieces
                  </span>
                </div>

                {students.length === 0 ? (
                  <div className="bg-yellow-50 border-2 border-dashed border-yellow-400 rounded-xl p-4 text-xs font-bold text-indigo-900 leading-normal text-center">
                    There are no students registered on the system yet! Please go to the Check-In Station and register a child account first.
                  </div>
                ) : (
                  <>
                    <div className="space-y-1.5 font-blueberry">
                      <label className="block text-[10px] font-mono font-black text-neutral-500 uppercase tracking-widest">
                        CHOOSE REGISTERED BUILDER *
                      </label>
                      <select
                        required
                        value={renterStudentId}
                        onChange={handleStudentChange}
                        className="w-full bg-white border-2 border-black rounded-xl px-3 py-2 text-xs font-bold"
                      >
                        {students.map(s => (
                          <option key={s.id} value={s.id}>{s.name.toUpperCase()} (Parent: {s.parentName})</option>
                        ))}
                      </select>
                      <p className="text-[9px] text-gray-400 leading-tight">
                        Rental registers must be mapped directly to registered student accounts for monitoring.
                      </p>
                    </div>

                    <div className="space-y-1.5 font-blueberry">
                      <label className="block text-[10px] font-mono font-black text-neutral-500 uppercase tracking-widest">
                        PARENT CONTACT EMAIL *
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="parent@example.com"
                        value={renterEmail}
                        onChange={(e) => setRenterEmail(e.target.value)}
                        className="w-full bg-white border-2 border-black rounded-xl px-3 py-2 text-xs font-mono font-semibold"
                      />
                    </div>

                    <div className="pt-3 border-t border-dashed border-neutral-200 flex gap-3 justify-end font-bangers tracking-wider">
                      <button
                        type="button"
                        onClick={() => setRentingSet(null)}
                        className="px-4 py-2 bg-white hover:bg-neutral-50 border-2 border-black rounded-lg text-xs"
                      >
                        CANCEL
                      </button>
                      <button
                        type="submit"
                        className="px-5 py-2 bg-legogreen hover:opacity-95 text-white border-2 border-black rounded-lg text-xs shadow-[3px_3px_0px_#000] active:translate-y-0.5"
                      >
                        CONFIRM RENTAL
                      </button>
                    </div>
                  </>
                )}
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
