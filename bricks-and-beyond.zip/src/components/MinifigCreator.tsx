import React, { useState } from 'react';
import { MinifigStyle } from '../types';
import { MinifigAvatar } from './MinifigAvatar';
import { Sparkles, Shuffle, Check, Undo } from 'lucide-react';

interface MinifigCreatorProps {
  initialStyle?: MinifigStyle;
  onSave: (style: MinifigStyle) => void;
  onCancel?: () => void;
  studentName?: string;
}

const HAIR_TYPES: { id: MinifigStyle['hairType']; label: string }[] = [
  { id: 'classic', label: 'Classic Bob' },
  { id: 'spiky', label: 'Brick Spike' },
  { id: 'long', label: 'Flowing Locks' },
  { id: 'cap', label: 'Baseball Cap' },
  { id: 'wizard', label: 'Wizard Hat' },
  { id: 'helmet', label: 'Space Helmet' },
];

const HAIR_COLORS = [
  { value: '#78350F', label: 'Brown' },
  { value: '#171717', label: 'Raven' },
  { value: '#EAB308', label: 'Blonde' },
  { value: '#DC2626', label: 'Ginger' },
  { value: '#3B82F6', label: 'Brick Blue' },
  { value: '#8B5CF6', label: 'Royal Violet' },
  { value: '#10B981', label: 'Neon Green' },
];

const EXPRESSIONS: { id: MinifigStyle['expression']; label: string }[] = [
  { id: 'smile', label: 'Sunny Smile' },
  { id: 'wink', label: 'Cheeky Wink' },
  { id: 'cool', label: 'Retro Shades' },
  { id: 'glasses', label: 'Brite Specs' },
  { id: 'determined', label: 'Master Mind' },
];

const TORSO_COLORS = [
  { value: '#EF4444', label: 'Cherry Red' },
  { value: '#3B82F6', label: 'Royal Blue' },
  { value: '#10B981', label: 'Forest Green' },
  { value: '#EAB308', label: 'Bright Yellow' },
  { value: '#F97316', label: 'Safety Orange' },
  { value: '#EC4899', label: 'Bubblegum Pink' },
  { value: '#1E293B', label: 'Space Slate' },
];

const TORSO_PRINTS: { id: MinifigStyle['torsoPrint']; label: string }[] = [
  { id: 'none', label: 'Plain Tee' },
  { id: 'brick', label: '2x2 Stud' },
  { id: 'classic-space', label: 'Classic Space' },
  { id: 'ninja', label: 'Ninja Star' },
  { id: 'heart', label: 'Lego Heart' },
  { id: 'tie', label: 'Check-In Tie' },
];

const LEGS_COLORS = [
  { value: '#1E3A8A', label: 'Blue Jeans' },
  { value: '#1F2937', label: 'Dark Gray' },
  { value: '#7F1D1D', label: 'Burgundy' },
  { value: '#064E3B', label: 'Spy Green' },
  { value: '#EAB308', label: 'Yellow Leggings' },
  { value: '#000000', label: 'Classic Black' },
];

const defaultMinifigStyle: MinifigStyle = {
  hairType: 'classic',
  hairColor: '#78350F',
  expression: 'smile',
  torsoColor: '#EF4444',
  torsoPrint: 'brick',
  legsColor: '#1E3A8A',
};

export const MinifigCreator: React.FC<MinifigCreatorProps> = ({
  initialStyle,
  onSave,
  onCancel,
  studentName = "Your Minifig",
}) => {
  const [style, setStyle] = useState<MinifigStyle>(initialStyle || defaultMinifigStyle);

  const updateField = <K extends keyof MinifigStyle>(field: K, value: MinifigStyle[K]) => {
    setStyle((prev) => ({ ...prev, [field]: value }));
  };

  const handleRandomize = () => {
    const randomHair = HAIR_TYPES[Math.floor(Math.random() * HAIR_TYPES.length)].id;
    const randomHairColor = HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)].value;
    const randomExpr = EXPRESSIONS[Math.floor(Math.random() * EXPRESSIONS.length)].id;
    const randomTorso = TORSO_COLORS[Math.floor(Math.random() * TORSO_COLORS.length)].value;
    const randomPrint = TORSO_PRINTS[Math.floor(Math.random() * TORSO_PRINTS.length)].id;
    const randomLegs = LEGS_COLORS[Math.floor(Math.random() * LEGS_COLORS.length)].value;

    setStyle({
      hairType: randomHair,
      hairColor: randomHairColor,
      expression: randomExpr,
      torsoColor: randomTorso,
      torsoPrint: randomPrint,
      legsColor: randomLegs,
    });
  };

  return (
    <div id="minifig-creator" className="bg-white rounded-2xl border-4 border-black p-6 shadow-[8px_8px_0px_#FFD500] max-w-4xl mx-auto my-4">
      <div className="flex flex-col md:flex-row gap-8 items-center">
        {/* Visual Preview Panel */}
        <div className="w-full md:w-2/5 flex flex-col items-center bg-slate-50 rounded-xl border-4 border-black p-6 relative overflow-hidden h-72 md:h-96 justify-center shadow-[4px_4px_0px_#000]">
          {/* Legos floating in background decoration */}
          <div className="absolute top-2 left-2 w-8 h-4 bg-legored rounded border-2 border-black rotate-12 opacity-60"></div>
          <div className="absolute bottom-4 right-4 w-6 h-6 bg-legoyellow rounded-full border-2 border-black opacity-60"></div>
          <div className="absolute top-1/4 right-2 w-10 h-6 bg-legogreen rounded border-2 border-black -rotate-45 opacity-40"></div>

          <MinifigAvatar style={style} size={180} className="z-10 drop-shadow-[4px_4px_0px_rgba(0,0,0,0.15)]" />

          <div className="mt-4 bg-legoyellow border-2 border-black px-4 py-1.5 rounded-lg shadow-[3px_3px_0px_#000] z-10">
            <span className="font-bangers text-lg text-black tracking-widest uppercase">
              {studentName}
            </span>
          </div>

          <button
            type="button"
            id="randomize-minifig-btn"
            onClick={handleRandomize}
            className="absolute bottom-3 left-3 bg-white hover:bg-yellow-100 border-2 border-black p-2 rounded-full shadow-[2.5px_2.5px_0px_#000] transition-all active:translate-y-0.5 cursor-pointer"
            title="Randomize Parts"
          >
            <Shuffle className="w-5 h-5 text-black" />
          </button>
        </div>

        {/* Customization Controls */}
        <div className="w-full md:w-3/5 space-y-4">
          <div className="border-b-4 border-black pb-3 mb-4">
            <h3 className="font-bangers text-2xl text-black tracking-widest uppercase flex items-center gap-2">
              <Sparkles className="text-legoyellow w-6 h-6 fill-yellow-250 animate-bounce" />
              MINIFIG BUILDER
            </h3>
            <p className="text-sm text-gray-600 font-semibold font-blueberry uppercase">
              Tap buttons to change hair, expressions, and cool print designs!
            </p>
          </div>

          <div className="max-h-[300px] overflow-y-auto space-y-4 pr-1">
            {/* Hair Style */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">1. HAIR STYLE</label>
              <div className="flex flex-wrap gap-1.5">
                {HAIR_TYPES.map((hair) => (
                  <button
                    key={hair.id}
                    type="button"
                    onClick={() => updateField('hairType', hair.id)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg border-2 border-black transition-all cursor-pointer ${
                      style.hairType === hair.id
                        ? 'bg-legoyellow text-black shadow-[3px_3px_0px_#000]'
                        : 'bg-slate-50 hover:bg-slate-100 text-gray-800 shadow-[1px_1px_0px_#000]'
                    }`}
                  >
                    {hair.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Hair Color */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">2. HAIR COLOR</label>
              <div className="flex flex-wrap gap-2">
                {HAIR_COLORS.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => updateField('hairColor', color.value)}
                    style={{ backgroundColor: color.value }}
                    className={`w-6 h-6 rounded-full border-2 border-black transition-transform cursor-pointer ${
                      style.hairColor === color.value ? 'scale-125 ring-2 ring-legoyellow ring-offset-1' : 'hover:scale-110'
                    }`}
                    title={color.label}
                  />
                ))}
              </div>
            </div>

            {/* Face Expressions */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">3. EXPRESSION</label>
              <div className="flex flex-wrap gap-1.5">
                {EXPRESSIONS.map((expr) => (
                  <button
                    key={expr.id}
                    type="button"
                    onClick={() => updateField('expression', expr.id)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg border-2 border-black transition-all cursor-pointer ${
                      style.expression === expr.id
                        ? 'bg-legoyellow text-black shadow-[3px_3px_0px_#000]'
                        : 'bg-slate-50 hover:bg-slate-100 text-gray-800 shadow-[1px_1px_0px_#000]'
                    }`}
                  >
                    {expr.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Shirt Color */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">4. TORSO SHIRT COLOR</label>
              <div className="flex flex-wrap gap-2">
                {TORSO_COLORS.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => updateField('torsoColor', color.value)}
                    style={{ backgroundColor: color.value }}
                    className={`w-6 h-6 rounded-full border-2 border-black transition-transform cursor-pointer ${
                      style.torsoColor === color.value ? 'scale-125 ring-2 ring-legoyellow ring-offset-1' : 'hover:scale-110'
                    }`}
                    title={color.label}
                  />
                ))}
              </div>
            </div>

            {/* Shirt Print */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">5. SHIRT DESIGN</label>
              <div className="flex flex-wrap gap-1.5">
                {TORSO_PRINTS.map((print) => (
                  <button
                    key={print.id}
                    type="button"
                    onClick={() => updateField('torsoPrint', print.id)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-lg border-2 border-black transition-all cursor-pointer ${
                      style.torsoPrint === print.id
                        ? 'bg-legoyellow text-black shadow-[3px_3px_0px_#000]'
                        : 'bg-slate-50 hover:bg-slate-100 text-gray-800 shadow-[1px_1px_0px_#000]'
                    }`}
                  >
                    {print.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Pants Color */}
            <div className="space-y-1.5">
              <label className="text-xs font-bangers text-black tracking-widest block uppercase">6. PANTS COLOR</label>
              <div className="flex flex-wrap gap-2">
                {LEGS_COLORS.map((color) => (
                  <button
                    key={color.value}
                    type="button"
                    onClick={() => updateField('legsColor', color.value)}
                    style={{ backgroundColor: color.value }}
                    className={`w-6 h-6 rounded-full border-2 border-black transition-transform cursor-pointer ${
                      style.legsColor === color.value ? 'scale-125 ring-2 ring-legoyellow ring-offset-1' : 'hover:scale-110'
                    }`}
                    title={color.label}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-3 justify-end border-t border-slate-100">
            {onCancel && (
              <button
                type="button"
                onClick={onCancel}
                className="px-5 py-2.5 rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase hover:bg-gray-100 active:translate-y-0.5 transition-all text-black cursor-pointer"
              >
                BACK
              </button>
            )}
            <button
              type="button"
              id="save-minifig-creator-btn"
              onClick={() => onSave(style)}
              className="px-6 py-2.5 bg-legogreen hover:opacity-95 rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase text-white shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Check className="w-5 h-5" />
              FINISH AVATAR
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
