import React, { useState } from 'react';
import { Student, Workshop, Staff, DailyTask, AdminNotification, CheckInLog, Booking, CalendarEvent, LegoSet } from '../types';
import { MinifigAvatar } from './MinifigAvatar';
import { GoogleSheetsConfig } from './GoogleSheetsConfig';
import {
  Lock,
  Unlock,
  Users,
  Calendar,
  CheckSquare,
  Square,
  Plus,
  Trash2,
  Edit3,
  UserPlus,
  Check,
  X,
  Clock,
  Sparkles,
  Award,
  ChevronRight,
  ShieldCheck,
  LogOut,
  CalendarDays,
  FileSpreadsheet,
  Bell,
  Settings,
  Eye,
  EyeOff,
  UserCheck,
  Search,
  Package,
  BookOpen
} from 'lucide-react';

interface AdminPortalProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  workshops: Workshop[];
  setWorkshops: React.Dispatch<React.SetStateAction<Workshop[]>>;
  registeredWorkshops: { [key: string]: string[] };
  setRegisteredWorkshops: React.Dispatch<React.SetStateAction<{ [key: string]: string[] }>>;
  staff: Staff[];
  setStaff: React.Dispatch<React.SetStateAction<Staff[]>>;
  tasks: DailyTask[];
  setTasks: React.Dispatch<React.SetStateAction<DailyTask[]>>;
  onStaffCheckIn: (staffId: string, isCheckIn: boolean) => void;
  onCustomizeStaffAvatar: (staffId: string) => void;

  // Google Sheets configurations
  logs: CheckInLog[];
  googleClientId: string;
  setGoogleClientId: (id: string) => void;
  spreadsheetId: string;
  setSpreadsheetId: (id: string) => void;
  accessToken: string | null;
  onGoogleLogin: () => void;
  onSyncLogs: () => Promise<void>;
  isSyncing: boolean;

  // Notifications
  notifications: AdminNotification[];
  setNotifications: React.Dispatch<React.SetStateAction<AdminNotification[]>>;

  // Bookings
  bookings: Booking[];
  setBookings: React.Dispatch<React.SetStateAction<Booking[]>>;

  // Admin session synchronization
  isAdminLoggedIn: boolean;
  setIsAdminLoggedIn: (val: boolean) => void;

  // Calendar and Rentals
  events: CalendarEvent[];
  setEvents: React.Dispatch<React.SetStateAction<CalendarEvent[]>>;
  legoSets: LegoSet[];
  setLegoSets: React.Dispatch<React.SetStateAction<LegoSet[]>>;
}

const DAYS_OF_WEEK = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday', 'All Days'] as const;

export const AdminPortal: React.FC<AdminPortalProps> = ({
  students,
  setStudents,
  workshops,
  setWorkshops,
  registeredWorkshops,
  setRegisteredWorkshops,
  staff,
  setStaff,
  tasks,
  setTasks,
  onStaffCheckIn,
  onCustomizeStaffAvatar,
  logs,
  googleClientId,
  setGoogleClientId,
  spreadsheetId,
  setSpreadsheetId,
  accessToken,
  onGoogleLogin,
  onSyncLogs,
  isSyncing,
  notifications,
  setNotifications,
  bookings,
  setBookings,
  isAdminLoggedIn,
  setIsAdminLoggedIn,
  events,
  setEvents,
  legoSets,
  setLegoSets
}) => {
  // Passcode gate state
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [passwordError, setPasswordError] = useState<string>('');
  const [showPasswordMask, setShowPasswordMask] = useState<boolean>(false);

  // Active Admin Subsystem Tab
  const [panelTab, setPanelTab] = useState<'staff' | 'students' | 'workshops' | 'tasks' | 'sheets' | 'notifications' | 'security' | 'bookings' | 'rentals' | 'calendar'>('staff');

  // Bookings filter states
  const [bookingSearchQuery, setBookingSearchQuery] = useState('');
  const [bookingTypeFilter, setBookingTypeFilter] = useState<'All' | 'Power Hour' | 'Workshop/Camp'>('All');

  // Rentals inventory admin states
  const [newSetName, setNewSetName] = useState('');
  const [newSetTheme, setNewSetTheme] = useState('Technic');
  const [newSetPieces, setNewSetPieces] = useState(500);
  const [newSetDiff, setNewSetDiff] = useState<'Beginner' | 'Intermediate' | 'Master'>('Intermediate');

  // Calendar scheduler admin states
  const [evtTitle, setEvtTitle] = useState('');
  const [evtDesc, setEvtDesc] = useState('');
  const [evtDate, setEvtDate] = useState('2026-07-20');
  const [evtType, setEvtType] = useState<'Camp' | 'Workshop' | 'Holiday' | 'Special Event'>('Camp');

  // Staff registry modal and search state
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffFields, setNewStaffFields] = useState({ name: '', role: '', password: '' });
  const [staffSearchQuery, setStaffSearchQuery] = useState('');

  // Student directory search state
  const [studentSearchQuery, setStudentSearchQuery] = useState('');
  const [studentFilter, setStudentFilter] = useState<'All' | 'Master Builder' | 'Adventurer' | 'Not a Member'>('All');

  // Workshop Subsystem State
  const [editingWorkshopId, setEditingWorkshopId] = useState<string | null>(null);
  const [showAddWorkshopModal, setShowAddWorkshopModal] = useState(false);
  const [workshopForm, setWorkshopForm] = useState<Omit<Workshop, 'id'>>({
    title: '',
    description: '',
    date: '',
    time: '',
    minAge: 6,
    spotsLeft: 10,
    price: '$20 / session',
    tag: 'Engineering',
  });

  // Tasks Subsystem State
  const [activeTaskDay, setActiveTaskDay] = useState<typeof DAYS_OF_WEEK[number]>('All Days');
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskDay, setNewTaskDay] = useState<typeof DAYS_OF_WEEK[number]>('All Days');
  const [newTaskAssignedTo, setNewTaskAssignedTo] = useState<string>('');

  // Security password change states
  const [newPassword, setNewPassword] = useState('');
  const [currentPasswordConfirm, setCurrentPasswordConfirm] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [securitySuccess, setSecuritySuccess] = useState('');
  const [securityError, setSecurityError] = useState('');

  const [newStaffPassword, setNewStaffPassword] = useState('');
  const [currentStaffPasswordConfirm, setCurrentStaffPasswordConfirm] = useState('');
  const [confirmNewStaffPassword, setConfirmNewStaffPassword] = useState('');
  const [staffSecuritySuccess, setStaffSecuritySuccess] = useState('');
  const [staffSecurityError, setStaffSecurityError] = useState('');

  // Password retrieval logic
  const getAdminPassword = (): string => {
    return localStorage.getItem('bricks_admin_password') || 'admin';
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const correctPassword = getAdminPassword();
    
    if (passwordInput === correctPassword) {
      setIsAdminLoggedIn(true);
      sessionStorage.setItem('bricks_admin_auth', 'true');
      setPasswordInput('');
      setPasswordError('');
    } else {
      setPasswordError(`INCORRECT PASSWORD! ACCESS DENIED. Please try again.`);
    }
  };

  const handleLogout = () => {
    setIsAdminLoggedIn(false);
    sessionStorage.removeItem('bricks_admin_auth');
  };

  const handleUpdateStaffPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setStaffSecurityError('');
    setStaffSecuritySuccess('');

    const currentStaffPass = localStorage.getItem('bricks_staff_password') || 'staff';

    if (currentStaffPasswordConfirm !== currentStaffPass) {
      setStaffSecurityError('Current Staff Password is incorrect!');
      return;
    }

    if (!newStaffPassword.trim()) {
      setStaffSecurityError('New Staff Password cannot be empty.');
      return;
    }

    if (newStaffPassword !== confirmNewStaffPassword) {
      setStaffSecurityError('New Staff Passwords do not match.');
      return;
    }

    localStorage.setItem('bricks_staff_password', newStaffPassword.trim());
    setStaffSecuritySuccess('Staff password updated successfully!');
    setCurrentStaffPasswordConfirm('');
    setNewStaffPassword('');
    setConfirmNewStaffPassword('');
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError('');
    setSecuritySuccess('');

    const currentPass = getAdminPassword();

    if (currentPasswordConfirm !== currentPass) {
      setSecurityError('Current Password is incorrect!');
      return;
    }

    if (!newPassword.trim()) {
      setSecurityError('New Password cannot be empty.');
      return;
    }

    if (newPassword !== confirmNewPassword) {
      setSecurityError('New Passwords do not match.');
      return;
    }

    localStorage.setItem('bricks_admin_password', newPassword.trim());
    setSecuritySuccess('Admin password updated successfully! Please use your new password next time.');
    setCurrentPasswordConfirm('');
    setNewPassword('');
    setConfirmNewPassword('');
  };

  // Staff roster actions
  const handleAddStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaffFields.name || !newStaffFields.role) {
      alert("Please fill in staff name and role!");
      return;
    }

    const randomAvatar: any = {
      hairType: ['spiky', 'classic', 'long', 'cap', 'helmet'][Math.floor(Math.random() * 5)],
      hairColor: ['#171717', '#78350F', '#EAB308', '#9333EA'][Math.floor(Math.random() * 4)],
      expression: ['smile', 'wink', 'cool', 'determined'][Math.floor(Math.random() * 4)],
      torsoColor: ['#EF4444', '#3B82F6', '#10B981', '#F59E0B'][Math.floor(Math.random() * 4)],
      torsoPrint: ['classic-space', 'brick', 'ninja', 'heart', 'tie'][Math.floor(Math.random() * 5)],
      legsColor: ['#1E3A8A', '#000000', '#F3F4F6', '#1F2937'][Math.floor(Math.random() * 4)],
    };

    const newMember: Staff = {
      id: `staff_${Date.now()}`,
      name: newStaffFields.name,
      role: newStaffFields.role,
      avatar: randomAvatar,
      checkedInToday: false,
      hoursWorked: 0,
      clockedIn: false,
      password: newStaffFields.password.trim() || 'staff'
    };

    setStaff(prev => [...prev, newMember]);
    setNewStaffFields({ name: '', role: '', password: '' });
    setShowAddStaffModal(false);
  };

  const handleRemoveStaff = (id: string, name: string) => {
    if (confirm(`Are you sure you want to PERMANENTLY remove staff member ${name}? This will delete their hours tracked in this session.`)) {
      setStaff(prev => prev.filter(s => s.id !== id));
    }
  };

  // Student directory operations
  const handleRemoveStudent = (id: string, name: string) => {
    if (confirm(`DANGER: Are you sure you want to remove student member "${name}"? This action cannot be undone.`)) {
      setStudents(prev => prev.filter(s => s.id !== id));
    }
  };

  // Workshop orchestration
  const handleCreateWorkshop = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workshopForm.title || !workshopForm.date || !workshopForm.time) {
      alert("Please fill in workshop title, date, and time!");
      return;
    }

    const newWk: Workshop = {
      ...workshopForm,
      id: `wk_${Date.now()}`,
    };

    setWorkshops(prev => [...prev, newWk]);
    setShowAddWorkshopModal(false);
    resetWorkshopForm();
  };

  const triggerEditWorkshop = (wk: Workshop) => {
    setEditingWorkshopId(wk.id);
    setWorkshopForm({
      title: wk.title,
      description: wk.description,
      date: wk.date,
      time: wk.time,
      minAge: wk.minAge,
      spotsLeft: wk.spotsLeft,
      price: wk.price,
      tag: wk.tag,
    });
  };

  const handleSaveWorkshopEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingWorkshopId) return;

    setWorkshops(prev => prev.map(wk => {
      if (wk.id === editingWorkshopId) {
        return {
          ...wk,
          ...workshopForm,
        };
      }
      return wk;
    }));

    setEditingWorkshopId(null);
    resetWorkshopForm();
  };

  const handleDeleteWorkshop = (id: string, title: string) => {
    if (confirm(`Are you sure you want to delete the workshop "${title}"?`)) {
      setWorkshops(prev => prev.filter(wk => wk.id !== id));
      setRegisteredWorkshops(prev => {
        const next = { ...prev };
        delete next[id];
        return next;
      });
    }
  };

  const resetWorkshopForm = () => {
    setWorkshopForm({
      title: '',
      description: '',
      date: '',
      time: '',
      minAge: 6,
      spotsLeft: 10,
      price: '$20 / session',
      tag: 'Engineering',
    });
  };

  // Daily Tasks administration
  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;

    const newTask: DailyTask = {
      id: `task_${Date.now()}`,
      text: newTaskText.trim(),
      day: newTaskDay,
      completed: false,
      assignedTo: newTaskAssignedTo || undefined,
    };

    setTasks(prev => [...prev, newTask]);
    setNewTaskText('');
    setNewTaskAssignedTo('');
  };

  const handleToggleTaskAdmin = (taskId: string) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t));
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  // Notifications filtering & management
  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  const handleMarkNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Searching & filtering data
  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(studentSearchQuery.toLowerCase()) || 
                          student.parentName.toLowerCase().includes(studentSearchQuery.toLowerCase());
    const matchesFilter = studentFilter === 'All' || student.membershipType === studentFilter;
    return matchesSearch && matchesFilter;
  });

  const filteredStaff = staff.filter(m => 
    m.name.toLowerCase().includes(staffSearchQuery.toLowerCase()) ||
    m.role.toLowerCase().includes(staffSearchQuery.toLowerCase())
  );

  const filteredTasks = tasks.filter(t => {
    if (activeTaskDay === 'All Days') return true;
    return t.day === activeTaskDay || t.day === 'All Days';
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  // 1. GATED ENTRY: SECURITY PASSWORD VIEW
  if (!isAdminLoggedIn) {
    return (
      <div className="max-w-md mx-auto my-12 animate-fade-in font-sans p-2">
        <div className="bg-white border-4 border-black rounded-2xl overflow-hidden shadow-[8px_8px_0px_#000]">
          <div className="bg-legored text-white px-6 py-4 border-b-4 border-black flex items-center justify-between">
            <h3 className="font-bangers text-2xl tracking-widest flex items-center gap-2">
              <Lock className="w-5 h-5" />
              ADMIN SECURE CONTROL
            </h3>
            <span className="bg-yellow-400 text-black font-bangers text-[10px] tracking-widest px-2.5 py-1 rounded border-2 border-black uppercase leading-none">
              SECURE
            </span>
          </div>

          <div className="p-6 space-y-6 text-left">
            <div className="flex justify-center flex-col items-center gap-2 border-b border-dashed border-neutral-200 pb-4">
              <ShieldCheck className="w-12 h-12 text-legored fill-red-100" />
              <p className="text-xs font-bold text-neutral-400 font-mono text-center uppercase tracking-wide">
                AUTHENTICATION REQUIRED
              </p>
            </div>

            <p className="text-xs font-bold text-gray-500 font-mono uppercase leading-relaxed text-center">
              Please enter your Management password to access center rosters, remove members, manage tasks, and configure cloud sheets syncing. 
            </p>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-widest block text-left">
                  ADMIN PASSCODE
                </label>
                <div className="relative">
                  <input
                    type={showPasswordMask ? 'text' : 'password'}
                    placeholder="Enter password..."
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    className="w-full bg-neutral-50 border-2 border-black rounded-xl px-4 py-3 font-mono text-sm text-black focus:outline-none focus:ring-2 focus:ring-legored shadow-[2px_2px_0px_rgba(0,0,0,1)]"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswordMask(!showPasswordMask)}
                    className="absolute right-3.5 top-3.5 text-neutral-400 hover:text-black"
                  >
                    {showPasswordMask ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {passwordError && (
                <div className="bg-red-50 border border-red-300 rounded-lg p-2.5 text-[11px] text-red-600 font-bold font-mono uppercase tracking-wide leading-relaxed">
                  {passwordError}
                </div>
              )}

              <button
                type="submit"
                className="w-full bg-legoyellow hover:bg-yellow-400 text-black font-bangers text-sm uppercase tracking-wider py-3 px-4 border-2 border-black rounded-xl shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Unlock className="w-4 h-4" />
                UNLOCK PLATFORM COMMAND
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // 2. MAIN LOGGED-IN PANEL
  return (
    <div className="space-y-6 font-sans animate-fade-in text-left">
      
      {/* Admin Title Header panel */}
      <div className="bg-white border-4 border-black p-4 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[8px_8px_0px_#008542]">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-100 border-2 border-black p-2.5 rounded-full text-legogreen shadow-[2px_2px_0px_#000] shrink-0">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <span className="bg-legogreen text-white text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded border border-black inline-block">
              SECURE ADMIN MODULE
            </span>
            <h3 className="font-bangers text-2xl text-black leading-none tracking-widest uppercase mt-1">
              EDUCATIONAL CENTER COMMAND COMMANDER
            </h3>
            <p className="text-xs font-mono font-bold text-neutral-500 block uppercase mt-0.5">
              Live secure station active. Double-challenge authority enabled.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Notifications micro indicator */}
          <button
            onClick={() => setPanelTab('notifications')}
            className={`p-2.5 border-2 border-black rounded-xl shadow-[2px_2px_0px_#000] flex items-center justify-center relative active:translate-y-0.5 ${
              panelTab === 'notifications' ? 'bg-legoyellow' : 'bg-neutral-50 hover:bg-neutral-100'
            }`}
          >
            <Bell className="w-4 h-4 text-black" />
            {unreadCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white font-mono text-[9px] font-black rounded-full w-5 h-5 flex items-center justify-center animate-bounce border border-black">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={handleLogout}
            className="bg-legored hover:bg-red-600 text-white font-bangers text-xs tracking-widest uppercase px-4 py-2.5 rounded-xl border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            LOCK WINDOW
          </button>
        </div>
      </div>

      {/* Admin Module Sub Tabs Layout */}
      <div className="flex flex-wrap gap-1 md:gap-1.5 border-b-4 border-black overflow-x-auto scroller-thick">
        <button
          onClick={() => setPanelTab('staff')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'staff'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Users className="w-4 h-4 text-legoblue" />
          STAFF ({staff.length})
        </button>

        <button
          onClick={() => setPanelTab('students')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'students'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <UserCheck className="w-4 h-4 text-emerald-500" />
          STUDENTS ({students.length})
        </button>

        <button
          onClick={() => setPanelTab('workshops')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'workshops'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Calendar className="w-4 h-4 text-legored" />
          WORKSHOPS ({workshops.length})
        </button>

        <button
          onClick={() => setPanelTab('tasks')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'tasks'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <CheckSquare className="w-4 h-4 text-purple-600" />
          TASK MANAGER ({tasks.length})
        </button>

        <button
          onClick={() => setPanelTab('sheets')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'sheets'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-green-600" />
          GOOGLE SHEET SYNC
        </button>

        <button
          onClick={() => setPanelTab('notifications')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 relative ${
            panelTab === 'notifications'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Bell className="w-4 h-4 text-orange-500" />
          ALERTS FEEDS
          {unreadCount > 0 && (
            <span className="w-2 h-2 bg-red-500 rounded-full inline-block animate-ping"></span>
          )}
        </button>

        <button
          onClick={() => setPanelTab('security')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'security'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Settings className="w-4 h-4 text-slate-700" />
          SECURITY PASSCODE
        </button>

        <button
          onClick={() => setPanelTab('bookings')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'bookings'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
          BOOKINGS SHEET
        </button>

        <button
          onClick={() => setPanelTab('rentals')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'rentals'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Package className="w-4 h-4 text-amber-500" />
          RENTALS INVENTORY
        </button>

        <button
          onClick={() => setPanelTab('calendar')}
          className={`flex items-center gap-1.5 px-4 py-2.5 font-bangers text-xs md:text-sm tracking-wider uppercase border-t-2 border-x-2 border-black rounded-t-xl transition-all shrink-0 ${
            panelTab === 'calendar'
              ? 'bg-legoyellow text-black translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-slate-50'
          }`}
        >
          <Calendar className="w-4 h-4 text-blue-600" />
          YEAR EVENTS
        </button>
      </div>

      {/* SUB-PANEL 1: STAFF DIRECTORY */}
      {panelTab === 'staff' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
                COACH & INSTRUCTOR REGISTRY
              </h4>
              <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
                Add tutors, monitor shift hours, trigger checkins, customize LEGO styles, or delete roster slots.
              </p>
            </div>
            
            <div className="flex gap-2 w-full sm:w-auto">
              <input
                type="text"
                placeholder="Search staff..."
                value={staffSearchQuery}
                onChange={(e) => setStaffSearchQuery(e.target.value)}
                className="bg-white border-2 border-black rounded-lg px-3 py-1.5 text-xs font-bold outline-none"
              />
              <button
                onClick={() => setShowAddStaffModal(true)}
                className="bg-legoblue hover:bg-blue-600 text-white font-bangers text-xs tracking-widest uppercase px-4 py-2 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 flex items-center gap-1"
              >
                <UserPlus className="w-3.5 h-3.5" />
                ADD STAFF
              </button>
            </div>
          </div>

          {/* ADD STAFF MODAL */}
          {showAddStaffModal && (
            <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl border-4 border-black max-w-md w-full overflow-hidden shadow-[10px_10px_0px_#000] animate-fade-in">
                <div className="bg-legoblue text-white px-5 py-4 border-b-4 border-black flex items-center justify-between">
                  <h4 className="font-bangers text-xl tracking-widest uppercase">ADD STAFF MEMBER</h4>
                  <button onClick={() => setShowAddStaffModal(false)} className="text-white hover:text-red-300">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <form onSubmit={handleAddStaffSubmit} className="p-5 space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-750 block mb-1">INSTRUCTOR FULL NAME</label>
                    <input
                      type="text"
                      placeholder="e.g., Coach Brandon"
                      required
                      value={newStaffFields.name}
                      onChange={(e) => setNewStaffFields(prev => ({ ...prev, name: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-750 block mb-1">CENTER ROLE</label>
                    <input
                      type="text"
                      placeholder="e.g., Lead Robotics Instructor"
                      required
                      value={newStaffFields.role}
                      onChange={(e) => setNewStaffFields(prev => ({ ...prev, role: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-750 block mb-1">INDIVIDUAL PORTAL PASSWORD</label>
                    <input
                      type="password"
                      placeholder="e.g., brandon123 (defaults to 'staff')"
                      value={newStaffFields.password}
                      onChange={(e) => setNewStaffFields(prev => ({ ...prev, password: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50 focus:outline-none font-mono"
                    />
                  </div>
                  <div className="flex gap-2 justify-end pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setShowAddStaffModal(false)}
                      className="px-4 py-2 border-2 border-black rounded-lg text-xs font-bangers uppercase hover:bg-gray-100 cursor-pointer"
                    >
                      CANCEL
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-legogreen text-white rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase shadow-[4px_4px_0px_#000] active:translate-y-0.5 cursor-pointer"
                    >
                      REGISTER STAFF
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* STAFF GRID */}
          {filteredStaff.length === 0 ? (
            <div className="text-center py-10 bg-white border-2 border-dashed border-neutral-300 rounded-xl font-mono text-xs font-bold text-neutral-400">
              No staff members match your criteria.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStaff.map((member) => (
                <div
                  key={member.id}
                  className={`bg-white rounded-2xl border-4 border-black p-5 relative overflow-hidden flex flex-col justify-between transition-all hover:translate-y-[-2px] ${
                    member.clockedIn
                      ? 'ring-4 ring-green-400 shadow-[8px_8px_0px_rgba(34,197,94,1)]'
                      : 'shadow-[6px_6px_0px_#000]'
                  }`}
                >
                  <div className="flex gap-4 items-start mb-3">
                    <div className="w-16 h-16 rounded-xl border-2 border-black flex items-center justify-center shrink-0 bg-slate-50 relative overflow-hidden">
                      <MinifigAvatar style={member.avatar} size={56} />
                    </div>

                    <div className="min-w-0">
                      <h5 className="font-bangers text-lg text-black leading-none truncate">{member.name}</h5>
                      <span className="text-[9px] uppercase font-bold text-gray-400 block tracking-wider mt-1 truncate">
                        {member.role}
                      </span>
                      
                      <div className="flex flex-wrap items-center gap-1.5 mt-2">
                        {member.clockedIn ? (
                          <span className="bg-green-100 text-green-700 font-mono text-[8px] font-black uppercase px-2 py-0.5 rounded border border-green-500 animate-pulse">
                            SHIFTS ACTIVE
                          </span>
                        ) : (
                          <span className="bg-neutral-100 text-neutral-400 font-mono text-[8px] font-black uppercase px-2 py-0.5 rounded border border-neutral-200">
                            CLOCKED OUT
                          </span>
                        )}
                        <span className="text-[10px] font-mono font-bold text-slate-700 bg-neutral-100 border rounded px-1.5">
                          {member.hoursWorked || 0} hrs
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <span className="text-[10px] font-mono text-gray-500 uppercase font-black shrink-0">Login Password:</span>
                    <input
                      type="text"
                      value={member.password || 'staff'}
                      onChange={(e) => {
                        const updatedVal = e.target.value;
                        setStaff(prev => prev.map(s => s.id === member.id ? { ...s, password: updatedVal } : s));
                      }}
                      className="border-2 border-black rounded px-1.5 py-0.5 text-[10px] font-mono w-32 bg-slate-50 font-bold focus:bg-white text-right"
                    />
                  </div>

                  <div className="border-t-2 border-dashed border-slate-100 pt-3 flex items-center justify-between mt-4">
                    <button
                      onClick={() => onCustomizeStaffAvatar(member.id)}
                      className="bg-white hover:bg-slate-50 text-black font-bangers text-[10px] tracking-wide px-2.5 py-1.5 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] flex items-center gap-1 active:translate-y-0.5"
                    >
                      <Sparkles className="w-3 h-3 text-legoyellow fill-yellow-400" />
                      AVATAR
                    </button>

                    <div className="flex gap-1">
                      {member.checkedInToday ? (
                        <button
                          onClick={() => onStaffCheckIn(member.id, false)}
                          className="bg-red-500 hover:bg-red-650 text-white font-bangers text-[10px] px-2.5 py-1.5 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000]"
                        >
                          SHIFT OUT
                        </button>
                      ) : (
                        <button
                          onClick={() => onStaffCheckIn(member.id, true)}
                          className="bg-green-500 hover:bg-green-650 text-white font-bangers text-[10px] px-2.5 py-1.5 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000]"
                        >
                          SHIFT IN
                        </button>
                      )}

                      <button
                        onClick={() => handleRemoveStaff(member.id, member.name)}
                        className="bg-slate-100 hover:bg-red-100 text-slate-500 hover:text-legored rounded-lg p-2 border border-slate-300 transition-colors cursor-pointer"
                        title="Remove instructor"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* STAFF TIMESHEET SPREADSHEET */}
          <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[6px_6px_0px_#000] mt-8" id="hours-spreadsheet-container">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-dashed border-neutral-200 pb-3 mb-4">
              <div>
                <h4 className="font-bangers text-xl text-black uppercase tracking-wide flex items-center gap-2">
                  <span className="bg-green-600 text-white rounded p-1"><FileSpreadsheet className="w-4 h-4" /></span>
                  COACHES CLOCKED TIMESHEET SPREADSHEET
                </h4>
                <p className="text-[10px] font-mono font-bold text-gray-500 uppercase">
                  Excel-style live shift tracking • Review cumulative hours prior to confirming bookings
                </p>
              </div>
              <div className="flex items-center gap-2 text-[10px] font-mono text-neutral-500 font-bold">
                <span className="w-2.5 h-2.5 bg-green-550 rounded-full animate-pulse inline-block" />
                LIVE SHEET FEED
              </div>
            </div>

            <div className="overflow-x-auto border-2 border-black rounded-lg shadow-[2px_2px_0px_rgba(0,0,0,1)]">
              <table className="w-full text-left border-collapse font-mono text-xs">
                <thead>
                  <tr className="bg-neutral-100 border-b-2 border-black">
                    <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">REF ID</th>
                    <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">COACH NAME</th>
                    <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">SPECIALTY ROLE</th>
                    <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-center">SHIFT STATE</th>
                    <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-right">LAST SHIFT STAMP</th>
                    <th className="px-3 py-2 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-right bg-yellow-50/70">CUMULATIVE HOURS</th>
                  </tr>
                </thead>
                <tbody>
                  {staff.map((member, i) => (
                    <tr key={member.id} className="border-b border-neutral-200 hover:bg-slate-50 transition-colors">
                      <td className="px-3 py-2 border-r border-neutral-200 text-[10px] font-bold text-neutral-500 font-mono">STF-{100 + i}</td>
                      <td className="px-3 py-2 border-r border-neutral-200 font-bold text-black">{member.name}</td>
                      <td className="px-3 py-2 border-r border-neutral-200 font-bold uppercase text-neutral-600 text-[10px]">{member.role}</td>
                      <td className="px-3 py-2 border-r border-neutral-200 text-center">
                        {member.clockedIn ? (
                          <span className="inline-block bg-green-100 text-green-700 border border-green-400 font-black text-[9px] uppercase px-1.5 py-0.5 rounded animate-pulse">
                            ON-DUTY
                          </span>
                        ) : (
                          <span className="inline-block bg-neutral-100 text-neutral-400 border border-neutral-300 font-bold text-[9px] uppercase px-1.5 py-0.5 rounded">
                            INACTIVE
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-2 border-r border-neutral-200 text-right text-[10px] text-neutral-500">
                        {member.shiftStartTimestamp ? new Date(member.shiftStartTimestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : 'N/A'}
                      </td>
                      <td className="px-3 py-2 text-right bg-yellow-50/50 font-black text-black">
                        {member.hoursWorked || 0} hrs
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* PARENT BOOKED SESSIONS SPREADSHEET */}
          <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[6px_6px_0px_#000] mt-6" id="bookings-spreadsheet-container">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-dashed border-neutral-200 pb-3 mb-4">
              <div>
                <h4 className="font-bangers text-xl text-black uppercase tracking-wide flex items-center gap-2">
                  <span className="bg-indigo-600 text-white rounded p-1"><FileSpreadsheet className="w-4 h-4" /></span>
                  PARENT RESERVED BOOKINGS SPREADSHEET
                </h4>
                <p className="text-[10px] font-mono font-bold text-gray-500 uppercase">
                  Excel-style parent booking sheet • Lists scheduled builders, timeslots, and parent profiles
                </p>
              </div>
              <div className="bg-indigo-100 border border-indigo-300 text-indigo-700 font-mono text-[9px] font-black px-2 py-0.5 rounded">
                {bookings.length} RESERVED
              </div>
            </div>

            {bookings.length === 0 ? (
              <div className="bg-slate-50 rounded-xl border-2 border-dashed border-slate-300 py-10 px-4 text-center font-mono text-xs font-bold text-slate-400">
                NO BOOKED TICKETS STORED CURRENTLY. PARENTS CONFIGURE RESERVATIONS VIA SECURED GOOGLE STATION HUB.
              </div>
            ) : (
              <div className="overflow-x-auto border-2 border-black rounded-lg shadow-[2px_2px_0px_rgba(0,0,0,1)]">
                <table className="w-full text-left border-collapse font-mono text-xs">
                  <thead>
                    <tr className="bg-neutral-100 border-b-2 border-black">
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">TICKET REF</th>
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">BUILDER (CHILD)</th>
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-center">SESSION DAY</th>
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-center">HOUR SLOT</th>
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">PARENT EMAIL</th>
                      <th className="px-3 py-2 border-r border-neutral-300 text-[10px] font-bold text-neutral-600 uppercase tracking-wider">SPECIAL INSTRUCTIONS</th>
                      <th className="px-3 py-2 text-[10px] font-bold text-neutral-600 uppercase tracking-wider text-center">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bookings.map((b, i) => (
                      <tr key={b.id} className="border-b border-neutral-200 hover:bg-slate-50 transition-colors">
                        <td className="px-3 py-2 border-r border-neutral-200 text-[10px] font-bold text-neutral-500 font-mono">BKG-{1000 + i}</td>
                        <td className="px-3 py-2 border-r border-neutral-200 font-bold text-black">{b.studentName}</td>
                        <td className="px-3 py-2 border-r border-neutral-200 text-center font-bold text-emerald-600">{b.day}</td>
                        <td className="px-3 py-2 border-r border-neutral-200 text-center font-bold text-neutral-700">{b.hour}</td>
                        <td className="px-3 py-2 border-r border-neutral-200 text-neutral-600 select-all">{b.parentEmail}</td>
                        <td className="px-3 py-2 border-r border-neutral-200 text-[11px] text-neutral-500 italic max-w-xs truncate" title={b.notes}>{b.notes || 'None'}</td>
                        <td className="px-3 py-2 text-center">
                          <button
                            onClick={() => setBookings(prev => prev.filter(ob => ob.id !== b.id))}
                            className="bg-red-50 hover:bg-red-100 text-red-600 text-[10px] font-bold font-mono border border-red-300 px-2 py-0.5 rounded cursor-pointer transition-colors"
                          >
                            REVOKE
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-PANEL 2: STUDENTS DIRECTORY (REMOVE & MANAGE MEMBERS) */}
      {panelTab === 'students' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b pb-3 border-dashed border-neutral-200">
            <div>
              <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
                STUDENTS & SCHOOLS ROSTER CONTROLLER
              </h4>
              <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
                View student membership profiles, emergency contacts, or perform final administrative deletions.
              </p>
            </div>

            <div className="flex flex-wrap gap-2 w-full sm:w-auto">
              <select
                value={studentFilter}
                onChange={(e: any) => setStudentFilter(e.target.value)}
                className="bg-white border-2 border-black rounded-lg px-3 py-1.5 text-xs font-bold font-mono uppercase text-gray-650"
              >
                <option value="All">All Memberships</option>
                <option value="Master Builder">Master Builders Only</option>
                <option value="Adventurer">Adventurers Only</option>
                <option value="Not a Member">Not a Member Only</option>
              </select>

              <div className="relative">
                <input
                  type="text"
                  placeholder="Search students/parents..."
                  value={studentSearchQuery}
                  onChange={(e) => setStudentSearchQuery(e.target.value)}
                  className="bg-white border-2 border-black rounded-lg px-3 py-1.5 pl-8 text-xs font-bold outline-none w-full sm:w-48"
                />
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-gray-400" />
              </div>
            </div>
          </div>

          {filteredStudents.length === 0 ? (
            <div className="text-center py-16 bg-white border-2 border-dashed border-neutral-300 rounded-xl font-mono text-xs font-bold text-neutral-450">
              No students or members matches the search parameters.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredStudents.map((child) => (
                <div
                  key={child.id}
                  className="bg-white border-4 border-black rounded-2xl p-4 shadow-[4px_4px_0px_#000] flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2">
                      <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded border border-black ${
                        child.membershipType === 'Master Builder' ? 'bg-amber-100 text-amber-700' :
                        child.membershipType === 'Adventurer' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {child.membershipType}
                      </span>
                      
                      <button
                        onClick={() => handleRemoveStudent(child.id, child.name)}
                        className="bg-red-50 hover:bg-red-150 text-legored border border-red-300 p-1 rounded transition-colors cursor-pointer"
                        title="Delete student member"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="flex gap-3">
                      <div className="w-12 h-12 border border-black rounded-lg overflow-hidden bg-slate-50 shrink-0 flex items-center justify-center">
                        <MinifigAvatar style={child.avatar} size={44} />
                      </div>
                      <div className="min-w-0">
                        <h5 className="font-bangers text-lg text-black leading-none truncate">{child.name}</h5>
                        <p className="text-[10px] font-mono font-bold text-neutral-500 mt-1">School: {child.school || 'Unlisted'}</p>
                      </div>
                    </div>

                    <div className="bg-neutral-50 p-2.5 rounded-lg border border-neutral-250 font-mono text-[10px] leading-relaxed space-y-1 text-neutral-700">
                      <div>
                        <strong>Parent:</strong> {child.parentName}
                      </div>
                      <div className="truncate">
                        <strong>Email:</strong> {child.parentEmail}
                      </div>
                      <div>
                        <strong>Phone:</strong> {child.parentPhone}
                      </div>
                      {child.dietaryRestrictions && (
                        <div className="text-red-700 bg-red-50 font-bold px-2 py-0.5 rounded border border-red-200 mt-1 inline-block">
                          Allergy: {child.dietaryRestrictions}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 mt-3 text-right text-[9px] font-mono font-bold text-gray-400">
                    ID: {child.id}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-PANEL 3: WORKSHOPS CURRICULUM */}
      {panelTab === 'workshops' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
                LEGO COURSETRACKS & WORKSHOPS
              </h4>
              <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
                Publish course tracks, edit schedules, pricing slots, or remove expired workshops.
              </p>
            </div>
            <button
              onClick={() => {
                resetWorkshopForm();
                setShowAddWorkshopModal(true);
              }}
              className="bg-legogreen hover:bg-green-600 text-white font-bangers text-xs tracking-widest uppercase px-4 py-2.5 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              CREATE WORKSHOP
            </button>
          </div>

          {/* ADD / EDIT WORKSHOP MODAL */}
          {(showAddWorkshopModal || editingWorkshopId !== null) && (
            <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl border-4 border-black max-w-lg w-full overflow-hidden shadow-[10px_10px_0px_#000] animate-fade-in">
                <div className="bg-legored text-white px-5 py-4 border-b-4 border-black flex items-center justify-between">
                  <h4 className="font-bangers text-xl tracking-widest uppercase flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    {editingWorkshopId ? 'SAVE CHANGES' : 'CREATE WORKSHOP'}
                  </h4>
                  <button
                    onClick={() => {
                      setShowAddWorkshopModal(false);
                      setEditingWorkshopId(null);
                    }}
                    className="text-white hover:text-yellow-300"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <form
                  onSubmit={editingWorkshopId ? handleSaveWorkshopEdit : handleCreateWorkshop}
                  className="p-5 space-y-4 max-h-[85vh] overflow-y-auto"
                >
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">COURSE TITLE</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Robot Sumo Wrestling Track"
                      value={workshopForm.title}
                      onChange={(e) => setWorkshopForm(prev => ({ ...prev, title: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50 outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">TAG / TAG CATEGORY</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Robotics"
                      value={workshopForm.tag}
                      onChange={(e) => setWorkshopForm(prev => ({ ...prev, tag: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">DESCRIPTION</label>
                    <textarea
                      required
                      placeholder="Explain to players what Technic bricks we are going to use..."
                      rows={3}
                      value={workshopForm.description}
                      onChange={(e) => setWorkshopForm(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">DATE STRING</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g., Saturday, July 12th"
                        value={workshopForm.date}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, date: e.target.value }))}
                        className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black font-semibold bg-slate-50"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 block mb-1">TIME RANGE</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g., 2:00 PM - 4:00 PM"
                        value={workshopForm.time}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, time: e.target.value }))}
                        className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm text-black"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 font-mono">
                    <div>
                      <label className="text-xs font-bold text-gray-750 block mb-1">MIN AGE</label>
                      <input
                        type="number"
                        min={3}
                        value={workshopForm.minAge}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, minAge: parseInt(e.target.value) || 6 }))}
                        className="w-full border shadow-inner px-2 py-1.5"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-750 block mb-1">SPOTS TOTAL</label>
                      <input
                        type="number"
                        min={1}
                        value={workshopForm.spotsLeft}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, spotsLeft: parseInt(e.target.value) || 10 }))}
                        className="w-full border shadow-inner px-2 py-1.5"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-755 block mb-1">PRICE</label>
                      <input
                        type="text"
                        value={workshopForm.price}
                        onChange={(e) => setWorkshopForm(prev => ({ ...prev, price: e.target.value }))}
                        className="w-full border shadow-inner px-2 py-1.5"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 justify-end pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => {
                        setShowAddWorkshopModal(false);
                        setEditingWorkshopId(null);
                      }}
                      className="px-4 py-2 border-2 border-black rounded-lg text-xs font-bangers uppercase hover:bg-gray-100 cursor-pointer"
                    >
                      CLOSE
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 bg-legored text-white rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase shadow-[4px_4px_0px_#000] active:translate-y-0.5 cursor-pointer"
                    >
                      {editingWorkshopId ? 'SAVE CHANGES' : 'PUBLISH'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* ACTIVE WORKSHOPS SPREAD */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {workshops.map((wk) => {
              const registered = registeredWorkshops[wk.id] || [];
              const spotsRem = Math.max(0, wk.spotsLeft - registered.length);
              
              return (
                <div
                  key={wk.id}
                  className="bg-white border-4 border-black rounded-xl p-5 shadow-[5px_5px_0px_#000] flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2 border-b-2 border-dashed border-slate-100 pb-2">
                      <span className="bg-legoyellow text-black border border-black font-bangers text-[10px] tracking-wider px-2 py-0.5 rounded leading-none uppercase">
                        {wk.tag}
                      </span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => triggerEditWorkshop(wk)}
                          className="bg-white hover:bg-slate-50 border p-1 rounded cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-legoblue" />
                        </button>
                        <button
                          onClick={() => handleDeleteWorkshop(wk.id, wk.title)}
                          className="bg-white hover:bg-red-50 border p-1 rounded cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-legored" />
                        </button>
                      </div>
                    </div>

                    <h5 className="font-bangers text-xl text-black leading-tight uppercase">{wk.title}</h5>
                    <p className="text-xs text-gray-500 font-medium leading-relaxed leading-snug">{wk.description}</p>

                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono font-bold text-gray-600 bg-slate-50 rounded-lg p-2.5">
                      <div className="flex items-center gap-2">
                        <CalendarDays className="w-3.5 h-3.5 text-legoblue" />
                        <span>{wk.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-legoblue" />
                        <span>{wk.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="w-3.5 h-3.5 text-legogreen" />
                        <span>Min Age: {wk.minAge}+</span>
                      </div>
                      <div className="flex items-center gap-2 text-black">
                        <Award className="w-3.5 h-3.5 text-legoyellow fill-yellow-400 font-bold" />
                        <span>{wk.price}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3.5 mt-4 border-t border-slate-105 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-gray-450 block font-mono font-bold uppercase">RESERVATIONS:</span>
                      <span className="font-bangers text-lg text-emerald-600">
                        {registered.length} REGISTERED ({spotsRem} left)
                      </span>
                    </div>
                    {registered.length > 0 && (
                      <span className="text-[10px] text-gray-500 font-mono font-bold max-w-[50%] truncate">
                        [{registered.join(', ')}]
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-PANEL 4: TASK MANAGER */}
      {panelTab === 'tasks' && (
        <div className="space-y-6 animate-fade-in">
          <div>
            <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
              PLAY CENTER PROTOCOL TASK WRITER
            </h4>
            <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
              Schedule chore protocols, sanitizations, count lists, and assign days for staff members to execute.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left Column Controls */}
            <div className="space-y-4 lg:col-span-1">
              <div className="bg-white border-4 border-black p-4 rounded-xl shadow-[4px_4px_0px_#000] space-y-2">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest block border-b pb-1.5 mb-2 font-mono">
                  CHOOSE COMPLIANCE DAY
                </span>
                <div className="flex flex-wrap gap-1">
                  {DAYS_OF_WEEK.map(day => (
                    <button
                      key={day}
                      onClick={() => setActiveTaskDay(day)}
                      className={`text-xs font-bold px-3 py-1.5 rounded-md border transition-all cursor-pointer ${
                        activeTaskDay === day
                          ? 'bg-legoyellow border-black text-black font-bangers shadow-[2px_2px_0px_#000]'
                          : 'bg-slate-100 border-slate-200 hover:border-black text-gray-650'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Task creation engine card */}
              <div className="bg-white border-4 border-black p-4 rounded-xl shadow-[4px_4px_0px_#000] text-left">
                <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest block border-b pb-1.5 mb-3 font-mono">
                  REGISTER NEW PLAY TASK
                </span>
                <form onSubmit={handleAddTaskSubmit} className="space-y-3 font-mono text-xs">
                  <div>
                    <label className="text-[9px] font-bold text-gray-400 block mb-1">ASSIGN DAY</label>
                    <select
                      value={newTaskDay}
                      onChange={(e) => setNewTaskDay(e.target.value as any)}
                      className="w-full bg-slate-50 border-2 border-black rounded-lg px-2 py-1.5 font-bold uppercase transition-all"
                    >
                      {DAYS_OF_WEEK.map(d => (
                        <option key={d} value={d}>{d}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-gray-400 block mb-1">TASK DESCRIPTION</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Clean battle ground track..."
                      value={newTaskText}
                      onChange={(e) => setNewTaskText(e.target.value)}
                      className="w-full border-2 border-black rounded-lg px-3 py-1.5 text-xs text-black font-bold outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold text-gray-400 block mb-1">ASSIGN TO SPECIFIC COACH</label>
                    <select
                      value={newTaskAssignedTo}
                      onChange={(e) => setNewTaskAssignedTo(e.target.value)}
                      className="w-full bg-slate-50 border-2 border-black rounded-lg px-2 py-1.5 font-bold uppercase transition-all text-xs"
                    >
                      <option value="">General Task (Any Staff)</option>
                      {staff.map(s => (
                        <option key={s.id} value={s.id}>{s.name} ({s.role})</option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-legoblue hover:bg-blue-600 text-white font-bangers uppercase tracking-widest py-2 px-4 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 cursor-pointer"
                  >
                    DEPLOY PROTOCOL
                  </button>
                </form>
              </div>
            </div>

            {/* Right Column Tasks Active */}
            <div className="lg:col-span-2 space-y-3">
              <div className="bg-white border-4 border-black p-4 rounded-xl shadow-[6px_6px_0px_#000] min-h-[350px]">
                <div className="flex items-center justify-between border-b pb-2 mb-4">
                  <span className="font-bangers text-xl text-black uppercase tracking-wide">
                    {activeTaskDay} Protocol Tasks
                  </span>
                  <span className="bg-slate-100 text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded border border-slate-300 font-mono">
                    {filteredTasks.length} LOADED
                  </span>
                </div>

                {filteredTasks.length === 0 ? (
                  <div className="text-center py-20 text-gray-400 text-xs font-bold font-mono uppercase tracking-wider">
                    No tasks registered for {activeTaskDay}.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredTasks.map((t) => (
                      <div
                        key={t.id}
                        className={`border-2 border-black rounded-xl p-3 flex items-center justify-between gap-4 transition-colors ${
                          t.completed ? 'bg-slate-105/50 opacity-60' : 'bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => handleToggleTaskAdmin(t.id)}
                            className="text-gray-700 hover:text-black cursor-pointer active:scale-95"
                          >
                            {t.completed ? (
                              <CheckSquare className="w-5 h-5 text-legogreen" />
                            ) : (
                              <Square className="w-5 h-5" />
                            )}
                          </button>
                          <div>
                            <span className={`text-xs md:text-sm font-semibold text-black leading-snug ${
                              t.completed ? 'line-through text-gray-400' : ''
                            }`}>
                              {t.text}
                            </span>
                            {t.assignedTo && (
                              <span className="block text-[10px] font-mono font-bold text-indigo-600 mt-0.5">
                                Assigned to: {staff.find(sf => sf.id === t.assignedTo)?.name || t.assignedTo}
                              </span>
                            )}
                            {t.completed && t.completedBy && (
                              <span className="inline-block bg-green-50 text-green-700 text-[9px] font-mono font-black mt-1 px-1.5 py-0.5 rounded border border-green-200">
                                Completed by {t.completedBy} at {t.completedAt || 'today'}
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="bg-yellow-100 text-[8px] font-mono font-black border border-black px-1.5 py-0.5 rounded leading-none">
                            {t.day}
                          </span>
                          <button
                            onClick={() => handleDeleteTask(t.id)}
                            className="text-gray-400 hover:text-legored p-1 cursor-pointer"
                            title="Delete task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* SUB-PANEL 5: GOOGLE SHEET INTEGRATION */}
      {panelTab === 'sheets' && (
        <div className="space-y-4 animate-fade-in text-left">
          <div className="border-b-2 border-dashed border-neutral-200 pb-2 mb-2">
            <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
              GOOGLE INTEGRATION SYSTEM BACKUP
            </h4>
            <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
              Link live student logs with your custom office Google spreadsheet for backups.
            </p>
          </div>

          <GoogleSheetsConfig
            logs={logs}
            googleClientId={googleClientId}
            setGoogleClientId={setGoogleClientId}
            spreadsheetId={spreadsheetId}
            setSpreadsheetId={setSpreadsheetId}
            accessToken={accessToken}
            onGoogleLogin={onGoogleLogin}
            onSyncLogs={onSyncLogs}
            isSyncing={isSyncing}
          />
        </div>
      )}

      {/* SUB-PANEL 6: ALERTS FEEDS (NOTIFICATIONS CENTER) */}
      {panelTab === 'notifications' && (
        <div className="space-y-6 animate-fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dashed border-neutral-250 pb-3">
            <div>
              <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
                ADMIN REALTIME NOTIFICATION SYSTEM
              </h4>
              <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
                Observe live tasks completed by tutors, checklists ticked, and timesheet updates.
              </p>
            </div>
            
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleMarkNotificationsRead}
                disabled={notifications.length === 0}
                className="bg-white hover:bg-neutral-100 text-black font-bangers text-xs px-3 py-1.5 border-2 border-black rounded-lg shadow-[2px_2px_0px_#000] active:translate-y-0.5 disabled:opacity-50"
              >
                MARK READ
              </button>
              <button
                type="button"
                onClick={handleClearAllNotifications}
                disabled={notifications.length === 0}
                className="bg-legored hover:bg-red-600 text-white font-bangers text-xs px-3 py-1.5 border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 disabled:opacity-50"
              >
                CLEAR LIST
              </button>
            </div>
          </div>

          {notifications.length === 0 ? (
            <div className="bg-white border-4 border-dashed border-neutral-300 p-12 text-center rounded-2xl">
              <Bell className="w-10 h-10 text-neutral-300 mx-auto mb-2.5" />
              <p className="font-mono text-xs font-bold text-neutral-400 uppercase tracking-widest">
                No active notifications recorded in this session yet.
              </p>
              <p className="font-mono text-[11px] text-gray-500 mt-1 max-w-sm mx-auto leading-relaxed">
                As staff login, clock in/out, or mark tasks complete in the Staff Space, status flashes will record here in real-time.
              </p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[450px] overflow-y-auto pr-2">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  className={`border-2 border-black rounded-xl p-3.5 flex items-start gap-3 transition-colors ${
                    n.read ? 'bg-slate-50 opacity-60' : 'bg-yellow-50 border-yellow-400'
                  }`}
                >
                  <div className={`p-1.5 rounded-full border border-black shrink-0 ${n.read ? 'bg-slate-200' : 'bg-yellow-300'}`}>
                    <Bell className="w-3.5 h-3.5 text-black" />
                  </div>
                  
                  <div className="min-w-0 flex-grow text-left">
                    <p className={`text-xs font-bold text-black ${n.read ? 'font-medium' : 'font-extrabold'}`}>
                      {n.text}
                    </p>
                    <span className="text-[10px] font-mono text-neutral-400 block mt-1">
                      Triggered: {n.timestamp}
                    </span>
                  </div>

                  {!n.read && (
                    <span className="bg-yellow-400 text-black border border-black font-mono text-[8px] font-black px-1.5 py-0.5 rounded shrink-0">
                      NEW
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-PANEL 7: SECURITY SETTINGS */}
      {panelTab === 'security' && (
        <div className="space-y-6 animate-fade-in p-1">
          <div>
            <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
              SECURITY & PASSWORD ACCESS PANEL
            </h4>
            <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
              Configure or update the password required to view the secure panel tabs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
            <div className="bg-white border-4 border-black rounded-2xl p-6 shadow-[5px_5px_0px_#000]">
              <h5 className="font-bangers text-lg text-black mb-4 border-b border-dashed pb-2">
                CHANGE ADMINISTRATIVE PASSCODE
              </h5>

              <form onSubmit={handleUpdatePassword} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">CURRENT AUTH PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Enter current password..."
                    value={currentPasswordConfirm}
                    onChange={(e) => setCurrentPasswordConfirm(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">NEW PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Choose new secure password..."
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">CONFIRM NEW PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Repeat new password..."
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                {securityError && (
                  <div className="bg-red-50 border border-red-300 text-red-600 rounded-lg p-2.5 font-mono text-xs font-bold">
                    {securityError}
                  </div>
                )}

                {securitySuccess && (
                  <div className="bg-green-50 border border-green-300 text-green-700 rounded-lg p-2.5 font-mono text-xs font-bold leading-relaxed">
                    {securitySuccess}
                  </div>
                )}

                <button
                  type="submit"
                  className="bg-legoblue hover:bg-blue-600 text-white font-bangers text-xs uppercase tracking-widest px-5 py-2.5 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 cursor-pointer"
                >
                  APPLY PASSWORD REVISION
                </button>
              </form>
            </div>

            <div className="bg-white border-4 border-black rounded-2xl p-6 shadow-[5px_5px_0px_#000]">
              <h5 className="font-bangers text-lg text-black mb-4 border-b border-dashed pb-2">
                CHANGE STAFF PORTAL PASSCODE
              </h5>

              <form onSubmit={handleUpdateStaffPassword} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">CURRENT STAFF PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Enter current staff password..."
                    value={currentStaffPasswordConfirm}
                    onChange={(e) => setCurrentStaffPasswordConfirm(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">NEW STAFF PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Choose new staff password..."
                    value={newStaffPassword}
                    onChange={(e) => setNewStaffPassword(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-bold text-neutral-500 uppercase">CONFIRM NEW STAFF PASSWORD</label>
                  <input
                    type="password"
                    required
                    placeholder="Repeat new staff password..."
                    value={confirmNewStaffPassword}
                    onChange={(e) => setConfirmNewStaffPassword(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                {staffSecurityError && (
                  <div className="bg-red-50 border border-red-300 text-red-600 rounded-lg p-2.5 font-mono text-xs font-bold">
                    {staffSecurityError}
                  </div>
                )}

                {staffSecuritySuccess && (
                  <div className="bg-green-50 border border-green-300 text-green-700 rounded-lg p-2.5 font-mono text-xs font-bold leading-relaxed">
                    {staffSecuritySuccess}
                  </div>
                )}

                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bangers text-xs uppercase tracking-widest px-5 py-2.5 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] active:translate-y-0.5 cursor-pointer"
                >
                  APPLY STAFF PASSWORD REVISION
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* SUB-PANEL 8: BOOKINGS SHEET */}
      {panelTab === 'bookings' && (
        <div className="space-y-6 animate-fade-in" id="admin-bookings-subpanel">
          <div>
            <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
              REGISTERED BOOKINGS SPREADSHEET
            </h4>
            <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
              Live records of all registered power hour time slots and camp/workshop student seats.
            </p>
          </div>

          {/* Filters controls */}
          <div className="bg-slate-50 border-2 border-black rounded-xl p-4 flex flex-col md:flex-row gap-4 justify-between items-center">
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search bookings (Student Name, Email, Class)..."
                value={bookingSearchQuery}
                onChange={(e) => setBookingSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 border-2 border-black rounded-lg text-xs font-semibold bg-white font-mono"
              />
            </div>

            <div className="flex gap-2 items-center">
              <span className="text-[10px] font-mono font-black text-gray-500 uppercase">Filter Type:</span>
              <select
                value={bookingTypeFilter}
                onChange={(e) => setBookingTypeFilter(e.target.value as any)}
                className="bg-white border-2 border-black rounded-lg px-2.5 py-1 text-xs font-mono font-bold"
              >
                <option value="All">All Bookings</option>
                <option value="Power Hour">Power Hour Only</option>
                <option value="Workshop/Camp">Workshops &amp; Camps</option>
              </select>
            </div>
          </div>

          {/* Bookings Spreadsheet table list */}
          <div className="bg-white border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_#000]">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 border-b-2 border-black text-slate-800 uppercase font-mono font-black tracking-wider text-[10px]">
                  <th className="p-3 border-r border-neutral-300">Category</th>
                  <th className="p-3 border-r border-neutral-300">Student Name</th>
                  <th className="p-3 border-r border-neutral-300">Activity Class</th>
                  <th className="p-3 border-r border-neutral-300">Schedule / Price</th>
                  <th className="p-3 border-r border-neutral-300">Parent Contact Info</th>
                  <th className="p-3 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200 font-mono text-[11px] font-semibold">
                {(() => {
                  const list: any[] = [];
                  // Gather Power Hour bookings
                  bookings.forEach(b => {
                    list.push({
                      id: b.id,
                      type: 'Power Hour',
                      studentName: b.studentName,
                      activity: `Power Hour Free Assembly (${b.day})`,
                      date: `${b.day} @ ${b.hour}`,
                      contact: b.parentEmail,
                      notes: b.notes || 'None'
                    });
                  });

                  // Gather Workshop/Camp bookings
                  Object.keys(registeredWorkshops).forEach(workshopId => {
                    const w = workshops.find(item => item.id === workshopId);
                    if (w) {
                      const studentNames = registeredWorkshops[workshopId] || [];
                      studentNames.forEach((name, idx) => {
                        const std = students.find(s => s.name === name || s.id === name);
                        list.push({
                          id: `ws_reg_${workshopId}_${idx}`,
                          type: 'Workshop/Camp',
                          studentName: std?.name || name,
                          activity: w.title,
                          date: `${w.date} (${w.time})`,
                          contact: std?.parentEmail || 'On File',
                          notes: `Spot Cost: ${w.price}`
                        });
                      });
                    }
                  });

                  // Filter list
                  const filtered = list.filter(item => {
                    const matchesSearch = item.studentName.toLowerCase().includes(bookingSearchQuery.toLowerCase()) ||
                                          item.activity.toLowerCase().includes(bookingSearchQuery.toLowerCase()) ||
                                          item.contact.toLowerCase().includes(bookingSearchQuery.toLowerCase());
                    const matchesType = bookingTypeFilter === 'All' || item.type === bookingTypeFilter;
                    return matchesSearch && matchesType;
                  });

                  if (filtered.length === 0) {
                    return (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-neutral-400 font-bold uppercase">
                          No bookings matches the active filter rules.
                        </td>
                      </tr>
                    );
                  }

                  return filtered.map(item => (
                    <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 border-r border-neutral-200">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase border ${
                          item.type === 'Power Hour' 
                            ? 'bg-amber-100 text-amber-800 border-amber-300' 
                            : 'bg-indigo-100 text-indigo-800 border-indigo-300'
                        }`}>
                          {item.type}
                        </span>
                      </td>
                      <td className="p-3 border-r border-neutral-200 uppercase font-bold text-gray-800">{item.studentName}</td>
                      <td className="p-3 border-r border-neutral-200 text-gray-700 uppercase">{item.activity}</td>
                      <td className="p-3 border-r border-neutral-200 font-semibold">{item.date}</td>
                      <td className="p-3 border-r border-neutral-200 text-slate-500">{item.contact}</td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => {
                            if (window.confirm(`Are you sure you want to cancel booking for "${item.studentName}"?`)) {
                              if (item.type === 'Power Hour') {
                                setBookings(prev => prev.filter(b => b.id !== item.id));
                              } else {
                                const parts = item.id.split('_');
                                const wId = parts[2];
                                setRegisteredWorkshops(prev => {
                                  const cur = prev[wId] || [];
                                  return {
                                    ...prev,
                                    [wId]: cur.filter(n => n !== item.studentName)
                                  };
                                });
                              }
                            }
                          }}
                          className="text-red-500 hover:text-red-700 p-1 border border-transparent hover:border-red-300 rounded hover:bg-red-50"
                          title="Cancel Booking"
                        >
                          <Trash2 className="w-4 h-4 mx-auto" />
                        </button>
                      </td>
                    </tr>
                  ));
                })()}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-PANEL 9: RENTAL INVENTORY */}
      {panelTab === 'rentals' && (
        <div className="space-y-6 animate-fade-in" id="admin-rentals-subpanel">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
                LEGO SPECIALTY RENTALS CATALOG
              </h4>
              <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
                Manage Lego rental sets inventory, check live out-of-stock statuses, and register returns.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left form to add new lego set */}
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] text-left">
              <h5 className="font-bangers text-lg text-black mb-4 border-b border-dashed pb-2">
                REGISTER NEW RENTAL LEGO BOX
              </h5>
              
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newSetName) return;
                  const newSet: LegoSet = {
                    id: `set_${Date.now()}`,
                    name: newSetName,
                    theme: newSetTheme,
                    pieces: Number(newSetPieces),
                    difficulty: newSetDiff,
                    rented: false
                  };
                  setLegoSets(prev => [...prev, newSet]);
                  setNewSetName('');
                }} 
                className="space-y-3 text-xs"
              >
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">LEGO SET TITLE *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Star Wars Millennium Falcon..."
                    value={newSetName}
                    onChange={(e) => setNewSetName(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Theme Series</label>
                    <select
                      value={newSetTheme}
                      onChange={(e) => setNewSetTheme(e.target.value)}
                      className="w-full bg-slate-50 border-2 border-black rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold"
                    >
                      <option value="Technic">Technic</option>
                      <option value="Star Wars">Star Wars</option>
                      <option value="Harry Potter">Harry Potter</option>
                      <option value="Architecture">Architecture</option>
                      <option value="Creator Expert">Creator Expert</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Pieces Count</label>
                    <input
                      type="number"
                      required
                      value={newSetPieces}
                      onChange={(e) => setNewSetPieces(Number(e.target.value))}
                      className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-1.5 text-xs font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Difficulty Tier</label>
                  <select
                    value={newSetDiff}
                    onChange={(e) => setNewSetDiff(e.target.value as any)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Master">Master</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full bg-legoyellow hover:bg-yellow-400 text-black border-2 border-black font-bangers text-xs tracking-widest py-2.5 rounded-xl shadow-[3px_3px_0px_#000] active:translate-y-0.5 cursor-pointer uppercase"
                >
                  SAVE BOX TO DIRECTORY
                </button>
              </form>
            </div>

            {/* Right side live catalog overview */}
            <div className="lg:col-span-2 bg-white border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_#000]">
              <div className="bg-slate-50 p-3 border-b-2 border-black font-bangers text-sm text-black tracking-wider uppercase">
                LIVE ACTIVE CATALOGUE ({legoSets.length} TOTAL BRICKS SETS)
              </div>
              
              <div className="divide-y divide-neutral-200 max-h-[380px] overflow-y-auto scroller-thick">
                {legoSets.length === 0 ? (
                  <div className="p-8 text-center text-neutral-400 font-mono text-xs uppercase font-bold">
                    No Lego Sets registered in the system library directory yet.
                  </div>
                ) : (
                  legoSets.map(set => (
                    <div key={set.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bangers text-sm text-black uppercase tracking-wide">{set.name}</span>
                          <span className="bg-indigo-50 border border-indigo-200 text-indigo-700 font-mono text-[9px] px-1.5 py-0.2 rounded font-bold uppercase">
                            {set.theme}
                          </span>
                        </div>
                        <div className="text-[10px] font-mono text-neutral-500 font-bold uppercase mt-0.5">
                          {set.pieces} pieces | Difficulty: <strong className="text-gray-700">{set.difficulty}</strong>
                        </div>

                        {set.rented && (
                          <div className="mt-1.5 bg-red-50 border border-red-200 rounded p-1.5 text-[10px] font-mono text-red-950 font-semibold inline-block">
                            Rented by: <strong className="text-red-700 uppercase">{set.rentedByStudentName}</strong> (Date: {set.rentedDate}) | Email: {set.parentEmail}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {set.rented ? (
                          <button
                            onClick={() => {
                              if (window.confirm(`Mark "${set.name}" as returned?`)) {
                                setLegoSets(prev => prev.map(s => {
                                  if (s.id === set.id) {
                                    return {
                                      ...s,
                                      rented: false,
                                      rentedByStudentId: undefined,
                                      rentedByStudentName: undefined,
                                      rentedDate: undefined,
                                      parentEmail: undefined
                                    };
                                  }
                                  return s;
                                }));
                              }
                            }}
                            className="bg-legogreen hover:bg-green-600 text-white font-bangers text-[10px] tracking-wider px-3 py-1.5 rounded-lg border-2 border-black shadow-[2px_2px_0px_#000] active:translate-y-0.5 uppercase"
                          >
                            Mark Returned
                          </button>
                        ) : (
                          <span className="bg-emerald-50 text-emerald-700 font-mono text-[10px] font-black border border-emerald-300 rounded-md px-2 py-1 uppercase">
                            ✓ Available
                          </span>
                        )}

                        <button
                          onClick={() => {
                            if (window.confirm(`Delete "${set.name}" from library inventory?`)) {
                              setLegoSets(prev => prev.filter(s => s.id !== set.id));
                            }
                          }}
                          className="text-red-400 hover:text-red-600 border border-transparent hover:border-red-200 hover:bg-red-50 p-1.5 rounded"
                          title="Delete lego set box"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-PANEL 10: CALENDAR SCHEDULER */}
      {panelTab === 'calendar' && (
        <div className="space-y-6 animate-fade-in" id="admin-calendar-subpanel">
          <div>
            <h4 className="font-bangers text-2xl text-black tracking-widest uppercase">
              2026 PROGRAM CALENDAR MANAGER
            </h4>
            <p className="text-xs text-gray-500 font-semibold uppercase font-mono">
              Schedule camps, open houses, workshops, and tournaments on the year-round master program schedule.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left side Form to schedule event */}
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] text-left">
              <h5 className="font-bangers text-lg text-black mb-4 border-b border-dashed pb-2">
                SCHEDULE SEASONAL CAMPS / WORKSHOPS
              </h5>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!evtTitle || !evtDesc || !evtDate) return;
                  const newEvt: CalendarEvent = {
                    id: `evt_${Date.now()}`,
                    title: evtTitle,
                    description: evtDesc,
                    date: evtDate,
                    type: evtType
                  };
                  setEvents(prev => [...prev, newEvt]);
                  setEvtTitle('');
                  setEvtDesc('');
                }}
                className="space-y-3.5 text-xs text-left"
              >
                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Event Title *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Star Wars Holiday Robotics Camp..."
                    value={evtTitle}
                    onChange={(e) => setEvtTitle(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Program Description *</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Write active schedule details, difficulty expectations, and coach roster plans..."
                    value={evtDesc}
                    onChange={(e) => setEvtDesc(e.target.value)}
                    className="w-full bg-slate-50 border-2 border-black rounded-xl px-3 py-2 text-xs font-sans font-semibold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Date (YYYY-MM-DD) *</label>
                    <input
                      type="date"
                      required
                      value={evtDate}
                      onChange={(e) => setEvtDate(e.target.value)}
                      className="w-full bg-slate-50 border-2 border-black rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono font-black text-neutral-500 uppercase">Category *</label>
                    <select
                      value={evtType}
                      onChange={(e) => setEvtType(e.target.value as any)}
                      className="w-full bg-slate-50 border-2 border-black rounded-xl px-2.5 py-1.5 text-xs font-mono font-bold"
                    >
                      <option value="Camp">Camp</option>
                      <option value="Workshop">Workshop</option>
                      <option value="Holiday">Holiday</option>
                      <option value="Special Event">Special Event</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-legoyellow hover:bg-yellow-400 text-black border-2 border-black font-bangers text-xs tracking-widest py-2.5 rounded-xl shadow-[3px_3px_0px_#000] active:translate-y-0.5 cursor-pointer uppercase"
                >
                  PUBLISH EVENT TO CALENDAR
                </button>
              </form>
            </div>

            {/* Right side live events scheduled board */}
            <div className="lg:col-span-2 bg-white border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_#000]">
              <div className="bg-slate-50 p-3 border-b-2 border-black font-bangers text-sm text-black tracking-wider uppercase">
                SYSTEM ACTIVE YEAR SCHEDULE EVENTS LIST ({events.length})
              </div>

              <div className="divide-y divide-neutral-200 max-h-[380px] overflow-y-auto scroller-thick">
                {events.length === 0 ? (
                  <div className="p-8 text-center text-neutral-400 font-mono text-xs uppercase font-bold">
                    No scheduled calendar events found.
                  </div>
                ) : (
                  [...events].sort((a,b) => a.date.localeCompare(b.date)).map(evt => (
                    <div key={evt.id} className="p-4 flex items-center justify-between gap-3 text-xs">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs font-black text-indigo-700 uppercase bg-indigo-50 border border-indigo-200 px-2 rounded">
                            {evt.date}
                          </span>
                          <span className={`text-[9px] font-mono font-black uppercase px-2 rounded border ${
                            evt.type === 'Camp' ? 'bg-red-50 text-red-700 border-red-200' :
                            evt.type === 'Special Event' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                            'bg-green-50 text-green-700 border-green-200'
                          }`}>
                            {evt.type}
                          </span>
                        </div>
                        <h5 className="font-bangers text-sm text-black uppercase mt-1 tracking-wide">{evt.title}</h5>
                        <p className="text-[10px] text-gray-500 font-semibold font-sans leading-relaxed truncate max-w-[400px]">
                          {evt.description}
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete calendar event "${evt.title}"?`)) {
                            setEvents(prev => prev.filter(e => e.id !== evt.id));
                          }
                        }}
                        className="text-red-400 hover:text-red-600 border border-transparent hover:border-red-200 hover:bg-red-50 p-1.5 rounded shrink-0"
                        title="Delete scheduled event"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
