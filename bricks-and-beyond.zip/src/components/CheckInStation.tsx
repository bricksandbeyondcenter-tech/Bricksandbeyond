import React, { useState } from 'react';
import { Student, MinifigStyle, Booking } from '../types';
import { MinifigAvatar } from './MinifigAvatar';
import { 
  Search, 
  UserPlus, 
  LogIn, 
  LogOut, 
  Heart, 
  Phone, 
  Award, 
  Smile, 
  Plus, 
  Sparkles, 
  Filter, 
  X,
  Calendar,
  Lock,
  Mail,
  User,
  ShieldAlert,
  Clock,
  Check,
  RefreshCw
} from 'lucide-react';

interface CheckInStationProps {
  students: Student[];
  setStudents: React.Dispatch<React.SetStateAction<Student[]>>;
  bookings: Booking[];
  setBookings: React.Dispatch<React.SetStateAction<Booking[]>>;
  onCheckIn: (studentId: string, isCheckIn: boolean) => void;
  onAddStudent: (newStudent: Omit<Student, 'id' | 'avatar' | 'badges' | 'guestPassUsed' | 'setRentalUsed'>, avatar: MinifigStyle) => void;
  onCustomizeAvatar: (studentId: string) => void;
  loggedInParentEmail: string;
  setLoggedInParentEmail: React.Dispatch<React.SetStateAction<string>>;
  loggedInParentName: string;
  setLoggedInParentName: React.Dispatch<React.SetStateAction<string>>;
}

export const CheckInStation: React.FC<CheckInStationProps> = ({
  students,
  setStudents,
  bookings,
  setBookings,
  onCheckIn,
  onAddStudent,
  onCustomizeAvatar,
  loggedInParentEmail,
  setLoggedInParentEmail,
  loggedInParentName,
  setLoggedInParentName,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [membershipFilter, setMembershipFilter] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showSuccessCard, setShowSuccessCard] = useState<{
    visible: boolean;
    student: Student | null;
    type: 'checkin' | 'checkout';
    timestamp: string;
  }>({ visible: false, student: null, type: 'checkin', timestamp: '' });

  // Confirmation Modal State for checking in/out to avoid accidental clicks
  const [confirmCheckInStudent, setConfirmCheckInStudent] = useState<{
    student: Student;
    isCheckIn: boolean;
  } | null>(null);
  const [typedVerificationCode, setTypedVerificationCode] = useState('');
  const [generatedVerificationCode, setGeneratedVerificationCode] = useState('');
  const [verificationError, setVerificationError] = useState('');

  // Add Member Form Fields with Parent Password
  const [formFields, setFormFields] = useState({
    name: '',
    parentName: '',
    parentEmail: '',
    parentPhone: '',
    parentPassword: '',
    birthdate: '',
    emergencyName: '',
    emergencyPhone: '',
    school: '',
    dietaryRestrictions: '',
    membershipType: 'Not a Member' as Student['membershipType'],
    photoPermission: true,
  });

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.parentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.parentEmail.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter =
      membershipFilter === 'All' || student.membershipType === membershipFilter;

    return matchesSearch && matchesFilter;
  });

  const handleAction = (student: Student, isCheckIn: boolean) => {
    // Generate a random 3-digit verification code to prevent accidental click
    const code = Math.floor(100 + Math.random() * 900).toString();
    setGeneratedVerificationCode(code);
    setTypedVerificationCode('');
    setVerificationError('');
    setConfirmCheckInStudent({ student, isCheckIn });
  };

  const executeConfirmedCheckIn = () => {
    if (typedVerificationCode !== generatedVerificationCode) {
      setVerificationError('INCORRECT VERIFICATION CODE. PLEASE RE-ENTER!');
      return;
    }

    if (!confirmCheckInStudent) return;
    const { student, isCheckIn } = confirmCheckInStudent;

    // Record Check-in time
    onCheckIn(student.id, isCheckIn);

    // Show exciting full-screen success popup
    setShowSuccessCard({
      visible: true,
      student,
      type: isCheckIn ? 'checkin' : 'checkout',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    });

    setConfirmCheckInStudent(null);

    // Auto close after 3.5 seconds
    setTimeout(() => {
      setShowSuccessCard((prev) => ({ ...prev, visible: false }));
    }, 3800);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formFields.name || !formFields.parentName || !formFields.parentEmail || !formFields.parentPassword) {
      alert("Please enter the student name, parent name, email, and parent password.");
      return;
    }

    // Generate standard classic starting avatar
    const randomAvatar: MinifigStyle = {
      hairType: 'classic',
      hairColor: ['#78350F', '#171717', '#EAB308', '#DC2626'][Math.floor(Math.random() * 4)],
      expression: 'smile',
      torsoColor: ['#EF4444', '#3B82F6', '#10B981', '#EAB308'][Math.floor(Math.random() * 4)],
      torsoPrint: 'brick',
      legsColor: '#1E3A8A',
    };

    onAddStudent(formFields, randomAvatar);
    
    // Reset Form
    setFormFields({
      name: '',
      parentName: '',
      parentEmail: '',
      parentPhone: '',
      parentPassword: '',
      birthdate: '',
      emergencyName: '',
      emergencyPhone: '',
      school: '',
      dietaryRestrictions: '',
      membershipType: 'Not a Member',
      photoPermission: true,
    });
    
    setShowAddModal(false);
  };

  const [stationTab, setStationTab] = useState<'checkin' | 'parenthub'>('checkin');

  // Google authentication variables replaced by custom Parent Login session props
  const [tempEmail, setTempEmail] = useState('');
  const [tempPassword, setTempPassword] = useState('');
  const [parentLoginError, setParentLoginError] = useState('');

  // Preference / Booking Hub State
  const [selectedChildId, setSelectedChildId] = useState('');
  const [bookingDay, setBookingDay] = useState<string>('Monday');
  const [bookingHour, setBookingHour] = useState<string>('15:00');
  const [bookingNotes, setBookingNotes] = useState('');
  const [bookingSuccessMsg, setBookingSuccessMsg] = useState('');
  const [dietSuccessMsg, setDietSuccessMsg] = useState('');

  // Editing child form fields inside parent hub
  const [childEditForm, setChildEditForm] = useState({
    name: '',
    birthdate: '',
    school: '',
    dietaryRestrictions: '',
    parentPhone: '',
    emergencyName: '',
    emergencyPhone: '',
    membershipType: 'Not a Member' as Student['membershipType'],
  });

  const handleSelectChildToEdit = (childId: string) => {
    setSelectedChildId(childId);
    setDietSuccessMsg('');
    const child = students.find(s => s.id === childId);
    if (child) {
      setChildEditForm({
        name: child.name,
        birthdate: child.birthdate,
        school: child.school,
        dietaryRestrictions: child.dietaryRestrictions,
        parentPhone: child.parentPhone,
        emergencyName: child.emergencyName || '',
        emergencyPhone: child.emergencyPhone || '',
        membershipType: child.membershipType,
      });
    }
  };

  const handleSaveChildPreferences = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedChildId) return;

    setStudents(prev => prev.map(s => {
      if (s.id === selectedChildId) {
        return {
          ...s,
          name: childEditForm.name,
          birthdate: childEditForm.birthdate,
          school: childEditForm.school,
          dietaryRestrictions: childEditForm.dietaryRestrictions,
          parentPhone: childEditForm.parentPhone,
          emergencyName: childEditForm.emergencyName,
          emergencyPhone: childEditForm.emergencyPhone,
          membershipType: childEditForm.membershipType,
        };
      }
      return s;
    }));

    setDietSuccessMsg("All preferences, dietary and allergy restrictions are saved and figured out. Your child's profile is now synchronized. ✓");
    setTimeout(() => setDietSuccessMsg(''), 6000);
  };

  const handleBookSessionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedInParentEmail || !selectedChildId) {
      alert("Please select a child to book a session!");
      return;
    }

    const child = students.find(s => s.id === selectedChildId);
    if (!child) return;

    const newBooking: Booking = {
      id: 'booking_' + Math.random().toString(36).substring(2, 11),
      studentId: child.id,
      studentName: child.name,
      parentEmail: loggedInParentEmail,
      day: bookingDay,
      hour: bookingHour,
      notes: bookingNotes,
      createdAt: new Date().toLocaleDateString()
    };

    setBookings(prev => [...prev, newBooking]);
    setBookingNotes('');
    setBookingSuccessMsg(`Awesome! Booked session for ${child.name} on ${bookingDay} at ${bookingHour} successfully! Let's build!`);
    setTimeout(() => setBookingSuccessMsg(''), 6000);
  };

  const handleParentLogout = () => {
    setLoggedInParentEmail('');
    setLoggedInParentName('');
    localStorage.removeItem('bricks_logged_in_parent_email');
    localStorage.removeItem('bricks_logged_in_parent_name');
  };

  // Quick helper to register a child connected directly to the logged-in parent
  const [quickRegName, setQuickRegName] = useState('');
  const [quickRegAge, setQuickRegAge] = useState('');
  const [quickRegRestrict, setQuickRegRestrict] = useState('');
  const [quickRegPhone, setQuickRegPhone] = useState('');

  const handleQuickRegisterChild = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loggedInParentEmail || !quickRegName) return;

    // Find the current parent's password from their existing students (if any)
    const existingChild = students.find(s => s.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim());
    const matchedPassword = existingChild?.parentPassword || 'password';

    const newId = 'std_' + Math.random().toString(36).substring(2, 11);
    const newStd: Student = {
      id: newId,
      name: quickRegName,
      parentName: loggedInParentName || 'Parent',
      parentEmail: loggedInParentEmail,
      parentPhone: quickRegPhone || 'Unspecified Phone',
      parentPassword: matchedPassword,
      birthdate: quickRegAge || '6 years old',
      emergencyName: '',
      emergencyPhone: '',
      school: '',
      dietaryRestrictions: quickRegRestrict || 'None',
      membershipType: 'Not a Member',
      photoPermission: true,
      guestPassUsed: false,
      setRentalUsed: false,
      badges: { apprentice: 0, bridge_builder: 0, space_cadet: 0, helper: 0, technic: 0 },
      avatar: {
        hairType: 'classic',
        hairColor: '#EAB308',
        expression: 'smile',
        torsoColor: '#10B981',
        torsoPrint: 'classic-space',
        legsColor: '#1E3A8A'
      }
    };

    setStudents(prev => [...prev, newStd]);
    setQuickRegName('');
    setQuickRegAge('');
    setQuickRegRestrict('');
    setQuickRegPhone('');
    setSelectedChildId(newId);
    handleSelectChildToEdit(newId);
  };

  return (
    <div className="space-y-6">
      {/* TAB SELECTOR HEADER FRAME */}
      <div className="flex gap-2.5 border-b-4 border-black pb-1 overflow-x-auto">
        <button
          type="button"
          onClick={() => setStationTab('checkin')}
          className={`flex items-center gap-2 px-5 py-3 rounded-t-2xl font-bangers text-sm sm:text-base tracking-widest transition-all ${
            stationTab === 'checkin'
              ? 'bg-legoyellow text-black border-t-4 border-x-4 border-black shadow-[4px_4px_0px_#000] translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-neutral-50 border-t-2 border-x-2 border-gray-200'
          }`}
        >
          <LogIn className="w-5 h-5 text-legored" />
          1. LIVE ASSEMBLY CHECK-IN DESK
        </button>

        <button
          type="button"
          id="parent-hub-tab"
          onClick={() => setStationTab('parenthub')}
          className={`flex items-center gap-2 px-5 py-3 rounded-t-2xl font-bangers text-sm sm:text-base tracking-widest transition-all ${
            stationTab === 'parenthub'
              ? 'bg-legoyellow text-black border-t-4 border-x-4 border-black shadow-[4px_4px_0px_#000] translate-y-[4px]'
              : 'bg-white text-gray-500 hover:text-black hover:bg-neutral-50 border-t-2 border-x-2 border-gray-200'
          }`}
        >
          <Mail className="w-5 h-5 text-legoblue" />
          2. GOOGLE SECURED PARENT HUB & BOOKINGS
        </button>
      </div>

      {stationTab === 'checkin' ? (
        <>
          {/* Search and Filters topbar */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-legoyellow border-4 border-black rounded-2xl p-5 shadow-[8px_8px_0px_#000]">
            <div className="flex-1 relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-black w-5 h-5" />
              <input
                type="text"
                id="search-students"
                placeholder="Search student or parent name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-11 pr-4 py-2.5 bg-white border-2 border-black rounded-lg font-medium font-blueberry text-black placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-legoblue shadow-[2px_2px_0px_rgba(0,0,0,1)]"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <Filter className="w-4 h-4 text-black shrink-0 hidden sm:inline" />
              {['All', 'Master Builder', 'Adventurer', 'Not a Member'].map((filter) => (
                <button
                  key={filter}
                  type="button"
                  onClick={() => setMembershipFilter(filter)}
                  className={`px-3 py-1.5 rounded-lg border-2 border-black font-bangers text-xs tracking-widest uppercase transition-all shrink-0 active:translate-y-0.5 ${
                    membershipFilter === filter
                      ? 'bg-legoblue text-white shadow-[2px_2px_0px_#000] translate-y-[-1px]'
                      : 'bg-white hover:bg-neutral-50 text-black shadow-[2px_2px_0px_#000]'
                  }`}
                >
                  {filter === 'All' ? 'ALL MEMBERS' : filter}
                </button>
              ))}
              <button
                type="button"
                id="add-student-btn"
                onClick={() => setShowAddModal(true)}
                className="flex items-center gap-1.5 bg-legogreen hover:opacity-95 text-white font-bangers text-xs tracking-widest uppercase px-4 py-2 rounded-lg border-2 border-black shadow-[4px_4px_0px_#000] shrink-0 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all"
              >
                <UserPlus className="w-4 h-4" />
                REGISTER NEW
              </button>
            </div>
          </div>

          {/* Grid of Students */}
          {filteredStudents.length === 0 ? (
            <div className="bg-white rounded-2xl border-4 border-black p-12 text-center shadow-[8px_8px_0px_#E3000B]">
              <Smile className="w-16 h-16 text-legoyellow mx-auto stroke-2 mb-2" />
              <h3 className="font-bangers text-2xl text-black">NO BUILDERS FOUND!</h3>
              <p className="font-blueberry text-gray-600 max-w-md mx-auto mt-1">
                "We couldn't find matches for '{searchTerm}'. Check the spelling or click the green button above to register a new student!"
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredStudents.map((student) => (
                <div
                  key={student.id}
                  className={`bg-white rounded-2xl border-4 border-black p-5 relative flex flex-col justify-between transition-all hover:translate-y-[-2px] ${
                    student.checkedInToday 
                      ? 'border-[#008542] shadow-[8px_8px_0px_#008542]' 
                      : 'border-black shadow-[8px_8px_0px_#E3000B]'
                  }`}
                >
                  <div>
                    {/* Membership Badges / Indicators */}
                    <div className="absolute top-3 right-3 flex gap-1">
                      {student.membershipType === 'Master Builder' && (
                        <span className="bg-legored text-white border-2 border-black font-bangers text-[10px] px-2 py-0.5 rounded shadow-[1.5px_1.5px_0px_#000] tracking-wider uppercase">
                          Master
                        </span>
                      )}
                      {student.membershipType === 'Adventurer' && (
                        <span className="bg-legoblue text-white border-2 border-black font-bangers text-[10px] px-2 py-0.5 rounded shadow-[1.5px_1.5px_0px_#000] tracking-wider uppercase">
                          Adventurer
                        </span>
                      )}
                      {student.membershipType === 'Not a Member' && (
                        <span className="bg-slate-100 text-slate-600 border-2 border-slate-300 font-bangers text-[10px] px-2 py-0.5 rounded tracking-wider uppercase">
                          Guest
                        </span>
                      )}
                    </div>

                    {/* Minifig Avatar Frame in Lego-style head background block */}
                    <div className="flex flex-col items-center pt-2">
                      <div className="w-24 h-24 bg-legoyellow rounded-[2rem] border-4 border-black relative overflow-hidden flex items-center justify-center p-2 shadow-[4px_4px_0px_rgba(0,0,0,0.15)] hover:scale-105 transition-transform cursor-pointer group" onClick={() => onCustomizeAvatar(student.id)}>
                        <MinifigAvatar style={student.avatar} size={74} className="filter drop-shadow-md" />
                        <div className="absolute inset-0 bg-black/60 text-white text-[10px] font-bangers flex items-center justify-center tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity">
                          EDIT BOT
                        </div>
                      </div>

                      <h3 id={`student-name-${student.id}`} className="font-bangers text-2xl text-black tracking-wide mt-3 text-center truncate w-full" style={{ textShadow: '1px 1px 0px rgba(0,0,0,0.05)' }}>
                        {student.name}
                      </h3>
                      <p className="font-blueberry text-xs text-gray-500 text-center font-semibold">
                        Parent: {student.parentName}
                      </p>
                    </div>

                    {/* Mini Badges or Food Alert */}
                    <div className="mt-4 pt-3 border-t-2 border-dashed border-gray-200 space-y-1.5 text-xs">
                      {student.dietaryRestrictions && student.dietaryRestrictions !== 'None' && (
                        <div className="flex items-center gap-1.5 text-legored font-semibold bg-red-50 border border-red-200 px-2.5 py-1 rounded-lg">
                          <Heart className="w-3.5 h-3.5 shrink-0 fill-red-100 text-legored" />
                          <span className="truncate">Diet: {student.dietaryRestrictions}</span>
                        </div>
                      )}

                      <div className="flex justify-between items-center text-gray-600 font-medium font-blueberry">
                        <span className="flex items-center gap-1 text-[11px] font-semibold"><Phone className="w-3.5 h-3.5 text-slate-500" /> {student.parentPhone}</span>
                        <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-300 text-[10px] font-bold">Age: {student.birthdate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Action Buttons */}
                  <div className="mt-5 pt-3 border-t-2 border-black flex gap-2">
                    {!student.checkedInToday ? (
                      <button
                        type="button"
                        id={`checkin-btn-${student.id}`}
                        onClick={() => handleAction(student, true)}
                        className="w-full bg-legogreen hover:opacity-95 text-white font-bangers text-lg py-2.5 px-4 rounded-xl border-2 border-black shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all flex items-center justify-center gap-2"
                      >
                        <LogIn className="w-5 h-5" />
                        CHECK-IN
                      </button>
                    ) : (
                      <button
                        type="button"
                        id={`checkout-btn-${student.id}`}
                        onClick={() => handleAction(student, false)}
                        className="w-full bg-legored hover:opacity-95 text-white font-bangers text-lg py-2.5 px-4 rounded-xl border-2 border-black shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all flex items-center justify-center gap-2"
                      >
                        <LogOut className="w-5 h-5" />
                        CHECK-OUT
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      ) : (
        /* SECURE PARENT PORTAL - LOGIN & CHILD MANAGEMENT */
        <div className="animate-fade-in space-y-6 text-left">
          {!loggedInParentEmail ? (
            <div className="bg-white border-4 border-black rounded-3xl p-8 max-w-lg mx-auto text-center shadow-[8px_8px_0px_#000]">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto border-2 border-black mb-4 shadow text-indigo-600">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="font-bangers text-3xl text-black tracking-widest leading-none">PARENT HUB SIGN-IN</h3>
              <p className="font-blueberry text-xs text-neutral-500 font-bold uppercase tracking-wide mt-2">
                Log in with your Parent Email & Password to manage diets, safeguards, and book play sessions!
              </p>

              <div className="mt-6 border-2 border-slate-200 border-dashed p-6 rounded-2xl space-y-4">
                <form onSubmit={(e) => {
                  e.preventDefault();
                  setParentLoginError('');
                  const emailTrim = tempEmail.trim().toLowerCase();
                  const matchedStudents = students.filter(s => s.parentEmail.toLowerCase().trim() === emailTrim);

                  if (matchedStudents.length === 0) {
                    setParentLoginError("No registered builder found with this parent email. Please register your child first at the Reception Desk!");
                    return;
                  }

                  const match = matchedStudents.find(s => s.parentPassword === tempPassword);
                  if (!match) {
                    setParentLoginError("Incorrect password. Please verify your parent credentials or ask our coaches for assistance!");
                    return;
                  }

                  setLoggedInParentEmail(emailTrim);
                  setLoggedInParentName(match.parentName);
                  localStorage.setItem('bricks_logged_in_parent_email', emailTrim);
                  localStorage.setItem('bricks_logged_in_parent_name', match.parentName);
                  setTempEmail('');
                  setTempPassword('');
                }} className="space-y-4 text-left">
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">Parent Email Address</label>
                    <input 
                      type="email" 
                      required 
                      placeholder="e.g. parent@gmail.com" 
                      value={tempEmail} 
                      onChange={e => setTempEmail(e.target.value)} 
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm bg-slate-50 font-semibold focus:bg-white focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-700 block mb-1">Parent Password</label>
                    <input 
                      type="password" 
                      required 
                      placeholder="Enter parent password..." 
                      value={tempPassword} 
                      onChange={e => setTempPassword(e.target.value)} 
                      className="w-full border-2 border-black rounded-lg px-3 py-2 text-sm bg-slate-50 font-semibold focus:bg-white focus:outline-none"
                    />
                  </div>

                  {parentLoginError && (
                    <p className="bg-red-50 border border-red-300 text-red-600 rounded-lg p-2.5 text-center text-xs font-bold font-mono uppercase flex items-center justify-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
                      {parentLoginError}
                    </p>
                  )}

                  <button
                    type="submit"
                    className="w-full bg-legoblue hover:opacity-95 text-white border-2 border-black font-bangers tracking-wider text-sm py-2.5 rounded-lg shadow-[2px_2px_0px_#000] cursor-pointer"
                  >
                    SECURE PARENT LOG IN
                  </button>
                </form>

                <div className="pt-3 text-[11px] font-mono text-neutral-400 text-center leading-normal">
                  <span className="font-bold text-neutral-600 block mb-0.5">NEED AN ACCOUNT?</span>
                  Register your builder at the check-in tab and define your password there!
                </div>
              </div>
            </div>
          ) : (
            /* Connected Parent Hub Section */
            <div className="space-y-6 text-left">
              <div className="bg-gradient-to-r from-legoblue to-indigo-600 text-white rounded-2xl border-4 border-black p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[4px_4px_0px_#000]">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-2 border-black text-indigo-600 shadow">
                    <User className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="bg-yellow-400 text-black text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded border border-black inline-block">
                      PARENT SESSION SECURED ✓
                    </span>
                    <h3 className="font-bangers text-2xl tracking-widest uppercase leading-none mt-1">
                      {loggedInParentName.toUpperCase()}'s PARENT CONSOLE
                    </h3>
                    <p className="text-xs font-mono font-bold text-blue-100 uppercase mt-0.5">
                      Email: {loggedInParentEmail} (Preferences stored & synced)
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={handleParentLogout}
                  className="bg-legored hover:opacity-95 text-white font-bangers text-xs uppercase px-4 py-2 border-2 border-black rounded-xl shadow-[2px_2px_0px_#000] flex items-center gap-1.5 active:translate-y-0.5 cursor-pointer text-center"
                >
                  <LogOut className="w-4 h-4" />
                  LOG OUT
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
                {/* Left Column: Preferences and Diet/Allergies Safeguards */}
                <div className="lg:col-span-6 bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] flex flex-col justify-between">
                  <div>
                    <h4 className="font-bangers text-xl text-black border-b-2 border-dashed border-neutral-100 pb-2 mb-4 flex items-center gap-1.5">
                      <Heart className="w-5 h-5 text-legored fill-red-100" />
                      1. SAFEGUARDS, ALLERGIES & DIET
                    </h4>

                    <p className="text-xs text-neutral-500 font-mono font-bold mb-4">
                      Below are the child accounts registered under your Google email on our roster. Click on one to update their dietary, health, or Emergency Escort specifications instantly.
                    </p>

                    {/* Kids roster selection buttons */}
                    {students.filter(s => s.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim()).length === 0 ? (
                      <div className="bg-yellow-50 border-2 border-dashed border-yellow-400 rounded-xl p-4 text-center text-xs font-bold text-indigo-900 font-mono mb-4">
                        No builder accounts are registered under "{loggedInParentEmail}" yet. Type your builder's details in the quick registry form below to register and link them instantly!
                      </div>
                    ) : (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {students.filter(s => s.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim()).map(child => (
                          <button
                            key={child.id}
                            type="button"
                            onClick={() => handleSelectChildToEdit(child.id)}
                            className={`flex items-center gap-2 px-3 py-2 rounded-xl border-2 transition-all font-bangers text-xs tracking-wider uppercase ${
                              selectedChildId === child.id
                                ? 'bg-legoyellow border-black shadow-[2px_2px_0px_#000]'
                                : 'bg-slate-50 border-neutral-200 hover:border-black'
                            }`}
                          >
                            <MinifigAvatar style={child.avatar} size={24} />
                            {child.name.toUpperCase()}
                          </button>
                        ))}
                      </div>
                    )}

                    {selectedChildId && students.find(s => s.id === selectedChildId) ? (
                      <form onSubmit={handleSaveChildPreferences} className="space-y-3 p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                        <span className="bg-legoblue text-white text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded border border-black inline-block">
                          EDITING {childEditForm.name.toUpperCase()}'s PROFILE
                        </span>
                        
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">BUILDER NAME *</label>
                            <input
                              type="text"
                              required
                              value={childEditForm.name}
                              onChange={e => setChildEditForm({...childEditForm, name: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">AGE / BIRTHDATE *</label>
                            <input
                              type="text"
                              required
                              value={childEditForm.birthdate}
                              onChange={e => setChildEditForm({...childEditForm, birthdate: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">DIETARY SAFEGUARDS & ALLERGIES *</label>
                          <textarea
                            required
                            rows={2}
                            value={childEditForm.dietaryRestrictions}
                            onChange={e => setChildEditForm({...childEditForm, dietaryRestrictions: e.target.value})}
                            placeholder="e.g. Gluten-Free option, Peanut allergy, Lactose-intolerant, etc."
                            className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                          />
                          <p className="text-[10px] text-neutral-400 font-mono mt-0.5 leading-tight">
                            * When saved, checkout alerts automatically trigger visual alerts on the live check-in board!
                          </p>
                        </div>

                        <div className="grid grid-cols-2 gap-3 font-blueberry">
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">PARENT PHONE</label>
                            <input
                              type="text"
                              required
                              value={childEditForm.parentPhone}
                              onChange={e => setChildEditForm({...childEditForm, parentPhone: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">SCHOOL NAME</label>
                            <input
                              type="text"
                              value={childEditForm.school}
                              onChange={e => setChildEditForm({...childEditForm, school: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3 border-t border-dashed border-slate-200 pt-2.5 font-blueberry">
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">EMERGENCY ESCORT CO-BUILDER</label>
                            <input
                              type="text"
                              placeholder="e.g. Grandma Helen"
                              value={childEditForm.emergencyName}
                              onChange={e => setChildEditForm({...childEditForm, emergencyName: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-mono font-bold text-gray-500 block mb-1">EMERGENCY ESCORT PHONE</label>
                            <input
                              type="text"
                              placeholder="e.g. 555-0199"
                              value={childEditForm.emergencyPhone}
                              onChange={e => setChildEditForm({...childEditForm, emergencyPhone: e.target.value})}
                              className="w-full bg-white border-2 border-black rounded-lg px-2.5 py-1.5 text-xs font-semibold"
                            />
                          </div>
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-legogreen text-white font-bangers text-xs tracking-wider py-2 rounded-lg border-2 border-black shadow-[3px_3px_0px_#000] hover:opacity-95 active:translate-y-0.5"
                        >
                          SAVE DIET & ALLERGY SAFEGUARDS
                        </button>

                        {dietSuccessMsg && (
                          <p className="bg-green-50 border border-green-400 text-green-950 rounded-lg p-2.5 font-semibold text-xs leading-relaxed animate-fade-in font-mono mt-2 text-center">
                            {dietSuccessMsg}
                          </p>
                        )}
                      </form>
                    ) : null}
                  </div>

                  {/* Quick Roster Add Area */}
                  <div className="mt-6 pt-5 border-t-2 border-dashed border-slate-200">
                    <h5 className="font-bangers text-sm text-black uppercase mb-3 flex items-center gap-1">
                      <Plus className="w-4 h-4 text-legogreen" />
                      Register & Link New Child Under this Google Account
                    </h5>

                    <form onSubmit={handleQuickRegisterChild} className="grid grid-cols-2 gap-2 text-left bg-slate-50 border border-slate-200 rounded-xl p-3 font-blueberry">
                      <div>
                        <label className="text-[9px] font-bold text-gray-600 block mb-0.5">Child Full Name *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Samuel G."
                          value={quickRegName}
                          onChange={e => setQuickRegName(e.target.value)}
                          className="w-full border-2 border-black bg-white rounded-md px-2 py-1 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-bold text-gray-600 block mb-0.5">Age/Birthdate *</label>
                        <input
                          type="text"
                          placeholder="e.g. 7 years old"
                          value={quickRegAge}
                          onChange={e => setQuickRegAge(e.target.value)}
                          className="w-full border-2 border-black bg-white rounded-md px-2 py-1 text-xs"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="text-[9px] font-bold text-gray-600 block mb-0.5">Dietary Restrictions & Allergies</label>
                        <input
                          type="text"
                          placeholder="e.g. Gluten Allergy, Nut allergy"
                          value={quickRegRestrict}
                          onChange={e => setQuickRegRestrict(e.target.value)}
                          className="w-full border-2 border-black bg-white rounded-md px-2 py-1 text-xs"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-bold text-gray-600 block mb-0.5">Contact-Phone</label>
                        <input
                          type="text"
                          placeholder="e.g. 88102244"
                          value={quickRegPhone}
                          onChange={e => setQuickRegPhone(e.target.value)}
                          className="w-full border-2 border-black bg-white rounded-md px-2 py-1 text-xs"
                        />
                      </div>
                      <div className="flex items-end">
                        <button
                          type="submit"
                          className="w-full bg-legoblue hover:opacity-95 text-white font-bangers text-[11px] tracking-wider py-1.5 rounded-lg border-2 border-black shadow-[1.5px_1.5px_0px_#000]"
                        >
                          LINK CHILD ACCOUNT
                        </button>
                      </div>
                    </form>
                  </div>
                </div>

                {/* Right Column: Book a Brick Assembly Session & Ticket Dashboard */}
                <div className="lg:col-span-6 bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_#000] flex flex-col justify-between">
                  <div>
                    <h4 className="font-bangers text-xl text-black border-b-2 border-dashed border-neutral-100 pb-2 mb-4 flex items-center gap-1.5">
                      <Calendar className="w-5 h-5 text-legoblue" />
                      2. BOOK CHALLENGE ASSEMBLY SESSION
                    </h4>

                    <form onSubmit={handleBookSessionSubmit} className="space-y-4 bg-yellow-50 border-2 border-yellow-400 p-4 rounded-2xl shadow-[3px_3px_0px_rgba(0,0,0,0.05)]">
                      <div>
                        <label className="text-[10px] font-mono font-bold text-gray-600 block mb-1">CHOOSE REGISTERED CHILD *</label>
                        <select
                          required
                          value={selectedChildId}
                          onChange={e => handleSelectChildToEdit(e.target.value)}
                          className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-xs font-semibold"
                        >
                          <option value="">-- Select Child --</option>
                          {students.filter(s => s.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim()).map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[10px] font-mono font-bold text-gray-600 block mb-1">SELECT ASSEMBLY DAY *</label>
                          <select
                            value={bookingDay}
                            onChange={e => setBookingDay(e.target.value)}
                            className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-xs font-semibold"
                          >
                            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(d => (
                              <option key={d} value={d}>{d}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="text-[10px] font-mono font-bold text-gray-600 block mb-1">SELECT HOURLY WINDOW *</label>
                          <select
                            value={bookingHour}
                            onChange={e => setBookingHour(e.target.value)}
                            className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-xs font-semibold"
                          >
                             <option value="09:00 AM">09:00 AM - 10:00 AM</option>
                             <option value="10:00 AM">10:00 AM - 11:00 AM</option>
                             <option value="11:00 AM">11:00 AM - 12:00 PM</option>
                             <option value="12:00 PM">12:00 PM - 01:00 PM</option>
                             <option value="01:00 PM">01:00 PM - 02:00 PM</option>
                             <option value="02:00 PM">02:00 PM - 03:00 PM</option>
                             <option value="03:00 PM">03:00 PM - 04:00 PM</option>
                             <option value="04:00 PM">04:00 PM - 05:00 PM</option>
                             <option value="05:00 PM">05:00 PM - 06:00 PM</option>
                             <option value="06:00 PM">06:00 PM - 07:00 PM</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-mono font-bold text-gray-600 block mb-1">PARENT NOTES (DIET, BUILDING SPECS, OR COG LEARNINGS)</label>
                        <input
                          type="text"
                          placeholder="e.g. Sammy will be building gears! Bring extra blocks."
                          value={bookingNotes}
                          onChange={e => setBookingNotes(e.target.value)}
                          className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-xs font-semibold"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-legoblue hover:bg-blue-600 text-white font-bangers text-xs sm:text-sm tracking-widest py-2.5 rounded-xl border-2 border-black shadow-[4px_4px_0px_#000] flex items-center justify-center gap-2 active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all"
                      >
                        <Clock className="w-4 h-4" />
                        CONFIRM SECURE BRICK BOOKING
                      </button>

                      {bookingSuccessMsg && (
                        <p className="bg-indigo-50 border border-indigo-400 text-indigo-950 font-semibold rounded-lg p-2 text-center text-xs animate-fade-in font-mono leading-relaxed">
                          {bookingSuccessMsg}
                        </p>
                      )}
                    </form>
                  </div>

                  {/* Booked Sessions Ticketing Deck */}
                  <div className="mt-6 pt-5 border-t-2 border-dashed border-slate-200">
                    <h5 className="font-bangers text-sm text-black uppercase mb-3 flex items-center gap-1 animate-pulse">
                      <Calendar className="w-4 h-4 text-indigo-600" />
                      My Registered Session Tickets
                    </h5>

                    {bookings.filter(b => b.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim()).length === 0 ? (
                      <p className="text-xs text-neutral-400 font-mono italic text-center py-4 bg-slate-50 border border-slate-200 rounded-xl">
                        No active bookings on the schedule yet. Select a child and fill the form above to book an assembly slot!
                      </p>
                    ) : (
                      <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 font-blueberry">
                        {bookings.filter(b => b.parentEmail.toLowerCase().trim() === loggedInParentEmail.toLowerCase().trim()).map(b => (
                          <div
                            key={b.id}
                            className="bg-slate-50 border-2 border-black rounded-xl p-3 flex justify-between items-center relative overflow-hidden shadow-[2px_2px_0px_#000]"
                          >
                            {/* Retro ticket visual side bumps */}
                            <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-r-2 border-black rounded-full z-10"></div>
                            <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-l-2 border-black rounded-full z-10"></div>

                            <div className="pl-3 min-w-0 flex-grow text-left">
                              <div className="flex items-center gap-2">
                                <span className="font-bangers text-base tracking-wider text-black">
                                  {b.studentName.toUpperCase()}
                                </span>
                                <span className="bg-legoyellow text-black text-[9px] font-bold border border-black px-1.5 py-0.2 rounded font-mono">
                                  ACTIVE RESERVATION
                                </span>
                              </div>
                              <p className="text-[11px] font-bold text-gray-600 font-mono flex items-center gap-1.5 mt-0.5">
                                <Calendar className="w-3.5 h-3.5 text-neutral-500 shrink-0" /> {b.day} @ {b.hour}
                              </p>
                              {b.notes && (
                                <p className="text-[10px] text-gray-500 font-medium truncate italic mt-0.5">
                                  "{b.notes}"
                                </p>
                              )}
                            </div>
                            <button
                              type="button"
                              onClick={() => setBookings(prev => prev.filter(bk => bk.id !== b.id))}
                              className="text-red-500 hover:text-red-700 bg-white hover:bg-neutral-100 p-1.5 rounded border border-neutral-300 shadow cursor-pointer mr-2 shrink-0"
                              title="Cancel Booking"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUCCESS POPUP MODAL/CARD */}
      {showSuccessCard.visible && showSuccessCard.student && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-legoyellow border-8 border-black rounded-[2.5rem] max-w-md w-full p-8 text-center relative shadow-[12px_12px_0px_#000] overflow-hidden">
            {/* Visual Confetti style stars */}
            <div className="absolute top-6 left-6 w-8 h-8 fill-legored text-legored animate-bounce">
              <Sparkles />
            </div>
            <div className="absolute top-10 right-8 w-6 h-6 fill-legoblue text-legoblue animate-pulse">
              <Sparkles />
            </div>

            <div className="flex flex-col items-center">
              <div className="bg-white rounded-[2rem] p-4 border-4 border-black shadow-[6px_6px_0px_rgba(0,0,0,0.15)]">
                <MinifigAvatar style={showSuccessCard.student.avatar} size={130} />
              </div>

              <h2 className="font-bangers text-4xl text-black tracking-wide uppercase mt-6" style={{ textShadow: '2px 2px 0px rgba(255,255,255,0.5)' }}>
                {showSuccessCard.type === 'checkin' ? 'AWESOME CHECK-IN!' : 'GOODBYE BUILDER!'}
              </h2>

              <p className="font-blueberry text-xl font-bold text-black border-2 border-black bg-white rounded-xl px-6 py-2 shadow-[4px_4px_0px_#000] mt-3">
                {showSuccessCard.student.name}
              </p>

              <div className="mt-4 text-black font-bangers text-lg tracking-wider">
                {showSuccessCard.type === 'checkin' ? (
                  <span className="text-legogreen">ENTERING AT {showSuccessCard.timestamp}</span>
                ) : (
                  <span className="text-legored">DEPARTING AT {showSuccessCard.timestamp}</span>
                )}
              </div>

              {/* Special Badge notice for checkin */}
              {showSuccessCard.type === 'checkin' && (
                <div className="mt-5 bg-white border-2 border-black rounded-xl p-3 w-full flex items-center justify-center gap-2 shadow-[3px_3px_0px_#000]">
                  <Award className="w-5 h-5 text-legored fill-red-300 shrink-0" />
                  <span className="text-xs font-bold text-black font-blueberry text-left">
                    {showSuccessCard.student.membershipType === 'Master Builder' 
                      ? 'Master Builder status active! Unlimited assembly passes.'
                      : 'Adventurer pass active! Level up your brick challenge progress today.'}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ACCIDENTAL CLICK PROTECTION MODAL */}
      {confirmCheckInStudent && (
        <div className="fixed inset-0 bg-black/65 backdrop-blur-xs flex items-center justify-center z-50 p-4 animate-fade-in">
          <div className="bg-white border-4 border-black rounded-3xl max-w-sm w-full p-6 shadow-[8px_8px_0px_#000] text-center">
            <div className="w-16 h-16 bg-legoyellow rounded-full flex items-center justify-center mx-auto border-2 border-black mb-3 shadow">
              <MinifigAvatar style={confirmCheckInStudent.student.avatar} size={48} />
            </div>

            <h3 className="font-bangers text-2xl text-black tracking-widest uppercase flex items-center justify-center gap-1.5">
              <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0" />
              {confirmCheckInStudent.isCheckIn ? 'CONFIRM CHECK-IN' : 'CONFIRM CHECK-OUT'}
            </h3>
            
            <p className="font-blueberry text-sm text-neutral-600 mt-2 font-semibold">
              Are you sure you want to {confirmCheckInStudent.isCheckIn ? 'check-in' : 'check-out'}{' '}
              <span className="text-black font-extrabold">{confirmCheckInStudent.student.name}</span>?
            </p>

            {/* Accidental click check: Type the verification code */}
            <div className="mt-4 p-4 bg-slate-50 border-2 border-black rounded-2xl space-y-3">
              <label className="block text-[10px] font-mono font-black text-neutral-500 uppercase tracking-widest text-left">
                ENTER VERIFICATION CODE TO CONFIRM
              </label>
              
              <div className="flex items-center justify-between bg-yellow-100 border-2 border-black px-4 py-2 rounded-xl">
                <span className="text-xs font-mono font-bold text-neutral-600">PLEASE TYPE THIS CODE:</span>
                <span className="font-bangers text-xl text-legored tracking-widest select-none bg-white border border-black px-2.5 py-0.5 rounded shadow-sm">
                  {generatedVerificationCode}
                </span>
              </div>

              <input
                type="text"
                required
                maxLength={4}
                placeholder="Type code here..."
                value={typedVerificationCode}
                onChange={(e) => setTypedVerificationCode(e.target.value)}
                className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-center font-mono font-bold text-lg tracking-widest focus:outline-none"
              />

              {verificationError && (
                <p className="text-[10px] text-red-600 font-bold uppercase font-mono leading-tight">
                  {verificationError}
                </p>
              )}
            </div>

            <div className="flex gap-2.5 mt-5">
              <button
                type="button"
                onClick={() => setConfirmCheckInStudent(null)}
                className="w-1/2 px-4 py-2 bg-slate-100 hover:bg-slate-200 border-2 border-black rounded-xl font-bangers text-xs tracking-wider uppercase"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={executeConfirmedCheckIn}
                className="w-1/2 px-4 py-2 bg-legogreen text-white hover:opacity-95 border-2 border-black rounded-xl font-bangers text-xs tracking-widest uppercase shadow-[2.5px_2.5px_0px_#000] active:translate-y-0.5"
              >
                YES, PROCEED
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD MEMBER POPUP FORM MODAL */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-40 p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl border-4 border-black w-full max-w-2xl shadow-[10px_10px_0px_#000] overflow-hidden">
            {/* Modal Header */}
            <div className="bg-legoblue border-b-4 border-black p-5 flex justify-between items-center text-white">
              <h3 className="font-bangers text-2xl tracking-widest uppercase flex items-center gap-2" style={{ textShadow: '1.5px 1.5px 0px #000' }}>
                <UserPlus className="w-6 h-6 text-legoyellow" />
                NEW STUDENT REGISTRATION
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="bg-legored hover:opacity-95 text-white border-2 border-black p-1.5 rounded-lg shadow-[2px_2px_0px_#000] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleFormSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Student Info */}
                <div className="space-y-3">
                  <h4 className="font-bangers text-lg text-legoblue border-b-2 border-slate-200 pb-1 tracking-wider uppercase">1. Student Details</h4>
                  
                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Student Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Felix Amador"
                      value={formFields.name}
                      onChange={(e) => setFormFields({ ...formFields, name: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Student Birthdate or Age *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., 6 years old or 25/06/2018"
                      value={formFields.birthdate}
                      onChange={(e) => setFormFields({ ...formFields, birthdate: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Student's School</label>
                    <input
                      type="text"
                      placeholder="e.g., Connell Academy"
                      value={formFields.school}
                      onChange={(e) => setFormFields({ ...formFields, school: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Dietary Restrictions / Allergies</label>
                    <input
                      type="text"
                      placeholder="e.g., Gluten-Free, Nut Allergy, None"
                      value={formFields.dietaryRestrictions}
                      onChange={(e) => setFormFields({ ...formFields, dietaryRestrictions: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>
                </div>

                {/* Parent Info */}
                <div className="space-y-3">
                  <h4 className="font-bangers text-lg text-legogreen border-b-2 border-slate-200 pb-1 tracking-wider uppercase">2. Parent / Guardian</h4>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Parent Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Julia Delafield"
                      value={formFields.parentName}
                      onChange={(e) => setFormFields({ ...formFields, parentName: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Email Address *</label>
                    <input
                      type="email"
                      required
                      placeholder="e.g., parent@gmail.com"
                      value={formFields.parentEmail}
                      onChange={(e) => setFormFields({ ...formFields, parentEmail: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Phone Number *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g., 87046522"
                      value={formFields.parentPhone}
                      onChange={(e) => setFormFields({ ...formFields, parentPhone: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-gray-750 font-blueberry block mb-1.5">Parent Account Password *</label>
                    <input
                      type="password"
                      required
                      placeholder="Define password for Parent Hub login..."
                      value={formFields.parentPassword}
                      onChange={(e) => setFormFields({ ...formFields, parentPassword: e.target.value })}
                      className="w-full border-2 border-black rounded-xl px-4 py-2.5 text-sm font-blueberry bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-legoblue transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs font-bold text-gray-700 font-blueberry block mb-1">Emergency Name</label>
                      <input
                        type="text"
                        placeholder="e.g., Uncle Fred"
                        value={formFields.emergencyName}
                        onChange={(e) => setFormFields({ ...formFields, emergencyName: e.target.value })}
                        className="w-full border-2 border-black rounded-lg px-3 py-1.5 text-sm font-blueberry text-xs"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-700 font-blueberry block mb-1">Emergency Phone</label>
                      <input
                        type="text"
                        placeholder="e.g., 88991130"
                        value={formFields.emergencyPhone}
                        onChange={(e) => setFormFields({ ...formFields, emergencyPhone: e.target.value })}
                        className="w-full border-2 border-black rounded-lg px-3 py-1.5 text-sm font-blueberry text-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Membership type & permissions */}
              <div className="bg-slate-50 rounded-xl border-2 border-black p-4 grid grid-cols-1 md:grid-cols-2 gap-4 shadow-[3px_3px_0px_#000]">
                <div>
                  <label className="text-sm font-bangers text-black block mb-1.5 tracking-wider">3. MEMBERSHIP LEVEL</label>
                  <select
                    value={formFields.membershipType}
                    onChange={(e) => setFormFields({ ...formFields, membershipType: e.target.value as Student['membershipType'] })}
                    className="w-full bg-white border-2 border-black rounded-lg px-3 py-2 text-sm font-blueberry"
                  >
                    <option value="Not a Member">Not a Member (Guest Single Entry)</option>
                    <option value="Adventurer">Adventurer (Up to 3x a week)</option>
                    <option value="Master Builder">Master Builder (Unlimited Assembly)</option>
                  </select>
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="photoPermission"
                    checked={formFields.photoPermission}
                    onChange={(e) => setFormFields({ ...formFields, photoPermission: e.target.checked })}
                    className="w-5 h-5 accent-legoblue border-2 border-black rounded cursor-pointer"
                  />
                  <label htmlFor="photoPermission" className="text-xs text-gray-700 font-semibold font-blueberry cursor-pointer">
                    I give permission for Bricks & Beyond to take photos and videos for program documentation and occasional promotional use.
                  </label>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 justify-end pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl border-2 border-black font-bangers text-sm text-black tracking-widest uppercase hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="submit"
                  id="submit-register-btn"
                  className="w-full sm:w-auto px-6 py-3 bg-legogreen hover:opacity-95 text-white rounded-xl border-2 border-black font-bangers text-sm tracking-widest uppercase shadow-[4px_4px_0px_#000] active:translate-y-0.5 active:shadow-[1px_1px_0px_#000] transition-all cursor-pointer"
                >
                  SUBMIT REGISTRATION
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
