import React, { useState } from 'react';
import { CalendarEvent } from '../types';
import { Calendar, ChevronLeft, ChevronRight, MapPin, Tag, Sparkles, Clock, AlertCircle } from 'lucide-react';

interface YearCalendarProps {
  events: CalendarEvent[];
}

export const YearCalendar: React.FC<YearCalendarProps> = ({ events }) => {
  // We can view months of the active year 2026
  const currentYear = 2026;
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth()); // default to current month (July = 6)
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);

  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  // Helper to get days in month
  const getDaysInMonth = (year: number, monthIndex: number) => {
    return new Date(year, monthIndex + 1, 0).getDate();
  };

  // Helper to get first day of month index (0 = Sun, 1 = Mon, etc.)
  const getFirstDayOfMonth = (year: number, monthIndex: number) => {
    return new Date(year, monthIndex, 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentYear, selectedMonth);
  const firstDayIndex = getFirstDayOfMonth(currentYear, selectedMonth);

  // Pad arrays to show weeks properly
  const calendarCells: (number | null)[] = [];
  for (let i = 0; i < firstDayIndex; i++) {
    calendarCells.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    calendarCells.push(d);
  }

  const handlePrevMonth = () => {
    setSelectedMonth(prev => (prev === 0 ? 11 : prev - 1));
    setSelectedEventId(null);
  };

  const handleNextMonth = () => {
    setSelectedMonth(prev => (prev === 11 ? 0 : prev + 1));
    setSelectedEventId(null);
  };

  // Get active event for a specific day in selected month
  const getEventForDay = (dayNum: number): CalendarEvent | undefined => {
    const formattedMonth = String(selectedMonth + 1).padStart(2, '0');
    const formattedDay = String(dayNum).padStart(2, '0');
    const isoString = `${currentYear}-${formattedMonth}-${formattedDay}`;
    return events.find(e => e.date === isoString);
  };

  const activeEvent = selectedEventId ? events.find(e => e.id === selectedEventId) : null;

  return (
    <div className="bg-white border-4 border-black rounded-3xl p-6 shadow-[8px_8px_0px_#000] space-y-6 font-sans text-left animate-fade-in" id="bnb-year-calendar">
      {/* Calendar Header with Lego Aesthetic */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b-4 border-black pb-4">
        <div className="flex items-center gap-3">
          <div className="bg-red-100 border-2 border-black p-2 rounded-xl text-legored">
            <Calendar className="w-7 h-7" />
          </div>
          <div>
            <h2 className="font-bangers text-3xl text-legored tracking-wider flex items-center gap-2">
              BNB YEAR SCHEDULE CALENDAR <span className="bg-legored text-white font-mono text-[10px] px-2 py-0.5 rounded-full uppercase tracking-normal">2026 PROGRAM</span>
            </h2>
            <p className="text-xs font-mono font-bold text-neutral-500 uppercase">
              Keep track of seasonal camps, structural workshops, and specialized STEM tournaments.
            </p>
          </div>
        </div>

        {/* Month selectors */}
        <div className="flex items-center gap-2 font-bangers">
          <button
            onClick={handlePrevMonth}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 border-2 border-black rounded-lg active:translate-y-0.5"
          >
            <ChevronLeft className="w-5 h-5 text-black" />
          </button>
          <span className="w-32 text-center text-xl uppercase tracking-wide border-b-2 border-black pb-0.5">
            {months[selectedMonth]} {currentYear}
          </span>
          <button
            onClick={handleNextMonth}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 border-2 border-black rounded-lg active:translate-y-0.5"
          >
            <ChevronRight className="w-5 h-5 text-black" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* MONTH VIEW GRID (lg:col-span-7) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-slate-50 border-2 border-black rounded-2xl p-4 shadow-[4px_4px_0px_rgba(0,0,0,0.05)]">
            {/* Days label */}
            <div className="grid grid-cols-7 gap-1 text-center font-mono text-xs font-bold text-slate-500 uppercase mb-2 border-b border-slate-200 pb-1.5">
              <span>Sun</span>
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
            </div>

            {/* Date digits cell grid */}
            <div className="grid grid-cols-7 gap-1.5">
              {calendarCells.map((day, idx) => {
                if (day === null) {
                  return <div key={`empty-${idx}`} className="aspect-square bg-slate-50 border border-slate-100 rounded-lg"></div>;
                }

                const event = getEventForDay(day);
                const hasEvent = !!event;
                const isSelected = selectedEventId && event?.id === selectedEventId;

                return (
                  <button
                    key={`day-${day}`}
                    type="button"
                    onClick={() => hasEvent && setSelectedEventId(event.id)}
                    disabled={!hasEvent}
                    className={`aspect-square border-2 rounded-xl flex flex-col justify-between p-1.5 transition-all relative ${
                      hasEvent 
                        ? isSelected
                          ? 'bg-legoyellow border-black shadow-[2px_2px_0px_#000] scale-102 cursor-pointer z-10'
                          : event.type === 'Camp'
                            ? 'bg-red-50 border-legored/80 text-legored hover:border-black cursor-pointer'
                            : event.type === 'Special Event'
                              ? 'bg-blue-50 border-legoblue/80 text-legoblue hover:border-black cursor-pointer'
                              : 'bg-emerald-50 border-legogreen/80 text-legogreen hover:border-black cursor-pointer'
                        : 'bg-white border-neutral-100 text-neutral-500 cursor-default hover:border-neutral-200'
                    }`}
                  >
                    <span className="text-xs font-mono font-bold leading-none">{day}</span>
                    
                    {/* Visual highlighted stud for events */}
                    {hasEvent && (
                      <span className={`w-3 h-3 rounded-full border border-black shadow-xs self-end ${
                        event.type === 'Camp' ? 'bg-legored animate-pulse' :
                        event.type === 'Special Event' ? 'bg-legoblue' :
                        'bg-legogreen'
                      }`} />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Color Indicators Legend */}
          <div className="flex flex-wrap gap-4 justify-start text-[11px] font-mono font-black uppercase text-neutral-500 px-1">
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-red-100 border border-legored/60 rounded-full flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-legored rounded-full"></span>
              </span>
              <span>Camps &amp; Intensive Weeks</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-blue-100 border border-legoblue/60 rounded-full flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-legoblue rounded-full"></span>
              </span>
              <span>Special Events &amp; Tournaments</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3.5 h-3.5 bg-green-100 border border-legogreen/60 rounded-full flex items-center justify-center">
                <span className="w-1.5 h-1.5 bg-legogreen rounded-full"></span>
              </span>
              <span>Holidays &amp; Workshops</span>
            </div>
          </div>
        </div>

        {/* EVENT DETAIL BOX (lg:col-span-5) */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <div className="bg-slate-50 border-2 border-black rounded-2xl p-5 shadow-[4px_4px_0px_rgba(0,0,0,0.05)] h-full flex flex-col justify-between">
            {activeEvent ? (
              <div className="space-y-4 animate-fade-in text-left">
                <div className="flex items-center justify-between">
                  <span className={`text-[10px] font-mono font-black uppercase px-2.5 py-0.5 rounded-md border border-black shadow-[1.5px_1.5px_0px_#000] ${
                    activeEvent.type === 'Camp' ? 'bg-red-500 text-white' :
                    activeEvent.type === 'Special Event' ? 'bg-blue-500 text-white' :
                    'bg-emerald-500 text-white'
                  }`}>
                    {activeEvent.type}
                  </span>
                  <span className="text-xs font-mono font-bold text-gray-500">
                    {new Date(activeEvent.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
                  </span>
                </div>

                <h3 className="font-bangers text-2xl text-black leading-tight tracking-wide border-b-2 border-dashed border-neutral-200 pb-2">
                  {activeEvent.title}
                </h3>

                <p className="text-xs leading-relaxed text-neutral-600 font-semibold">
                  {activeEvent.description}
                </p>

                <div className="space-y-2 pt-2 text-xs font-bold font-mono text-neutral-700 bg-white border border-neutral-200 rounded-xl p-3">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Schedule: All Day Class (09:00 AM - 04:00 PM)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Location: Santa Ana Main Center, Plaza Del Rio</span>
                  </div>
                </div>

                <p className="text-[10px] text-indigo-700 font-bold font-mono uppercase bg-indigo-50 border border-indigo-200 rounded-lg p-2 leading-snug">
                  * Register for camps and tournaments via our workshops tab or contact our head coach Clara directly!
                </p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center text-center py-12 px-4 h-full">
                <Sparkles className="w-10 h-10 text-neutral-300 animate-pulse mb-3" />
                <h4 className="font-bangers text-lg text-neutral-400 tracking-wide">NO EVENT HIGHLIGHTED</h4>
                <p className="text-xs font-semibold text-neutral-400 mt-1 uppercase font-mono max-w-[200px] leading-tight">
                  Click on any highlighted date on the calendar to reveal its program info.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Seasonal highlights layout slider */}
      <div className="bg-slate-50/50 border-2 border-black border-dashed rounded-2xl p-4">
        <h4 className="font-bangers text-base text-black mb-3 flex items-center gap-1 uppercase">
          UPCOMING 2026 BRICK CAMPS &amp; EVENTS HIGHLIGHTS
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {events.slice(0, 3).map(evt => (
            <div
              key={evt.id}
              onClick={() => {
                const dateObj = new Date(evt.date);
                setSelectedMonth(dateObj.getMonth());
                setSelectedEventId(evt.id);
              }}
              className="bg-white border-2 border-black hover:border-indigo-600 rounded-xl p-3 shadow-sm hover:shadow-[3px_3px_0px_rgba(0,0,0,0.1)] transition-all cursor-pointer flex justify-between items-start"
            >
              <div>
                <span className="text-[9px] font-mono font-black text-indigo-600 uppercase">
                  {new Date(evt.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
                <h5 className="font-bangers text-sm text-black tracking-wide leading-tight truncate w-44 uppercase">
                  {evt.title}
                </h5>
              </div>
              <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${
                evt.type === 'Camp' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
              }`}>
                {evt.type}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
